# -*- coding: utf-8 -*-

from datetime import datetime
from datetime import timedelta
import pendulum

SGD_TZ = pendulum.timezone('Asia/Seoul')
DEV_FLAG = 'dev'                             # prd/dev 구분

sgd_env = {
    'dag_owner': 'airflow',
    'wk_layer': 'w0',                                            # Working Layer
    'suffix_view': '_vw',                                        # View Suffix
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2021, 1, 1, tzinfo=SGD_TZ),           # DAG 시작일
}

conn_id = {
    'dl_s3': 'sgd_dl_s3_conn_id',                                # S3 connect
    'dl_redshift': {
        'igd': 'sgd_dl_igd_redshift_conn_id',                    # Redshift IGD cluster
        'acd': 'sgd_dl_acd_redshift_conn_id',                    # Redshift ACD cluster
    },
    'dl_ezgator': 'sgd_dl_ezgator_conn_id',
}

s3_env = {
    'stg_bucket_prefix': f'shcw-an2-datadam-{DEV_FLAG}-s3-dl-stg',
    'bck_bucket_prefix': f'shcw-an2-datadam-{DEV_FLAG}-s3-dl-bck',
}

redshift_env = {
    'copy_options': {
        'shb': ["csv delimiter '\037'"],
        'shc': ["csv delimiter '|'"],
        'shi': ["csv ignoreheader 1 delimiter '~'"],
        'shl': ["csv delimiter '|'"],
    },
    'unload_options': {
        'shb': ("csv","DELIMITER AS '\037'"),
        'shc': ("csv","DELIMITER AS '|'"),
        'shi': ("csv","DELIMITER AS '~'"),
        'shl': ("csv","DELIMITER AS '|'"),
    },
    'include_header': {
        'shb': False,
        'shc': False,
        'shi': True,
        'shl': False,
    },
    'unload_parallel': {
        'on': 'PARALLEL ON',
        'off': 'PARALLEL OFF',
    },
    'iam_role': {
        'igd': 'arn:aws:iam::796123547122:role/SHCW-DataDam-DEV-ROL-REDSHIFT-IGD-1',
        'acd': 'arn:aws:iam::796123547122:role/SHCW-DataDam-DEV-ROL-REDSHIFT-ACD-1',
    }
}

ezgator_env = {
    # 그룹사 송신
    'send': {
        'shell_path': '/shcsw/ezgator/client/ezgatorsend.sh',
        'if_nm_fmt': 'IF_DW_{company_code}_TO_SGD',
        # /로 끝나게 설정 (상위 경로는 IF에서 설정)
        'com_path' : {
            'shb_igd': '',
            'shb_acd': '',
            'shc_igd': '',
            'shc_acd': '',
            'shl_igd': '',
            'shl_acd': '',
        },
        # /로 끝나게 설정 (상위 경로는 IF에서 설정)
        'sgd_path' : {
            'shb_igd': '',
            'shb_acd': '',
            'shc_igd': '',
            'shc_acd': '',
            'shl_igd': '',
            'shl_acd': '',
        },
    },
    # 그룹사 수신
    'recv': {
        'shell_path': '/shcsw/ezgator/client/ezgatorsend.sh',
        'if_nm_fmt': 'IF_DW_SGD_TO_{company_code}',
        # /로 끝나게 설정
        'com_path': {
            'shb_igd': '',
            'shb_acd': '',
            'shc_igd': '',
            'shc_acd': '',
            'shl_igd': '',
            'shl_acd': '',
        },
        # /로 끝나게 설정
        'sgd_path' : {
            'shb_igd': 'shb/',
            'shb_acd': 'shb/',
            'shc_igd': 'shc/',
            'shc_acd': 'shc/',
            'shl_igd': 'shl/',
            'shl_acd': 'shl/',
        },
    },
    'list': {
        'shell_path': '/shcsw/ezgator/client/ezgatorlist.sh',
    },
}
