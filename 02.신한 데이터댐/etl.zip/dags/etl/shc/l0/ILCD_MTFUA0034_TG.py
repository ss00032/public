﻿# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum

from airflow import DAG
from sgd import config
from sgd.operators.l0_load_operator import L0LoadOperator
from sgd.operators.w0_unload_operator import W0UnloadOperator
from sgd.operators.stg_to_bck_operator import StgToBckOperator
from sgd.log_util import *
from sgd.utils import *


__author__     = "이종호"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["이종호"]
__version__    = "1.0"
__maintainer__ = "이종호"
__email__      = ""
__status__     = "Production"


"""
S3 파일 데이터를 Redshift에 적재하는 DAG 템플릿

기능 별로 분리 되었던 오퍼레이터를 하나로 통합해 내부적으로
아래 단계를 수행하면서 파일 데이터를 Redshift에 적재 한다.

  // APPEND 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY) 
  3. W0 Working 테이블 -> L0 테이블 insert
  
  // MERGE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 변경 데이터 delete
  4. W0 Working 테이블 -> L0 테이블 insert
  
  // OVERWRITE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 truncate
  3. W0 Working 테이블 -> L0 테이블 insert

하나의 파일을 받아 통합데이터, 동의고객데이터 클러스터에 적재하는 테이블은 UNLOAD 로직이 추가된다. 

[ 적용 방법 ]

제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 테이블 적재유형 (append, merge, overwrite)
  - 수집 파일명 prefix
  - INSERT용 Working 테이블 조회 쿼리 (선택적)
  - UNLOAD용 Working 테이블 조회 쿼리 (선택적)
  - L0 변경데이터 삭제 SQL (적재유형이 merge 인 경우만 해당)

"""

################################################################################
### Start of Target schema, working table, target table

""" 
(@) 프로그램 ID
"""
pgm_id = 'ILCD_MTFUA0034_TG'

""" 
(@) 테이블 적재 구분  
a: append, o: overwrite, m: merge
"""
table_load_type = 'o'

""" 
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

""" 
(@) 수집 파일명 prefix

은행/카드/라이프 예시: 
s3_file_prefix = 'ibd_dwa_job_date_/ibd_dwa_job_date_'
s3_file_prefix = f'jd_append_table_/jd_append_table_{execution_kst}'
금투 예시: 
s3_file_prefix = 'iid_aaa001m00_'
s3_file_prefix = f'iid_aaa001m00_{execution_kst}'
"""
s3_file_prefix = f'icd_mtfua0034_/icd_mtfua0034_{execution_kst}'

# 적재 Layer
target_layer = 'l0'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = f'{target_layer}_{company_code}'

# 적재 Working 스키마
working_schema = f"{config.sgd_env['wk_layer']}_{company_code}"

""" 
(@) L0 변경데이터 삭제 SQL (적재유형이 merge인 경우만 해당)
PK를 이용한 Join Query 
"""
delete_sql_for_merge = f"""
        delete from l0_shc.mtfua0034
              where 1 = 1 
"""

""" 
(@) INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
select_sql_for_insert = f"""
    insert into l0_shc.mtfua0034
                (
                  aws_ls_dt                               -- aws적재일시
                , ced                                     -- 기준일자
                , bg_cz_bsn_pd_cd                         -- 대분류영업상품코드
                , sls_ts_n                                -- 매출거래번호
                , ls_ld_dt                                -- 최종적재일시
                , sgdmd                                   -- 그룹md번호
                , sgdci                                   -- ci번호
                , sgdmd_dfr_n                             -- 고객구별그룹md번호
                , sgdci_dfr_n                             -- 고객구별ci번호
                , ts_d                                    -- 거래일자
                , cry_k_sgdmd                             -- 소지자그룹md번호
                , cry_k_sgdci                             -- 소지자ci번호
                , crd_pd_n                                -- 카드상품번호
                , crd_tcd                                 -- 카드유형코드
                , bsn_pd_cd                               -- 영업상품코드
                , cct1_crd_pd_n                           -- 개념1카드상품번호
                , cct2_crd_pd_n                           -- 개념2카드상품번호
                , r_sls_ts_n                              -- 원매출거래번호
                , lsp_rid                                 -- 매출전표접수일자
                , aq_de_d                                 -- 매입확정일자
                , sls_pi_d                                -- 매출반영일자
                , lsp_pcd                                 -- 매출전표경로코드
                , saa                                     -- 매출금액
                , cus_bla                                 -- 회원청구금액
                , lsp_at                                  -- 매출전표금액
                , ln_hcd                                  -- 대출지점코드
                , nr_hcd                                  -- 관리지점코드
                , mct_n                                   -- 가맹점번호
                , mct_ry_cd                               -- 가맹점업종코드
                , mct_kcd                                 -- 가맹점종류코드
                , bcc_mct_n                               -- bc카드가맹점번호
                , bcc_mct_tf                              -- bc카드가맹점tf
                , sls_ce_ccd                              -- 매출취소구분코드
                , ce_si_tf                                -- 취소전표tf
                , apv_n                                   -- 승인번호
                , apv_d                                   -- 승인일자
                , apv_tm                                  -- 승인시간
                , apv_tcd                                 -- 승인유형코드
                , crd_ico_ccd                             -- 카드발급사구분코드
                , cv_pcd                                  -- 현금서비스경로코드
                , cv_pm_ccd                               -- 현금서비스지급구분코드
                , chk_cre_sls_se_tf                       -- 체크신용매출사용tf
                , nn_ir_ns_ef_si_tf                       -- 무이자할부적용전표tf
                , nn_ir_ns_ef_cy_ms_cn                    -- 무이자할부적용주기개월수
                , ns_ms_cn                                -- 할부개월수
                , rls_si_tf                               -- 재매출전표tf
                , rls_r_ts_nr_n                           -- 재매출원거래관리번호
                , afo_n                                   -- 제휴사번호
                , afs_n                                   -- 제휴점번호
                , ctc_n                                   -- 약정번호
                , dct_pd_tf                               -- 다이렉트상품tf
                , mfg_gp_cd                               -- 제품그룹코드
                , fss_ta_hga                              -- 금감원기준취급금액
                , cv_fea                                  -- 현금서비스수수료금액
                , cv_hdg_fea                              -- 현금서비스취급수수료금액
                , cv_afl_fea                              -- 현금서비스제휴수수료금액
                , mcc_cd                                  -- mcc코드
                , to_saa                                  -- 총매출금액
                , to_fea                                  -- 총수수료금액
                , mo_tol_bj_tf                            -- 판촉집계대상tf
                , crd_rpl_n                               -- 카드대체번호
                )
    select  current_timestamp AT TIME ZONE 'Asia/Seoul' 
          , ced                                     -- 기준일자
          , bg_cz_bsn_pd_cd                         -- 대분류영업상품코드
          , sls_ts_n                                -- 매출거래번호
          , ls_ld_dt                                -- 최종적재일시
          , sgdmd                                   -- 그룹md번호
          , sgdci                                   -- ci번호
          , sgdmd_dfr_n                             -- 고객구별그룹md번호
          , sgdci_dfr_n                             -- 고객구별ci번호
          , ts_d                                    -- 거래일자
          , cry_k_sgdmd                             -- 소지자그룹md번호
          , cry_k_sgdci                             -- 소지자ci번호
          , crd_pd_n                                -- 카드상품번호
          , crd_tcd                                 -- 카드유형코드
          , bsn_pd_cd                               -- 영업상품코드
          , cct1_crd_pd_n                           -- 개념1카드상품번호
          , cct2_crd_pd_n                           -- 개념2카드상품번호
          , r_sls_ts_n                              -- 원매출거래번호
          , lsp_rid                                 -- 매출전표접수일자
          , aq_de_d                                 -- 매입확정일자
          , sls_pi_d                                -- 매출반영일자
          , lsp_pcd                                 -- 매출전표경로코드
          , saa                                     -- 매출금액
          , cus_bla                                 -- 회원청구금액
          , lsp_at                                  -- 매출전표금액
          , ln_hcd                                  -- 대출지점코드
          , nr_hcd                                  -- 관리지점코드
          , mct_n                                   -- 가맹점번호
          , mct_ry_cd                               -- 가맹점업종코드
          , mct_kcd                                 -- 가맹점종류코드
          , bcc_mct_n                               -- bc카드가맹점번호
          , bcc_mct_tf                              -- bc카드가맹점tf
          , sls_ce_ccd                              -- 매출취소구분코드
          , ce_si_tf                                -- 취소전표tf
          , apv_n                                   -- 승인번호
          , apv_d                                   -- 승인일자
          , apv_tm                                  -- 승인시간
          , apv_tcd                                 -- 승인유형코드
          , crd_ico_ccd                             -- 카드발급사구분코드
          , cv_pcd                                  -- 현금서비스경로코드
          , cv_pm_ccd                               -- 현금서비스지급구분코드
          , chk_cre_sls_se_tf                       -- 체크신용매출사용tf
          , nn_ir_ns_ef_si_tf                       -- 무이자할부적용전표tf
          , nn_ir_ns_ef_cy_ms_cn                    -- 무이자할부적용주기개월수
          , ns_ms_cn                                -- 할부개월수
          , rls_si_tf                               -- 재매출전표tf
          , rls_r_ts_nr_n                           -- 재매출원거래관리번호
          , afo_n                                   -- 제휴사번호
          , afs_n                                   -- 제휴점번호
          , ctc_n                                   -- 약정번호
          , dct_pd_tf                               -- 다이렉트상품tf
          , mfg_gp_cd                               -- 제품그룹코드
          , fss_ta_hga                              -- 금감원기준취급금액
          , cv_fea                                  -- 현금서비스수수료금액
          , cv_hdg_fea                              -- 현금서비스취급수수료금액
          , cv_afl_fea                              -- 현금서비스제휴수수료금액
          , mcc_cd                                  -- mcc코드
          , to_saa                                  -- 총매출금액
          , to_fea                                  -- 총수수료금액
          , mo_tol_bj_tf                            -- 판촉집계대상tf
          , crd_rpl_n                               -- 카드대체번호
      from w0_shc.mtfua0034
"""

""" 
(@) UNLOAD용 Working 테이블 조회 쿼리 (선택적)
"""
select_sql_for_unload = f"""
"""

### End of Target schema, working table, target table
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': handle_etl_error,
    'company_code' : company_code,
    'use_purpose' : use_purpose,
    'execution_kst' : execution_kst,
    's3_key' : s3_file_prefix
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
    dag_id=dag_id,
    description=f'{dag_id} DAG',
    start_date=config.sgd_env['start_date'],
    schedule_interval=None,
    default_args=args,
    tags=tags,
    catchup=False) as dag :

    l0_load_task = L0LoadOperator(
        task_id='l0_load_task',
        target_schema=target_schema,
        target_table=target_table,
        table_load_type=table_load_type,
        delete_sql_for_merge=delete_sql_for_merge,
        select_sql_for_insert=select_sql_for_insert,
    )


#    w0_unload_task = W0UnloadOperator(
#        task_id='w0_unload_task',
#        schema=target_schema,
#        table=target_table,
#        select_query=select_sql_for_unload,
#    )
#
#    stg_to_bck_operator = StgToBckOperator(
#        task_id='stg_to_bck_task',
#    )

#    l0_load_task >> w0_unload_task >> stg_to_bck_operator
    l0_load_task
