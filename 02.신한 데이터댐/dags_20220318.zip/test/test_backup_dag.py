# -*- coding: utf-8 -*-

import os
from airflow.exceptions import AirflowException
from airflow.models.dag import DAG
from airflow.utils.dates import days_ago

from airflow.hooks.S3_hook import S3Hook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults


class S3CopyObjectOperator(BaseOperator):
    """
    Creates a copy of an object that is already stored in S3.

    Note: the S3 connection used here needs to have access to both
    source and destination bucket/key.

    :param source_bucket_key: The key of the source object. (templated)

        It can be either full s3:// style url or relative path from root level.

        When it's specified as a full s3:// url, please omit source_bucket_name.
    :type source_bucket_key: str
    :param dest_bucket_key: The key of the object to copy to. (templated)

        The convention to specify `dest_bucket_key` is the same as `source_bucket_key`.
    :type dest_bucket_key: str
    :param source_bucket_name: Name of the S3 bucket where the source object is in. (templated)

        It should be omitted when `source_bucket_key` is provided as a full s3:// url.
    :type source_bucket_name: str
    :param dest_bucket_name: Name of the S3 bucket to where the object is copied. (templated)

        It should be omitted when `dest_bucket_key` is provided as a full s3:// url.
    :type dest_bucket_name: str
    :param source_version_id: Version ID of the source object (OPTIONAL)
    :type source_version_id: str
    :param aws_conn_id: Connection id of the S3 connection to use
    :type aws_conn_id: str
    :param verify: Whether or not to verify SSL certificates for S3 connection.
        By default SSL certificates are verified.

        You can provide the following values:

        - False: do not validate SSL certificates. SSL will still be used,
                 but SSL certificates will not be
                 verified.
        - path/to/cert/bundle.pem: A filename of the CA cert bundle to uses.
                 You can specify this argument if you want to use a different
                 CA cert bundle than the one used by botocore.
    :type verify: bool or str
    """

    template_fields = ('source_bucket_key', 'dest_bucket_key',
                       'source_bucket_name', 'dest_bucket_name')

    @apply_defaults
    def __init__(
            self,
            source_bucket_key,
            dest_bucket_key,
            source_bucket_name=None,
            dest_bucket_name=None,
            source_version_id=None,
            aws_conn_id='aws_default',
            verify=None,
            *args, **kwargs):
        super(S3CopyObjectOperator, self).__init__(*args, **kwargs)

        self.source_bucket_key = source_bucket_key
        self.dest_bucket_key = dest_bucket_key
        self.source_bucket_name = source_bucket_name
        self.dest_bucket_name = dest_bucket_name
        self.source_version_id = source_version_id
        self.aws_conn_id = aws_conn_id
        self.verify = verify

    def execute(self, context):
        s3_hook = S3Hook(aws_conn_id=self.aws_conn_id, verify=self.verify)
        s3_hook.copy_object(self.source_bucket_key, self.dest_bucket_key,
                            self.source_bucket_name, self.dest_bucket_name,
                            self.source_version_id)


class S3DeleteObjectsOperator(BaseOperator):
    """
    To enable users to delete single object or multiple objects from
    a bucket using a single HTTP request.

    Users may specify up to 1000 keys to delete.

    :param bucket: Name of the bucket in which you are going to delete object(s). (templated)
    :type bucket: str
    :param keys: The key(s) to delete from S3 bucket. (templated)

        When ``keys`` is a string, it's supposed to be the key name of
        the single object to delete.

        When ``keys`` is a list, it's supposed to be the list of the
        keys to delete.

        You may specify up to 1000 keys.
    :type keys: str or list
    :param aws_conn_id: Connection id of the S3 connection to use
    :type aws_conn_id: str
    :param verify: Whether or not to verify SSL certificates for S3 connection.
        By default SSL certificates are verified.

        You can provide the following values:

        - ``False``: do not validate SSL certificates. SSL will still be used,
                 but SSL certificates will not be
                 verified.
        - ``path/to/cert/bundle.pem``: A filename of the CA cert bundle to uses.
                 You can specify this argument if you want to use a different
                 CA cert bundle than the one used by botocore.
    :type verify: bool or str
    """

    template_fields = ('keys', 'prefix', 'bucket')

    @apply_defaults
    def __init__(
            self,
            bucket,
            prefix,
            keys,
            aws_conn_id='aws_default',
            verify=None,
            *args, **kwargs):
        super(S3DeleteObjectsOperator, self).__init__(*args, **kwargs)
        self.bucket = bucket
        self.prefix = prefix
        self.keys = keys
        self.aws_conn_id = aws_conn_id
        self.verify = verify

    def execute(self, context):
        s3_hook = S3Hook(aws_conn_id=self.aws_conn_id, verify=self.verify)

        object_keys = s3_hook.list_keys(bucket_name=self.bucket, prefix=self.prefix)

        s3_hook.delete_objects(bucket=self.bucket, keys=object_keys)
        #response = s3_hook.delete_objects(bucket=self.bucket, keys = object_keys)

        #deleted_keys = [x['Key'] for x in response.get("Deleted", [])]

        #deleted_keys = response.get("Deleted", [])
        #self.log.info("Deleted: %s", deleted_keys)

        #if "Errors" in response:
        #    errors_keys = [x['Key'] for x in response.get("Errors", [])]
        #    raise AirflowException("Errors when deleting: {}".format(errors_keys))


# DAG 정의
dag_id = 'test_backup_dag'

dag = DAG(
    dag_id=dag_id,
    description='BACKUP TEST DAG',
    schedule_interval=None,
    start_date=days_ago(2),
    max_active_runs=1,
    tags=['test', 's3', 'backup'],
    catchup=False
)

copy_task = S3CopyObjectOperator(
    task_id='filecopy_task',

    source_bucket_name='shcw-an2-datadam-dev-s3-dl-stg-shb-igd-1/backup_test', # 파일 위치
    source_bucket_key='backup_test_file.csv',  # 파일명
    dest_bucket_name='shcw-an2-datadam-dev-s3-dl-bck-shb-igd-1',  # destination 버킷명
    dest_bucket_key='backup_test_file.csv',  # copy 후 파일명
    source_version_id=None,  # optional
    aws_conn_id='sgd_dl_s3_conn_id',
    dag=dag
)

remove_task = S3DeleteObjectsOperator(
    task_id='filerm_task',
    bucket='shcw-an2-datadam-dev-s3-dl-stg-shb-igd-1',
    prefix='backup_test',
    keys='backup_test_file.csv',
    aws_conn_id='sgd_dl_s3_conn_id',
    dag=dag
)

copy_task >> remove_task
