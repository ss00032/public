# -*- coding: utf-8 -*-


from airflow.models.dag import DAG
from airflow.providers.ssh.operators.ssh import SSHOperator

from sgd import config

odate = "{{ dag_run.conf['odate'] }}"
pg_code_arg = 'datagg,datahira,dataportal,eais,ecos,incos,insure,iros,kosis,school,seoul,finlife'
command = f"python3 /datadam/konan/konan_to_sgd_1222.py {odate} {pg_code_arg}"

dag_id = 'CMM_GET_KONAN_TG'

with DAG(
        dag_id=dag_id,
        description=f'{dag_id} DAG',
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        max_active_runs=1,
        tags=['common', 'konan'],
) as dag:
    ssh_task = SSHOperator(
        task_id='ssh_task',
        ssh_conn_id='sgd_dl_konan_conn_id',
        command=command,
    )
    ssh_task