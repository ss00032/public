# -*- coding: utf-8 -*-

from airflow.models.dag import DAG
from airflow.providers.ssh.operators.ssh import SSHOperator
from sgd import config

cp_code = "{{ dag_run.conf['cp_code'] }}"
userid = "{{ dag_run.conf['userid'] }}"
database = "{{ dag_run.conf['database'] }}"
table = "{{ dag_run.conf['table'] }}"

ssh_command = f"python3 /shcsrc/python/sgd-dl-ezgator/script/sgd_export_to_company.py {cp_code} {userid} {database} {table}"

dag_id = "EXPORT_TO_COMPANY_TG"

with DAG(
    dag_id=dag_id,
    description='분석결과 그룹사 제공',
    start_date=config.sgd_env['start_date'],
    schedule_interval=None,
    tags=['common','exp'],
) as dag:
    ssh_task = SSHOperator(
        task_id='ssh_task',
        ssh_conn_id='sgd_dl_ezgator_conn_id',
        command=ssh_command
    )
    ssh_task
