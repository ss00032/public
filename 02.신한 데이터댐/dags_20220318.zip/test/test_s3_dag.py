# -*- coding: utf-8 -*-

import os

from airflow.models.dag import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.utils.dates import days_ago

BUCKET_NAME = os.environ.get('BUCKET_NAME', 'shcw-an2-datadam-dev-s3-dl-stg-shb-igd-1')


def upload_keys():
    """This is a python callback to add keys into the s3 bucket"""
    # add keys to bucket
    s3_hook = S3Hook(aws_conn_id='sgd_dl_s3_conn_id')
    for i in range(0, 3):
        s3_hook.load_string(
            string_data="input",
            key=f"path/data{i}",
            replace=True,
            bucket_name=BUCKET_NAME,
        )


def list_keys():
    s3_hook = S3Hook(aws_conn_id='sgd_dl_s3_conn_id')
    list = s3_hook.list_keys(bucket_name=BUCKET_NAME, prefix='path')
    print(list)


with DAG(
        dag_id='test_s3_dag',
        schedule_interval=None,
        start_date=days_ago(2),
        max_active_runs=1,
        tags=['test', 's3'],
) as dag:
    add_keys_to_bucket = PythonOperator(
        task_id="s3_bucket_dag_add_keys_to_bucket", python_callable=upload_keys
    )
    list_keys_to_bucket = PythonOperator(
        task_id="s3_bucket_dag_list_keys_to_bucket", python_callable=list_keys
    )
    add_keys_to_bucket >> list_keys_to_bucket
