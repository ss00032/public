# -*- coding: utf-8 -*-

import datetime
from airflow import DAG
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

from sgd import config


__author__ = "유수형"
__copyright__ = "Copyright 2021, Shinhan Datadam"
__credits__ = ["유수형"]
__version__ = "1.0"
__maintainer__ = "유수형"
__email__ = "april@lgcns.com"
__status__ = "Production"

args = {
    'owner': config.sgd_env['dag_owner'],
    'provide_context': True,
}


"""
(@) 배치 DAG 이름 수정
"""
batch_dag_name = 'TEST_BATCH_DAG'


dag = DAG(
    dag_id=batch_dag_name,
    description=f'{batch_dag_name.upper()}',
    schedule_interval=None,
    start_date=config.sgd_env['start_date'],
    default_args=args,
    tags=['test', 'bundle', 'trigger'],
    catchup=False
)

"""
(@) 배치 DAG 리스트 정의
  - 실행 대상 dag_id 입력
  - 최대 32개 이하 권장
"""
dag_id_batch_list = [
    'ILID_TEST_SENSOR_TG',
    'ILID_TEST_SENSOR_FAIL_TG',
]

# wait_until_done_task = DummyOperator(
#     task_id='wait_until_done_task',
#     dag=dag,
# )

# collect_etl_result_task = PythonOperator(
#     task_id='collect_etl_result_task',
#     python_callable=collect_etl_result,
#     op_kwargs={
#         'ti_key': '{{ task_instance_key_str }}',    # {dag_id}__{task_id}__{ds}
#         'execution_date': '{{ execution_date }}',
#     },
#     dag=dag,
# )

for dag_id in dag_id_batch_list:
    triggering_task = TriggerDagRunOperator(
        task_id=f'trigger_{dag_id}',
        trigger_dag_id=dag_id,
        execution_date='{{ execution_date }}',
        # pool='trigger_pool',
        reset_dag_run=True,
        wait_for_completion=True,
        poke_interval=10,
        dag=dag
    )
    triggering_task

# collect_etl_result_task >> wait_until_done_task
