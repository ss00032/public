# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
import os

from airflow.models.dag import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.dates import days_ago
from contextlib import closing

#sgd_conn_id = 'sgd_dl_igd_redshift_conn_id'
sgd_conn_id = 'sgd_dl_acd_redshift_conn_id'

def select_redshift():
    redshift_hook = PostgresHook(postgres_conn_id=sgd_conn_id)
    sql = 'SELECT * FROM l0_shb.append_table'
    with closing(redshift_hook.get_conn()) as conn:
        with closing(conn.cursor()) as cur:
            cur.execute(sql)
            result = cur.fetchall()
            for x in result:
                print(x)

def insert_redshift():
    redshift_hook = PostgresHook(postgres_conn_id=sgd_conn_id)
    sql = "INSERT INTO l0_shb.append_table VALUES (1, 'skoh5', 1, 'ko', 'iphone', 10.12, 'wait')"
    with closing(redshift_hook.get_conn()) as conn:
        with closing(conn.cursor()) as cur:
            cur.execute(sql)
            conn.commit()


def delete_redshift():
    redshift_hook = PostgresHook(postgres_conn_id=sgd_conn_id)
    sql = "DELETE FROM l0_shb.append_table WHERE time_ref = 1"
    with closing(redshift_hook.get_conn()) as conn:
        with closing(conn.cursor()) as cur:
            cur.execute(sql)
            conn.commit()


with DAG(
        dag_id='test_redshift_dag',
        schedule_interval=None,
        start_date=days_ago(2),
        max_active_runs=1,
        tags=['test', 'redshift'],
) as dag:
    insert_redshift = PythonOperator(
        task_id="insert_redshift", python_callable=insert_redshift
    )
    select_redshift = PythonOperator(
        task_id="select_redshift", python_callable=select_redshift
    )
    delete_redshift = PythonOperator(
        task_id="delete_redshift", python_callable=delete_redshift
    )

    insert_redshift >> select_redshift >> delete_redshift
