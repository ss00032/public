﻿# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from sgd import config
from airflow.operators.python import ShortCircuitOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator

from sgd import logging
from sgd.utils import *


""" 
(@) 프로그램 ID
"""
pgm_id = 'ILID_TEST_BRANCH_TASK_TG'
""" 
(@) 테이블 적재 구분  
a: append, o: overwrite, m: merge
"""
table_load_type = 'o'

""" 
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

""" 
(@) 수집 파일명 prefix
"""
# NOT FOUND FILE for test
#s3_file_prefix = f'icd_mtd50_20211117_/icd_mtdia50_20211117'

# EXIST FILE for test
s3_file_prefix = f'icd_mtdia5010_20211117_/icd_mtdia5010_20211117'
#s3_file_prefix = f'icm_MTDIA0005_202111_/icm_MTDIA0005_202111'

# 적재 Layer
target_layer = 'l0'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = f'{target_layer}_{company_code}'

# 적재 Working 스키마
working_schema = f"{config.sgd_env['wk_layer']}_{company_code}"

""" 
(@) L0 변경데이터 삭제 SQL (적재유형이 merge인 경우만 해당)
PK를 이용한 Join Query 
"""
delete_sql_for_merge = f"""
        delete from l0_shc.scomb0005
              where 1 = 1 
"""

""" 
(@) INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
select_sql_for_insert = f"""
"""

""" 
(@) UNLOAD용 Working 테이블 조회 쿼리 (선택적)
"""
select_sql_for_unload = f"""
"""

### End of Target schema, working table, target table
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'company_code' : company_code,
    'use_purpose' : use_purpose,
    'execution_kst' : execution_kst,
    's3_key' : s3_file_prefix
}

# ## airflow variable
# from airflow.models import Variable
#
# skip_ez = Variable.get("skip_ez")
# print("skip_ez :")
# print(skip_ez)


ez_on = 'NO'


def ezgator_on():
    print("ez_on :")
    print(ez_on)
    print("=========")

    if ez_on == 'YES':
        return '002_ez_list_task'
    elif ez_on == 'NO':
        return '004_l0_load_task'
    else:
        return '004_l0_load_task'


def print_hello_1():
    return 'task hello 1'


def print_hello_2():
    return 'task hello 2'


def print_hello_3():
    return 'task hello 3'


# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

tags.append('test')

with DAG(
    dag_id=dag_id,
    description=f'{dag_id} DAG',
    start_date=config.sgd_env['start_date'],
    schedule_interval=None,
    on_success_callback=logging.handle_dag_success,
    default_args=args,
    tags=tags,
    catchup=False) as dag :

    skip_ez_task = BranchPythonOperator(
        task_id='001_skip_ez_task',
        python_callable=ezgator_on,  # True: run, False: skip
        dag=dag)

    hello_1_task = PythonOperator(
        task_id='002_ez_list_task',
        python_callable=print_hello_1,
        dag=dag)

    hello_2_task = PythonOperator(
        task_id='003_ez_send_task',
        python_callable=print_hello_2,
        dag=dag)

    hello_3_task = PythonOperator(
        task_id='004_l0_load_task',
        python_callable=print_hello_3,
        trigger_rule='none_failed',
        dag=dag)

    # skip_ez_task >> ez_list_task >> ez_send_task >> l0_load_task

    # hello_1_task.set_upstream(skip_ez_task)
    # hello_1_task >> hello_2_task >> hello_3_task

    # start_dag >> branching >> [b1, b2, b3]

    skip_ez_task >> [hello_1_task, hello_3_task]
    hello_1_task.set_downstream(hello_2_task)
    hello_2_task.set_downstream(hello_3_task)

