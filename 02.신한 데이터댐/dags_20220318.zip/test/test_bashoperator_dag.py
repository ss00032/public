# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum

from airflow import DAG
from airflow.operators.bash import BashOperator

from sgd.date_util import *


dag = DAG(
    dag_id='test_bashoperator_dag',
    description='test bash',
    start_date=datetime(2021, 10, 1),
    schedule_interval=None,
    tags=['test','bash'],
    catchup=False
)

only_task = BashOperator(

    task_id='only_task',
    bash_command='echo {{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}',
    dag=dag

)

only_task