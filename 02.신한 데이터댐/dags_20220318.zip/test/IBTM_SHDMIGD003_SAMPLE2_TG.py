# -*- coding: utf-8 -*-

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *


__author__     = "이일주"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["이일주"]
__version__    = "1.0"
__maintainer__ = "이일주"
__email__      = "LEE1122334@xgm.co.kr"
__status__     = "Production"


"""
SH2 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID  : IBTM_SHDMIGD003_TG
  - 한글 테이블명: IGD_월고객보유상품기본
  - tmp_sh2 테이블명: tmp_sh2.shdmigd003_tmp99
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMIGD003_SAMPLE2_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = 'IGD_월고객보유상품기본'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

##날짜변수 사용관련 
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) tmp_sh2 테이블명 (TRUNCATE 대상)
"""
tmp_sh2_table = ['shdmigd003_tmp99','shdmigd003_tmp01','shdmigd003_tmp02','shdmigd003_tmp03','shdmigd003_tmp04']

"""
(@) tmp_sh2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmigd003_tmp01
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , mrp_pd_pss_tf                          -- 입출금상품보유TF
         , sai_pd_pss_tf                          -- 예적금상품보유TF
         , ln_pd_pss_tf                           -- 대출상품보유TF
         , ivs_pd_pss_tf                          -- 투자상품보유TF
         , pot_scu_pss_tf                         -- 지분증권보유TF
         , eb_scu_pss_tf                          -- 채무증권보유TF
         , eni_scu_pss_tf                         -- 수익증권보유TF
         , ivs_are_scu_pss_tf                     -- 투자계약증권보유TF
         , drb_cmb_scu_pss_tf                     -- 파생결합증권보유TF
         , scu_msd_scu_pss_tf                     -- 증권예탁증권보유TF
         , mont_ase_pss_tf                        -- 금전자산보유TF
         , pnz_pd_pss_tf                          -- 연금상품보유TF
         , iu_pd_pss_tf                           -- 보험상품보유TF
         , crd_pd_pss_tf                          -- 카드상품보유TF
         , shb_liq_pd_cn                          -- 신한은행유동성상품수
         , shb_sav_pd_cn                          -- 신한은행예금상품수
         , shb_issv_pd_cn                         -- 신한은행적금상품수
         , shb_trt_pd_cn                          -- 신한은행신탁상품수
         , shb_fud_pd_cn                          -- 신한은행펀드상품수
         , shb_rtr_pnz_pd_cn                      -- 신한은행퇴직연금상품수
         , shb_pnz_trt_pd_cn                      -- 신한은행연금신탁상품수
         , shb_hsg_ll_ln_pd_cn                    -- 신한은행주택담보대출상품수
         , shb_leh_mny_ln_pd_cn                   -- 신한은행전세자금대출상품수
         , shb_cre_ln_pd_cn                       -- 신한은행신용대출상품수
         , shb_fnn_pd_ll_ln_pd_cn                 -- 신한은행금융상품담보대출상품수
         , shb_eco_ln_pd_cn                       -- 신한은행기업대출상품수
         , shb_et_ln_pd_cn                        -- 신한은행기타대출상품수
         , shb_psn_etk_ln_pd_cn                   -- 신한은행개인사업자대출상품수
         , shb_et_esa_ln_pd_cn                    -- 신한은행기타부동산대출상품수
         , shb_car_ln_pd_cn                       -- 신한은행자동차대출상품수
         , pss_iu_cn                              -- 보유보험수
         , pss_crd_cn                             -- 보유카드수
         )
    -- 은행
    select ta_ym                            as ta_ym                   -- 기준년월
         , shmdn
         , max(case when shd_pd_zcd = 'B11'
                    then '1'
                    else '0'
                end)                        as mrp_pd_pss_tf           -- 입출금상품보유TF
         , max(case when shd_pd_zcd in ('B12','B13')
                    then '1'
                    else '0'
                end)                        as sai_pd_pss_tf           -- 예적금상품보유TF
         , max(case when shd_pd_zcd in ('B21','B22','B23','B24','B25','B26','B27','B28','B29')
                    then '1'
                    else '0'
                end)                        as ln_pd_pss_tf            -- 대출상품보유TF
         , max(case when shd_pd_zcd in ('B14','B15','B16')
                    then '1'
                    else '0'
                end)                        as ivs_pd_pss_tf           -- 투자상품보유TF
         , '0'                              as pot_scu_pss_tf          -- 지분증권보유TF
         , '0'                              as eb_scu_pss_tf           -- 채무증권보유TF
         , '0'                              as eni_scu_pss_tf          -- 수익증권보유TF
         , '0'                              as ivs_are_scu_pss_tf      -- 투자계약증권보유TF
         , '0'                              as drb_cmb_scu_pss_tf      -- 파생결합증권보유TF
         , '0'                              as scu_msd_scu_pss_tf      -- 증권예탁증권보유TF
         , '0'                              as mont_ase_pss_tf         -- 금전자산보유TF
         , max(case when shd_pd_zcd in ('B16','B17')
                    then '1'
                    else '0'
                end)                        as pnz_pd_pss_tf           -- 연금상품보유TF
         , '0'                              as iu_pd_pss_tf            -- 보험상품보유TF
         , '0'                              as crd_pd_pss_tf           -- 카드상품보유TF
         , nvl(count(distinct case when shd_pd_zcd = 'B11'
                                   then ts_dtn_n
                               end),0)      as shb_liq_pd_cn           -- 신한은행유동성상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B12'
                                   then ts_dtn_n
                               end),0)      as shb_sav_pd_cn           -- 신한은행예금상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B13'
                                   then ts_dtn_n
                               end),0)      as shb_issv_pd_cn          -- 신한은행적금상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B15'
                                   then ts_dtn_n
                               end),0)      as shb_trt_pd_cn           -- 신한은행신탁상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B14'
                                   then ts_dtn_n
                               end),0)      as shb_fud_pd_cn           -- 신한은행펀드상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B17'
                                   then ts_dtn_n
                               end),0)      as shb_rtr_pnz_pd_cn       -- 신한은행퇴직연금상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B16'
                                   then ts_dtn_n
                               end),0)      as shb_pnz_trt_pd_cn       -- 신한은행연금신탁상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B23'
                                   then ts_dtn_n
                               end),0)      as shb_hsg_ll_ln_pd_cn     -- 신한은행주택담보대출상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B22'
                                   then ts_dtn_n
                               end),0)      as shb_leh_mny_ln_pd_cn    -- 신한은행전세자금대출상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B21'
                                   then ts_dtn_n
                               end),0)      as shb_cre_ln_pd_cn        -- 신한은행신용대출상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B25'
                                   then ts_dtn_n
                               end),0)      as shb_fnn_pd_ll_ln_pd_cn  -- 신한은행금융상품담보대출상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B28'
                                   then ts_dtn_n
                               end),0)      as shb_eco_ln_pd_cn        -- 신한은행기업대출상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B29'
                                   then ts_dtn_n
                               end),0)      as shb_et_ln_pd_cn         -- 신한은행기타대출상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B27'
                                   then ts_dtn_n
                               end),0)      as shb_psn_etk_ln_pd_cn    -- 신한은행개인사업자대출상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B24'
                                   then ts_dtn_n
                               end),0)      as shb_et_esa_ln_pd_cn     -- 신한은행기타부동산대출상품수
         , nvl(count(distinct case when shd_pd_zcd = 'B26'
                                   then ts_dtn_n
                               end),0)      as shb_car_ln_pd_cn        -- 신한은행자동차대출상품수
         , 0                                as pss_iu_cn               -- 보유보험수
         , 0                                as pss_crd_cn              -- 보유카드수
      from sh1.shbmpdt001
     where ta_ym = '{date_cd('P_TA_YM')}'
     group by ta_ym
            , shmdn
"""

insert_sql_for_tmp_2 = f"""
    insert into tmp_sh2.shdmigd003_tmp02
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , mrp_pd_pss_tf                          -- 입출금상품보유TF
         , sai_pd_pss_tf                          -- 예적금상품보유TF
         , ln_pd_pss_tf                           -- 대출상품보유TF
         , ivs_pd_pss_tf                          -- 투자상품보유TF
         , pot_scu_pss_tf                         -- 지분증권보유TF
         , eb_scu_pss_tf                          -- 채무증권보유TF
         , eni_scu_pss_tf                         -- 수익증권보유TF
         , ivs_are_scu_pss_tf                     -- 투자계약증권보유TF
         , drb_cmb_scu_pss_tf                     -- 파생결합증권보유TF
         , scu_msd_scu_pss_tf                     -- 증권예탁증권보유TF
         , mont_ase_pss_tf                        -- 금전자산보유TF
         , pnz_pd_pss_tf                          -- 연금상품보유TF
         , iu_pd_pss_tf                           -- 보험상품보유TF
         , crd_pd_pss_tf                          -- 카드상품보유TF
         , shb_liq_pd_cn                          -- 신한은행유동성상품수
         , shb_sav_pd_cn                          -- 신한은행예금상품수
         , shb_issv_pd_cn                         -- 신한은행적금상품수
         , shb_trt_pd_cn                          -- 신한은행신탁상품수
         , shb_fud_pd_cn                          -- 신한은행펀드상품수
         , shb_rtr_pnz_pd_cn                      -- 신한은행퇴직연금상품수
         , shb_pnz_trt_pd_cn                      -- 신한은행연금신탁상품수
         , shb_hsg_ll_ln_pd_cn                    -- 신한은행주택담보대출상품수
         , shb_leh_mny_ln_pd_cn                   -- 신한은행전세자금대출상품수
         , shb_cre_ln_pd_cn                       -- 신한은행신용대출상품수
         , shb_fnn_pd_ll_ln_pd_cn                 -- 신한은행금융상품담보대출상품수
         , shb_eco_ln_pd_cn                       -- 신한은행기업대출상품수
         , shb_et_ln_pd_cn                        -- 신한은행기타대출상품수
         , shb_psn_etk_ln_pd_cn                   -- 신한은행개인사업자대출상품수
         , shb_et_esa_ln_pd_cn                    -- 신한은행기타부동산대출상품수
         , shb_car_ln_pd_cn                       -- 신한은행자동차대출상품수
         , pss_iu_cn                              -- 보유보험수
         , pss_crd_cn                             -- 보유카드수
         )
    -- 카드
    select ta_ym
         , sgdmd
         , '0'                                        as mrp_pd_pss_tf              -- 입출금상품보유TF
         , '0'                                        as sai_pd_pss_tf              -- 예적금상품보유TF
         , case when a_yn + b_yn + c_yn > 0
                then '1'
                else '0'
            end                                       as ln_pd_pss_tf               -- 대출상품보유TF
         , '0'                                        as ivs_pd_pss_tf              -- 투자상품보유TF
         , '0'                                        as pot_scu_pss_tf             -- 지분증권보유TF
         , '0'                                        as eb_scu_pss_tf              -- 채무증권보유TF
         , '0'                                        as eni_scu_pss_tf             -- 수익증권보유TF
         , '0'                                        as ivs_are_scu_pss_tf         -- 투자계약증권보유TF
         , '0'                                        as drb_cmb_scu_pss_tf         -- 파생결합증권보유TF
         , '0'                                        as scu_msd_scu_pss_tf         -- 증권예탁증권보유TF
         , '0'                                        as mont_ase_pss_tf            -- 금전자산보유TF
         , '0'                                        as pnz_pd_pss_tf              -- 연금상품보유TF
         , '0'                                        as iu_pd_pss_tf               -- 보험상품보유TF
         , max(d_yn)                                  as crd_pd_pss_tf              -- 카드상품보유TF
         , 0                                          as shb_liq_pd_cn              -- 신한은행유동성상품수
         , 0                                          as shb_sav_pd_cn              -- 신한은행예금상품수
         , 0                                          as shb_issv_pd_cn             -- 신한은행적금상품수
         , 0                                          as shb_trt_pd_cn              -- 신한은행신탁상품수
         , 0                                          as shb_fud_pd_cn              -- 신한은행펀드상품수
         , 0                                          as shb_rtr_pnz_pd_cn          -- 신한은행퇴직연금상품수
         , 0                                          as shb_pnz_trt_pd_cn          -- 신한은행연금신탁상품수
         , 0                                          as shb_hsg_ll_ln_pd_cn        -- 신한은행주택담보대출상품수
         , 0                                          as shb_leh_mny_ln_pd_cn       -- 신한은행전세자금대출상품수
         , 0                                          as shb_cre_ln_pd_cn           -- 신한은행신용대출상품수
         , 0                                          as shb_fnn_pd_ll_ln_pd_cn     -- 신한은행금융상품담보대출상품수
         , 0                                          as shb_eco_ln_pd_cn           -- 신한은행기업대출상품수
         , 0                                          as shb_et_ln_pd_cn            -- 신한은행기타대출상품수
         , 0                                          as shb_psn_etk_ln_pd_cn       -- 신한은행개인사업자대출상품수
         , 0                                          as shb_et_esa_ln_pd_cn        -- 신한은행기타부동산대출상품수
         , 0                                          as shb_car_ln_pd_cn           -- 신한은행자동차대출상품수
         , 0                                          as pss_iu_cn                  -- 보유보험수
         , max(a_cnt)                                 as pss_crd_cn                 -- 보유카드수
      from (select ta_ym
                 , sgdmd
                 , case when count(crd_rpl_n) > 0                                   -- 카드대체번호
                        then '1'
                        else '0'
                    end                               as a_yn                       -- 현금서비스상품보유여부
                 , '0'                                as b_yn                       -- 론대출상품보유여부
                 , '0'                                as c_yn                       -- 카드대출상품보유여부
                 , '0'                                as d_yn                       -- 카드상품보유여부 --실질카드
                 , 0                                  as a_cnt                      -- 보유카드수
              from shc.mtfua0002                                                    -- (월카드매출)
             where ta_ym = '{date_cd('P_TA_YM')}'
               and (cv_hga > 0                                                      -- 현금서비스취급금액
                  or
                    vv_cv_hga > 0                                                   -- 리볼빙현금서비스취급금액
                   )
             group by ta_ym
                    , sgdmd
             union all
            select ta_ym
                 , sgdmd
                 , '0'                                as a_yn                       -- 현금서비스상품보유여부
                 , case when count(sls_ts_n) > 0                                    -- 매출거래번호
                        then '1'
                        else '0'
                    end                               as b_yn                       -- 론대출상품보유여부
                 , '0'                                as c_yn                       -- 카드대출상품보유여부
                 , '0'                                as d_yn                       -- 카드상품보유여부 --실질카드
                 , 0                                  as a_cnt                      -- 보유카드수
              from shc.swoac0019                                                    -- (월론대출)
             where ta_ym = '{date_cd('P_TA_YM')}'
               and lln_al >  0                                                      -- 론대출잔액
               and lln_pyf_d is null                                                -- 론대출완납일자
             group by ta_ym
                    , sgdmd
             union all
            select ta_ym
                 , sgdmd
                 , '0'                                as a_yn                       -- 현금서비스상품보유여부
                 , '0'                                as b_yn                       -- 론대출상품보유여부
                 , case when count(ln_n) > 0                                        -- 대출번호
                        then '1'
                        else '0'
                    end                               as c_yn                       -- 카드대출상품보유여부
                 , '0'                                as d_yn                       -- 카드상품보유여부 --실질카드
                 , 0                                  as a_cnt                      -- 보유카드수
              from shc.swoac0020                                                    -- (월오토금융대출)
             where ta_ym = '{date_cd('P_TA_YM')}'
               and pyf_tf = '0'                                                     -- 완납tf
             group by ta_ym
                    , sgdmd
             union all
            select ta_ym
                 , sgdmd
                 , '0'                                as a_yn                       -- 현금서비스상품보유여부
                 , '0'                                as b_yn                       -- 론대출상품보유여부
                 , '0'                                as c_yn                       -- 카드대출상품보유여부
                 , max(case when crd_su_tcd = 'S'
                            then '1'
                            else '0'
                        end)                          as d_yn                       -- 카드상품보유여부 --실질카드
                 , 0                                  as a_cnt                      -- 보유카드수
              from shc.mtdia0001                                                    -- (월카드디멘젼) <mtdia5008 매핑>
             where ta_ym = '{date_cd('P_TA_YM')}'
             group by ta_ym
                    , sgdmd
             union all
            select ta_ym
                 , shmdn                              as sgdmd
                 , '0'                                as a_yn                       -- 현금서비스상품보유여부
                 , '0'                                as b_yn                       -- 론대출상품보유여부
                 , '0'                                as c_yn                       -- 카드대출상품보유여부
                 , '0'                                as d_yn                       -- 카드상품보유여부 --실질카드
                 , nvl(count(distinct crd_rpl_n),0)   as a_cnt                      -- 보유카드수
              from sh1.shcmpdt001
             where ta_ym = '{date_cd('P_TA_YM')}'
             group by ta_ym
                    , shmdn
            )
      group by ta_ym
             , sgdmd
             , case when a_yn + b_yn + c_yn > 0
                    then '1'
                    else '0'
                end
"""

insert_sql_for_tmp_3 = f"""
    insert into tmp_sh2.shdmigd003_tmp03
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , mrp_pd_pss_tf                          -- 입출금상품보유TF
         , sai_pd_pss_tf                          -- 예적금상품보유TF
         , ln_pd_pss_tf                           -- 대출상품보유TF
         , ivs_pd_pss_tf                          -- 투자상품보유TF
         , pot_scu_pss_tf                         -- 지분증권보유TF
         , eb_scu_pss_tf                          -- 채무증권보유TF
         , eni_scu_pss_tf                         -- 수익증권보유TF
         , ivs_are_scu_pss_tf                     -- 투자계약증권보유TF
         , drb_cmb_scu_pss_tf                     -- 파생결합증권보유TF
         , scu_msd_scu_pss_tf                     -- 증권예탁증권보유TF
         , mont_ase_pss_tf                        -- 금전자산보유TF
         , pnz_pd_pss_tf                          -- 연금상품보유TF
         , iu_pd_pss_tf                           -- 보험상품보유TF
         , crd_pd_pss_tf                          -- 카드상품보유TF
         , shb_liq_pd_cn                          -- 신한은행유동성상품수
         , shb_sav_pd_cn                          -- 신한은행예금상품수
         , shb_issv_pd_cn                         -- 신한은행적금상품수
         , shb_trt_pd_cn                          -- 신한은행신탁상품수
         , shb_fud_pd_cn                          -- 신한은행펀드상품수
         , shb_rtr_pnz_pd_cn                      -- 신한은행퇴직연금상품수
         , shb_pnz_trt_pd_cn                      -- 신한은행연금신탁상품수
         , shb_hsg_ll_ln_pd_cn                    -- 신한은행주택담보대출상품수
         , shb_leh_mny_ln_pd_cn                   -- 신한은행전세자금대출상품수
         , shb_cre_ln_pd_cn                       -- 신한은행신용대출상품수
         , shb_fnn_pd_ll_ln_pd_cn                 -- 신한은행금융상품담보대출상품수
         , shb_eco_ln_pd_cn                       -- 신한은행기업대출상품수
         , shb_et_ln_pd_cn                        -- 신한은행기타대출상품수
         , shb_psn_etk_ln_pd_cn                   -- 신한은행개인사업자대출상품수
         , shb_et_esa_ln_pd_cn                    -- 신한은행기타부동산대출상품수
         , shb_car_ln_pd_cn                       -- 신한은행자동차대출상품수
         , pss_iu_cn                              -- 보유보험수
         , pss_crd_cn                             -- 보유카드수
         )
    -- 금투
    select substring(base_ymd,1,6)          as ta_ym                   -- 기준년월
         , grp_md_no                        as shmdn                   -- 그룹MD번호
         , '0'                              as mrp_pd_pss_tf           -- 입출금상품보유TF
         , '0'                              as sai_pd_pss_tf           -- 예적금상품보유TF
         , '0'                              as ln_pd_pss_tf            -- 대출상품보유TF
         , max(case when secr_evlt_amt > 0
                    then '1'
                    else '0'
                end)                        as ivs_pd_pss_tf           -- 투자상품보유TF
         , max(case when shar_secr_evlt_amt > 0
                    then '1'
                    else '0'
                end)                        as pot_scu_pss_tf          -- 지분증권보유TF
         , max(case when libt_secr_evlt_amt > 0
                    then '1'
                    else '0'
                end)                        as eb_scu_pss_tf           -- 채무증권보유TF
         , max(case when bncert_evlt_amt > 0
                    then '1'
                    else '0'
                end)                        as eni_scu_pss_tf          -- 수익증권보유TF
         , max(case when invt_cntc_secr_evlt_amt > 0
                    then '1'
                    else '0'
                end)                        as ivs_are_scu_pss_tf      -- 투자계약증권보유TF
         , max(case when drv_join_secr_evlt_amt > 0
                    then '1'
                    else '0'
                end)                        as drb_cmb_scu_pss_tf      -- 파생결합증권보유TF
         , max(case when secr_dpst_secr_evlt_amt > 0
                    then '1'
                    else '0'
                end)                        as scu_msd_scu_pss_tf      -- 증권예탁증권보유TF
         , max(case when buln_bf_evlt_amt > 0
                    then '1'
                    else '0'
                end)                        as mont_ase_pss_tf         -- 금전자산보유TF
         , '0'                              as pnz_pd_pss_tf           -- 연금상품보유TF
         , '0'                              as iu_pd_pss_tf            -- 보험상품보유TF
         , '0'                              as crd_pd_pss_tf           -- 카드상품보유TF
         , 0                                as shb_liq_pd_cn           -- 신한은행유동성상품수
         , 0                                as shb_sav_pd_cn           -- 신한은행예금상품수
         , 0                                as shb_issv_pd_cn          -- 신한은행적금상품수
         , 0                                as shb_trt_pd_cn           -- 신한은행신탁상품수
         , 0                                as shb_fud_pd_cn           -- 신한은행펀드상품수
         , 0                                as shb_rtr_pnz_pd_cn       -- 신한은행퇴직연금상품수
         , 0                                as shb_pnz_trt_pd_cn       -- 신한은행연금신탁상품수
         , 0                                as shb_hsg_ll_ln_pd_cn     -- 신한은행주택담보대출상품수
         , 0                                as shb_leh_mny_ln_pd_cn    -- 신한은행전세자금대출상품수
         , 0                                as shb_cre_ln_pd_cn        -- 신한은행신용대출상품수
         , 0                                as shb_fnn_pd_ll_ln_pd_cn  -- 신한은행금융상품담보대출상품수
         , 0                                as shb_eco_ln_pd_cn        -- 신한은행기업대출상품수
         , 0                                as shb_et_ln_pd_cn         -- 신한은행기타대출상품수
         , 0                                as shb_psn_etk_ln_pd_cn    -- 신한은행개인사업자대출상품수
         , 0                                as shb_et_esa_ln_pd_cn     -- 신한은행기타부동산대출상품수
         , 0                                as shb_car_ln_pd_cn        -- 신한은행자동차대출상품수
         , 0                                as pss_iu_cn               -- 보유보험수
         , 0                                as pss_crd_cn              -- 보유카드수
      from shi.jdc201s00
     where base_ymd = {date_cd('P_TA_YM')}||'31'                     /*해당년월말일기준*/
     group by substring(base_ymd,1,6)
            , grp_md_no
"""

insert_sql_for_tmp_4 = f"""
    insert into tmp_sh2.shdmigd003_tmp04
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , mrp_pd_pss_tf                          -- 입출금상품보유TF
         , sai_pd_pss_tf                          -- 예적금상품보유TF
         , ln_pd_pss_tf                           -- 대출상품보유TF
         , ivs_pd_pss_tf                          -- 투자상품보유TF
         , pot_scu_pss_tf                         -- 지분증권보유TF
         , eb_scu_pss_tf                          -- 채무증권보유TF
         , eni_scu_pss_tf                         -- 수익증권보유TF
         , ivs_are_scu_pss_tf                     -- 투자계약증권보유TF
         , drb_cmb_scu_pss_tf                     -- 파생결합증권보유TF
         , scu_msd_scu_pss_tf                     -- 증권예탁증권보유TF
         , mont_ase_pss_tf                        -- 금전자산보유TF
         , pnz_pd_pss_tf                          -- 연금상품보유TF
         , iu_pd_pss_tf                           -- 보험상품보유TF
         , crd_pd_pss_tf                          -- 카드상품보유TF
         , shb_liq_pd_cn                          -- 신한은행유동성상품수
         , shb_sav_pd_cn                          -- 신한은행예금상품수
         , shb_issv_pd_cn                         -- 신한은행적금상품수
         , shb_trt_pd_cn                          -- 신한은행신탁상품수
         , shb_fud_pd_cn                          -- 신한은행펀드상품수
         , shb_rtr_pnz_pd_cn                      -- 신한은행퇴직연금상품수
         , shb_pnz_trt_pd_cn                      -- 신한은행연금신탁상품수
         , shb_hsg_ll_ln_pd_cn                    -- 신한은행주택담보대출상품수
         , shb_leh_mny_ln_pd_cn                   -- 신한은행전세자금대출상품수
         , shb_cre_ln_pd_cn                       -- 신한은행신용대출상품수
         , shb_fnn_pd_ll_ln_pd_cn                 -- 신한은행금융상품담보대출상품수
         , shb_eco_ln_pd_cn                       -- 신한은행기업대출상품수
         , shb_et_ln_pd_cn                        -- 신한은행기타대출상품수
         , shb_psn_etk_ln_pd_cn                   -- 신한은행개인사업자대출상품수
         , shb_et_esa_ln_pd_cn                    -- 신한은행기타부동산대출상품수
         , shb_car_ln_pd_cn                       -- 신한은행자동차대출상품수
         , pss_iu_cn                              -- 보유보험수
         , pss_crd_cn                             -- 보유카드수
         )
    -- 라이프
    select t10.ta_ym
         , t10.shmdn
         , '0'                                        as mrp_pd_pss_tf          -- 입출금상품보유TF
         , '0'                                        as sai_pd_pss_tf          -- 예적금상품보유TF
         , case when t10.d_cnt > 0
                then '1'
                else '0'
            end                                       as ln_pd_pss_tf           -- 대출상품보유TF
         , '0'                                        as ivs_pd_pss_tf          -- 투자상품보유TF
         , '0'                                        as pot_scu_pss_tf         -- 지분증권보유TF
         , '0'                                        as eb_scu_pss_tf          -- 채무증권보유TF
         , '0'                                        as eni_scu_pss_tf         -- 수익증권보유TF
         , '0'                                        as ivs_are_scu_pss_tf     -- 투자계약증권보유TF
         , '0'                                        as drb_cmb_scu_pss_tf     -- 파생결합증권보유TF
         , '0'                                        as scu_msd_scu_pss_tf     -- 증권예탁증권보유TF
         , '0'                                        as mont_ase_pss_tf        -- 금전자산보유TF
         , case when t10.b_cnt > 0
                then '1'
                else '0'
            end                                       as pnz_pd_pss_tf          -- 연금상품보유TF
         , case when (t10.a_yn> 0 or t10.b_yn > 0)
                then '1'
                else '0'
            end                                       as iu_pd_pss_tf           -- 보험상품보유TF
         , '0'                                        as crd_pd_pss_tf          -- 카드상품보유TF
         , 0                                          as shb_liq_pd_cn          -- 신한은행유동성상품수
         , 0                                          as shb_sav_pd_cn          -- 신한은행예금상품수
         , 0                                          as shb_issv_pd_cn         -- 신한은행적금상품수
         , 0                                          as shb_trt_pd_cn          -- 신한은행신탁상품수
         , 0                                          as shb_fud_pd_cn          -- 신한은행펀드상품수
         , 0                                          as shb_rtr_pnz_pd_cn      -- 신한은행퇴직연금상품수
         , 0                                          as shb_pnz_trt_pd_cn      -- 신한은행연금신탁상품수
         , 0                                          as shb_hsg_ll_ln_pd_cn    -- 신한은행주택담보대출상품수
         , 0                                          as shb_leh_mny_ln_pd_cn   -- 신한은행전세자금대출상품수
         , 0                                          as shb_cre_ln_pd_cn       -- 신한은행신용대출상품수
         , 0                                          as shb_fnn_pd_ll_ln_pd_cn -- 신한은행금융상품담보대출상품수
         , 0                                          as shb_eco_ln_pd_cn       -- 신한은행기업대출상품수
         , 0                                          as shb_et_ln_pd_cn        -- 신한은행기타대출상품수
         , 0                                          as shb_psn_etk_ln_pd_cn   -- 신한은행개인사업자대출상품수
         , 0                                          as shb_et_esa_ln_pd_cn    -- 신한은행기타부동산대출상품수
         , 0                                          as shb_car_ln_pd_cn       -- 신한은행자동차대출상품수
         , sum(t10.a_yn + t10.b_yn)                   as pss_iu_cn              -- 보유보험수
         , 0                                          as pss_crd_cn             -- 보유카드수
      from (select t20.str_ym                             as ta_ym                  -- 기준년월
                 , t20.coor_cs_no                         as shmdn                  -- 그룹MD번호
                 , case when t20.ins_sbsn_good_smcl_cd = '06'
                        then 'L18'                                                  -- '변액보험'
                        when t20.ins_sbsn_good_lrcl_cd = '01'
                        then 'L11'                                                  -- '건강보험'
                        when t20.ins_sbsn_good_lrcl_cd = '05'
                        then 'L12'                                                  -- '상해보험'
                        when t20.ins_sbsn_good_lrcl_cd = '07'
                        then 'L13'                                                  -- '양로보험'
                        when t20.ins_sbsn_good_lrcl_cd = '08'
                        then 'L14'                                                  -- '어린이보험'
                        when t20.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then 'L15'                                                  -- '연금/저축/교육보험'
                        when t20.ins_sbsn_good_lrcl_cd = '12'
                        then 'L16'                                                  -- '종신보험'
                        when t20.ins_sbsn_good_lrcl_cd = '13'
                        then 'L17'                                                  -- '종합보험'
                        when t20.ins_sbsn_good_lrcl_cd = '11'
                        then 'L19'                                                  -- '제휴보험'
                        else 'L1Z'                                                  -- '기타보험'
                    end                                   as good_cd                -- SHD_PD_ZCD (데이터댐상품분류코드)
                 , nvl(sum(case when ctst_cd = 'A'
                                then 1
                                else 0
                            end)
                          ,0)                             as a_yn                   -- 유지계약여부
                 , nvl(sum(case when ctst_cd = 'A'
                                then cmip
                                else 0
                            end)
                          ,0)                             as a_cmip                 -- 유지계약cmip
                 , nvl(sum(case when ctst_cd = 'C'
                                then 1
                                else 0
                            end)
                          ,0)                             as b_yn                   -- 실효계약여부
                 , nvl(sum(case when ctst_cd = 'C'
                                then cmip
                                else 0
                            end)
                          ,0)                             as b_cmip                 -- 실효계약cmip
                 , nvl(sum(case when t22.fur_rs_cd = 'BA'
                                then 1
                                else 0
                            end)
                          ,0)                             as a_cnt                  -- 보험금청구건수
                 , nvl(sum(case when t22.fur_rs_cd = 'BA'
                                then t22.fur_am
                                else 0
                            end)
                          ,0)                             as a_amt                  -- 보험금청구금액
                 , nvl(sum(case when t22.fur_rs_cd = 'AG'
                                then 1
                                else 0
                            end)
                          ,0)                             as b_cnt                  -- 연금건수
                 , nvl(sum(case when t22.fur_rs_cd = 'AG'
                                then t22.fur_am
                                else 0
                            end)
                          ,0)                             as b_amt                  -- 연금금액
                 , nvl(sum(case when t22.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                                then 1
                                else 0
                            end)
                          ,0)                             as c_cnt                  -- 기타제지급건수
                 , nvl(sum(case when t22.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                                then t22.fur_am
                                else 0
                            end)
                          ,0)                             as c_amt                  -- 기타제지급금액
                 , nvl(sum(t24.cnt),0)                    as d_cnt                  -- 대출건수
                 , nvl(sum(t24.pllo_am),0)                as d_amt                  -- 대출금액
                 , nvl(sum(t24.inon_lrem_am),0)           as d_al                   -- 대출잔액
              from shl.dm_mthl_con           t20           --dm_월별계약
             inner join
                   shl.dm_mthl_con_anx_info  t21           --dm_월별계약부가정보
                on t20.str_ym  = t21.str_ym
               and t20.inon_no = t21.inon_no
              left outer join
                  (select substring(cc.tra_ymd,1,6)       as tra_ym
--                          to_char(cc.tra_ymd,'yyyymm')  as tra_ym
                        , cc.inon_no
                        , cc.fur_rs_cd
                        , sum(cc.fur_am)                  as fur_am
                     from shl.dm_py_det cc            -- 지급상세
                    where fur_can_sc_cd = '00'        -- 정상
                      and substring(cc.tra_ymd,1,6) = '{date_cd('P_TA_YM')}'
                    group by substring(cc.tra_ymd,1,6)
                           , cc.inon_no
                           , cc.fur_rs_cd
                   )                         t22
                on t20.str_ym  = t22.tra_ym
               and t20.inon_no = t22.inon_no
              left outer join
                  (select dd.cd_vldt_valu
                        , dd.cd_vldt_valu_nm
                     from shl.zt_unfc_cd_det       dd
                    where dd.unfc_cd_id = 'FUR_RS_CD'    --지급사유코드
                  )                          t23
                on t22.fur_rs_cd = t23.cd_vldt_valu
              left outer join
                  (select ee.str_ym
                        , ee.inon_no
                        , 1                             as cnt
                        , ee.pllo_am
                        , ee.inon_lrem_am
                     from shl.dm_pllo              ee
                    where ee.str_ym = '{date_cd('P_TA_YM')}'
                      and ee.inon_lon_kd_cd = '1'        --일반대출
                   )                         t24
                on t20.str_ym          = t24.str_ym
               and t20.inon_no         = t24.inon_no
             where t20.str_ym          = '{date_cd('P_TA_YM')}'
               and t20.indv_asct_sc_cd = '01'                --개인
             group by t20.str_ym
                    , t20.coor_cs_no                           --계약자고객번호
                    , case when t20.ins_sbsn_good_smcl_cd = '06'
                           then 'L18'                               -- '변액보험'
                           when t20.ins_sbsn_good_lrcl_cd = '01'
                           then 'L11'                               -- '건강보험'
                           when t20.ins_sbsn_good_lrcl_cd = '05'
                           then 'L12'                               -- '상해보험'
                           when t20.ins_sbsn_good_lrcl_cd = '07'
                           then 'L13'                               -- '양로보험'
                           when t20.ins_sbsn_good_lrcl_cd = '08'
                           then 'L14'                               -- '어린이보험'
                           when t20.ins_sbsn_good_lrcl_cd in ('09','10','02')
                           then 'L15'                               -- '연금/저축/교육보험'
                           when t20.ins_sbsn_good_lrcl_cd = '12'
                           then 'L16'                               -- '종신보험'
                           when t20.ins_sbsn_good_lrcl_cd = '13'
                           then 'L17'                               -- '종합보험'
                           when t20.ins_sbsn_good_lrcl_cd = '11'
                           then 'L19'                               -- '제휴보험'
                           else 'L1Z'                               -- '기타보험'
                       end
                union all
            select t20.clos_ym                            as ta_ym
                 , t20.cs_no                              as shmdn
                 , case when t20.lnco_sc_cd = '10'
                        then 'L21'                                                  -- '신용대출'
                        when t20.lnco_sc_cd = '20'
                        then 'L22'                                                  -- '부동산담보대출'
                        else 'L2Z'                                                  -- '기타담보대출'
                    end                                   as good_cd                -- SHD_PD_ZCD (데이터댐상품분류코드)
                  , 0                                     as a_yn                   -- 유지계약여부
                  , 0                                     as a_cmip                 -- 유지계약cmip
                  , 0                                     as b_yn                   -- 실효계약여부
                  , 0                                     as b_cmip                 -- 실효계약cmip
                  , 0                                     as a_cnt                  -- 보험금청구건수
                  , 0                                     as a_amt                  -- 보험금청구금액
                  , 0                                     as b_cnt                  -- 연금건수
                  , 0                                     as b_amt                  -- 연금금액
                  , 0                                     as c_cnt                  -- 기타제지급건수
                  , 0                                     as c_amt                  -- 기타제지급금액
                  , count(t20.lnco_no)                    as d_cnt                  -- 대출건수
                  , sum(t20.lon_am)                       as d_amt                  -- 대출금액
                  , sum(t20.lrem_am)                      as d_al                   -- 대출잔액
               from shl.fn_mmln                t20                                  -- fn_대출월마감
              where t20.clos_ym    = '{date_cd('P_TA_YM')}'
                and t20.lnco_sc_cd = '10' --개인
              group by t20.clos_ym
                     , t20.cs_no
                     , case when t20.lnco_sc_cd = '10'
                            then 'L21'                                              -- '신용대출'
                            when t20.lnco_sc_cd = '20'
                            then 'L22'                                              -- '부동산담보대출'
                            else 'L2Z'                                              -- '기타담보대출'
                        end
           ) t10
       group by t10.ta_ym
              , t10.shmdn
              , case when t10.d_cnt > 0
                     then '1'
                     else '0'
                 end
              , case when t10.b_cnt > 0
                     then '1'
                     else '0'
                 end
              , case when (t10.a_yn> 0 or t10.b_yn > 0)
                     then '1'
                     else '0'
                 end
"""

insert_sql_for_tmp_5 = f"""
    insert into tmp_sh2.shdmigd003_tmp99
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- aws적재일시
         , mrp_pd_pss_tf                          -- 입출금상품보유TF
         , sai_pd_pss_tf                          -- 예적금상품보유TF
         , ln_pd_pss_tf                           -- 대출상품보유TF
         , ivs_pd_pss_tf                          -- 투자상품보유TF
         , pot_scu_pss_tf                         -- 지분증권보유TF
         , eb_scu_pss_tf                          -- 채무증권보유TF
         , eni_scu_pss_tf                         -- 수익증권보유TF
         , ivs_are_scu_pss_tf                     -- 투자계약증권보유TF
         , drb_cmb_scu_pss_tf                     -- 파생결합증권보유TF
         , scu_msd_scu_pss_tf                     -- 증권예탁증권보유TF
         , mont_ase_pss_tf                        -- 금전자산보유TF
         , pnz_pd_pss_tf                          -- 연금상품보유TF
         , iu_pd_pss_tf                           -- 보험상품보유TF
         , crd_pd_pss_tf                          -- 카드상품보유TF
         , shb_liq_pd_cn                          -- 신한은행유동성상품수
         , shb_sav_pd_cn                          -- 신한은행예금상품수
         , shb_issv_pd_cn                         -- 신한은행적금상품수
         , shb_trt_pd_cn                          -- 신한은행신탁상품수
         , shb_fud_pd_cn                          -- 신한은행펀드상품수
         , shb_rtr_pnz_pd_cn                      -- 신한은행퇴직연금상품수
         , shb_pnz_trt_pd_cn                      -- 신한은행연금신탁상품수
         , shb_hsg_ll_ln_pd_cn                    -- 신한은행주택담보대출상품수
         , shb_leh_mny_ln_pd_cn                   -- 신한은행전세자금대출상품수
         , shb_cre_ln_pd_cn                       -- 신한은행신용대출상품수
         , shb_fnn_pd_ll_ln_pd_cn                 -- 신한은행금융상품담보대출상품수
         , shb_eco_ln_pd_cn                       -- 신한은행기업대출상품수
         , shb_et_ln_pd_cn                        -- 신한은행기타대출상품수
         , shb_psn_etk_ln_pd_cn                   -- 신한은행개인사업자대출상품수
         , shb_et_esa_ln_pd_cn                    -- 신한은행기타부동산대출상품수
         , shb_car_ln_pd_cn                       -- 신한은행자동차대출상품수
         , pss_iu_cn                              -- 보유보험수
         , pss_crd_cn                             -- 보유카드수
         )
    -- 통합
    select ta_ym                                                                    -- 기준년월
         , shmdn                                                                    -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'  as aws_ld_dt                -- aws적재일시
         , max(mrp_pd_pss_tf)                         as mrp_pd_pss_tf              -- 입출금상품보유TF
         , max(sai_pd_pss_tf)                         as sai_pd_pss_tf              -- 예적금상품보유TF
         , max(ln_pd_pss_tf)                          as ln_pd_pss_tf               -- 대출상품보유TF
         , max(ivs_pd_pss_tf)                         as ivs_pd_pss_tf              -- 투자상품보유TF
         , max(pot_scu_pss_tf)                        as pot_scu_pss_tf             -- 지분증권보유TF
         , max(eb_scu_pss_tf)                         as eb_scu_pss_tf              -- 채무증권보유TF
         , max(eni_scu_pss_tf)                        as eni_scu_pss_tf             -- 수익증권보유TF
         , max(ivs_are_scu_pss_tf)                    as ivs_are_scu_pss_tf         -- 투자계약증권보유TF
         , max(drb_cmb_scu_pss_tf)                    as drb_cmb_scu_pss_tf         -- 파생결합증권보유TF
         , max(scu_msd_scu_pss_tf)                    as scu_msd_scu_pss_tf         -- 증권예탁증권보유TF
         , max(mont_ase_pss_tf)                       as mont_ase_pss_tf            -- 금전자산보유TF
         , max(pnz_pd_pss_tf)                         as pnz_pd_pss_tf              -- 연금상품보유TF
         , max(iu_pd_pss_tf)                          as iu_pd_pss_tf               -- 보험상품보유TF
         , max(crd_pd_pss_tf)                         as crd_pd_pss_tf              -- 카드상품보유TF
         , max(shb_liq_pd_cn)                         as shb_liq_pd_cn              -- 신한은행유동성상품수
         , max(shb_sav_pd_cn)                         as shb_sav_pd_cn              -- 신한은행예금상품수
         , max(shb_issv_pd_cn)                        as shb_issv_pd_cn             -- 신한은행적금상품수
         , max(shb_trt_pd_cn)                         as shb_trt_pd_cn              -- 신한은행신탁상품수
         , max(shb_fud_pd_cn)                         as shb_fud_pd_cn              -- 신한은행펀드상품수
         , max(shb_rtr_pnz_pd_cn)                     as shb_rtr_pnz_pd_cn          -- 신한은행퇴직연금상품수
         , max(shb_pnz_trt_pd_cn)                     as shb_pnz_trt_pd_cn          -- 신한은행연금신탁상품수
         , max(shb_hsg_ll_ln_pd_cn)                   as shb_hsg_ll_ln_pd_cn        -- 신한은행주택담보대출상품수
         , max(shb_leh_mny_ln_pd_cn)                  as shb_leh_mny_ln_pd_cn       -- 신한은행전세자금대출상품수
         , max(shb_cre_ln_pd_cn)                      as shb_cre_ln_pd_cn           -- 신한은행신용대출상품수
         , max(shb_fnn_pd_ll_ln_pd_cn)                as shb_fnn_pd_ll_ln_pd_cn     -- 신한은행금융상품담보대출상품수
         , max(shb_eco_ln_pd_cn)                      as shb_eco_ln_pd_cn           -- 신한은행기업대출상품수
         , max(shb_et_ln_pd_cn)                       as shb_et_ln_pd_cn            -- 신한은행기타대출상품수
         , max(shb_psn_etk_ln_pd_cn)                  as shb_psn_etk_ln_pd_cn       -- 신한은행개인사업자대출상품수
         , max(shb_et_esa_ln_pd_cn)                   as shb_et_esa_ln_pd_cn        -- 신한은행기타부동산대출상품수
         , max(shb_car_ln_pd_cn)                      as shb_car_ln_pd_cn           -- 신한은행자동차대출상품수
         , max(pss_iu_cn)                             as pss_iu_cn                  -- 보유보험수
         , max(pss_crd_cn)                            as pss_crd_cn                 -- 보유카드수
      from (select ta_ym
                 , shmdn
                 , mrp_pd_pss_tf
                 , sai_pd_pss_tf
                 , ln_pd_pss_tf
                 , ivs_pd_pss_tf
                 , pot_scu_pss_tf
                 , eb_scu_pss_tf
                 , eni_scu_pss_tf
                 , ivs_are_scu_pss_tf
                 , drb_cmb_scu_pss_tf
                 , scu_msd_scu_pss_tf
                 , mont_ase_pss_tf
                 , pnz_pd_pss_tf
                 , iu_pd_pss_tf
                 , crd_pd_pss_tf
                 , shb_liq_pd_cn
                 , shb_sav_pd_cn
                 , shb_issv_pd_cn
                 , shb_trt_pd_cn
                 , shb_fud_pd_cn
                 , shb_rtr_pnz_pd_cn
                 , shb_pnz_trt_pd_cn
                 , shb_hsg_ll_ln_pd_cn
                 , shb_leh_mny_ln_pd_cn
                 , shb_cre_ln_pd_cn
                 , shb_fnn_pd_ll_ln_pd_cn
                 , shb_eco_ln_pd_cn
                 , shb_et_ln_pd_cn
                 , shb_psn_etk_ln_pd_cn
                 , shb_et_esa_ln_pd_cn
                 , shb_car_ln_pd_cn
                 , pss_iu_cn
                 , pss_crd_cn
              from tmp_sh2.shdmigd003_tmp01
             union all
            select ta_ym
                 , shmdn
                 , mrp_pd_pss_tf
                 , sai_pd_pss_tf
                 , ln_pd_pss_tf
                 , ivs_pd_pss_tf
                 , pot_scu_pss_tf
                 , eb_scu_pss_tf
                 , eni_scu_pss_tf
                 , ivs_are_scu_pss_tf
                 , drb_cmb_scu_pss_tf
                 , scu_msd_scu_pss_tf
                 , mont_ase_pss_tf
                 , pnz_pd_pss_tf
                 , iu_pd_pss_tf
                 , crd_pd_pss_tf
                 , shb_liq_pd_cn
                 , shb_sav_pd_cn
                 , shb_issv_pd_cn
                 , shb_trt_pd_cn
                 , shb_fud_pd_cn
                 , shb_rtr_pnz_pd_cn
                 , shb_pnz_trt_pd_cn
                 , shb_hsg_ll_ln_pd_cn
                 , shb_leh_mny_ln_pd_cn
                 , shb_cre_ln_pd_cn
                 , shb_fnn_pd_ll_ln_pd_cn
                 , shb_eco_ln_pd_cn
                 , shb_et_ln_pd_cn
                 , shb_psn_etk_ln_pd_cn
                 , shb_et_esa_ln_pd_cn
                 , shb_car_ln_pd_cn
                 , pss_iu_cn
                 , pss_crd_cn
              from tmp_sh2.shdmigd003_tmp02
             union all
            select ta_ym
                 , shmdn
                 , mrp_pd_pss_tf
                 , sai_pd_pss_tf
                 , ln_pd_pss_tf
                 , ivs_pd_pss_tf
                 , pot_scu_pss_tf
                 , eb_scu_pss_tf
                 , eni_scu_pss_tf
                 , ivs_are_scu_pss_tf
                 , drb_cmb_scu_pss_tf
                 , scu_msd_scu_pss_tf
                 , mont_ase_pss_tf
                 , pnz_pd_pss_tf
                 , iu_pd_pss_tf
                 , crd_pd_pss_tf
                 , shb_liq_pd_cn
                 , shb_sav_pd_cn
                 , shb_issv_pd_cn
                 , shb_trt_pd_cn
                 , shb_fud_pd_cn
                 , shb_rtr_pnz_pd_cn
                 , shb_pnz_trt_pd_cn
                 , shb_hsg_ll_ln_pd_cn
                 , shb_leh_mny_ln_pd_cn
                 , shb_cre_ln_pd_cn
                 , shb_fnn_pd_ll_ln_pd_cn
                 , shb_eco_ln_pd_cn
                 , shb_et_ln_pd_cn
                 , shb_psn_etk_ln_pd_cn
                 , shb_et_esa_ln_pd_cn
                 , shb_car_ln_pd_cn
                 , pss_iu_cn
                 , pss_crd_cn
              from tmp_sh2.shdmigd003_tmp03
             union all
            select ta_ym
                 , shmdn
                 , mrp_pd_pss_tf
                 , sai_pd_pss_tf
                 , ln_pd_pss_tf
                 , ivs_pd_pss_tf
                 , pot_scu_pss_tf
                 , eb_scu_pss_tf
                 , eni_scu_pss_tf
                 , ivs_are_scu_pss_tf
                 , drb_cmb_scu_pss_tf
                 , scu_msd_scu_pss_tf
                 , mont_ase_pss_tf
                 , pnz_pd_pss_tf
                 , iu_pd_pss_tf
                 , crd_pd_pss_tf
                 , shb_liq_pd_cn
                 , shb_sav_pd_cn
                 , shb_issv_pd_cn
                 , shb_trt_pd_cn
                 , shb_fud_pd_cn
                 , shb_rtr_pnz_pd_cn
                 , shb_pnz_trt_pd_cn
                 , shb_hsg_ll_ln_pd_cn
                 , shb_leh_mny_ln_pd_cn
                 , shb_cre_ln_pd_cn
                 , shb_fnn_pd_ll_ln_pd_cn
                 , shb_eco_ln_pd_cn
                 , shb_et_ln_pd_cn
                 , shb_psn_etk_ln_pd_cn
                 , shb_et_esa_ln_pd_cn
                 , shb_car_ln_pd_cn
                 , pss_iu_cn
                 , pss_crd_cn
              from tmp_sh2.shdmigd003_tmp04
            )
        group by ta_ym
               , shmdn
"""

"""
(@) tmp_sh2 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""                     
insert_sql_for_tmp = [insert_sql_for_tmp_1,insert_sql_for_tmp_2,insert_sql_for_tmp_3,insert_sql_for_tmp_4, insert_sql_for_tmp_5]

""" 
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmigd003_tmp99', 'pk': ['ta_ym', 'shmdn']}
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmigd003
    where ta_ym = '{date_cd('P_TA_YM')}'
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shdmigd003
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- aws적재일시
         , mrp_pd_pss_tf                          -- 입출금상품보유TF
         , sai_pd_pss_tf                          -- 예적금상품보유TF
         , ln_pd_pss_tf                           -- 대출상품보유TF
         , ivs_pd_pss_tf                          -- 투자상품보유TF
         , pot_scu_pss_tf                         -- 지분증권보유TF
         , eb_scu_pss_tf                          -- 채무증권보유TF
         , eni_scu_pss_tf                         -- 수익증권보유TF
         , ivs_are_scu_pss_tf                     -- 투자계약증권보유TF
         , drb_cmb_scu_pss_tf                     -- 파생결합증권보유TF
         , scu_msd_scu_pss_tf                     -- 증권예탁증권보유TF
         , mont_ase_pss_tf                        -- 금전자산보유TF
         , pnz_pd_pss_tf                          -- 연금상품보유TF
         , iu_pd_pss_tf                           -- 보험상품보유TF
         , crd_pd_pss_tf                          -- 카드상품보유TF
         , shb_liq_pd_cn                          -- 신한은행유동성상품수
         , shb_sav_pd_cn                          -- 신한은행예금상품수
         , shb_issv_pd_cn                         -- 신한은행적금상품수
         , shb_trt_pd_cn                          -- 신한은행신탁상품수
         , shb_fud_pd_cn                          -- 신한은행펀드상품수
         , shb_rtr_pnz_pd_cn                      -- 신한은행퇴직연금상품수
         , shb_pnz_trt_pd_cn                      -- 신한은행연금신탁상품수
         , shb_hsg_ll_ln_pd_cn                    -- 신한은행주택담보대출상품수
         , shb_leh_mny_ln_pd_cn                   -- 신한은행전세자금대출상품수
         , shb_cre_ln_pd_cn                       -- 신한은행신용대출상품수
         , shb_fnn_pd_ll_ln_pd_cn                 -- 신한은행금융상품담보대출상품수
         , shb_eco_ln_pd_cn                       -- 신한은행기업대출상품수
         , shb_et_ln_pd_cn                        -- 신한은행기타대출상품수
         , shb_psn_etk_ln_pd_cn                   -- 신한은행개인사업자대출상품수
         , shb_et_esa_ln_pd_cn                    -- 신한은행기타부동산대출상품수
         , shb_car_ln_pd_cn                       -- 신한은행자동차대출상품수
         , pss_iu_cn                              -- 보유보험수
         , pss_crd_cn                             -- 보유카드수
         )
    select ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- aws적재일시
         , mrp_pd_pss_tf                          -- 입출금상품보유TF
         , sai_pd_pss_tf                          -- 예적금상품보유TF
         , ln_pd_pss_tf                           -- 대출상품보유TF
         , ivs_pd_pss_tf                          -- 투자상품보유TF
         , pot_scu_pss_tf                         -- 지분증권보유TF
         , eb_scu_pss_tf                          -- 채무증권보유TF
         , eni_scu_pss_tf                         -- 수익증권보유TF
         , ivs_are_scu_pss_tf                     -- 투자계약증권보유TF
         , drb_cmb_scu_pss_tf                     -- 파생결합증권보유TF
         , scu_msd_scu_pss_tf                     -- 증권예탁증권보유TF
         , mont_ase_pss_tf                        -- 금전자산보유TF
         , pnz_pd_pss_tf                          -- 연금상품보유TF
         , iu_pd_pss_tf                           -- 보험상품보유TF
         , crd_pd_pss_tf                          -- 카드상품보유TF
         , shb_liq_pd_cn                          -- 신한은행유동성상품수
         , shb_sav_pd_cn                          -- 신한은행예금상품수
         , shb_issv_pd_cn                         -- 신한은행적금상품수
         , shb_trt_pd_cn                          -- 신한은행신탁상품수
         , shb_fud_pd_cn                          -- 신한은행펀드상품수
         , shb_rtr_pnz_pd_cn                      -- 신한은행퇴직연금상품수
         , shb_pnz_trt_pd_cn                      -- 신한은행연금신탁상품수
         , shb_hsg_ll_ln_pd_cn                    -- 신한은행주택담보대출상품수
         , shb_leh_mny_ln_pd_cn                   -- 신한은행전세자금대출상품수
         , shb_cre_ln_pd_cn                       -- 신한은행신용대출상품수
         , shb_fnn_pd_ll_ln_pd_cn                 -- 신한은행금융상품담보대출상품수
         , shb_eco_ln_pd_cn                       -- 신한은행기업대출상품수
         , shb_et_ln_pd_cn                        -- 신한은행기타대출상품수
         , shb_psn_etk_ln_pd_cn                   -- 신한은행개인사업자대출상품수
         , shb_et_esa_ln_pd_cn                    -- 신한은행기타부동산대출상품수
         , shb_car_ln_pd_cn                       -- 신한은행자동차대출상품수
         , pss_iu_cn                              -- 보유보험수
         , pss_crd_cn                             -- 보유카드수
      from tmp_sh2.shdmigd003_tmp99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh2 = [insert_sql_1]
### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh2_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    tmp_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_tmp_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh2_delete_task = RedshiftQueryOperator(
        task_id='004_sh2_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh2_load_task = [RedshiftQueryOperator(
        task_id='005_sh2_load_task_' + str(insert_sql_for_sh2.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh2]

    task_end = DummyOperator(task_id='task_end')


    # task dependency
    tmp_truncate_task >> tmp_load_task[0]

    for i in range(len(tmp_load_task)-1):
        tmp_load_task[i] >> tmp_load_task[i+1]
    
    tmp_load_task[len(tmp_load_task)-1] >> tmp_load_task_end >> tmp_pk_valid_task >> sh2_delete_task >> sh2_load_task >> task_end
    
    