# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from sgd import config
from sgd import logging
from sgd.utils import *
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator


""" 
(@) 프로그램 ID
"""
pgm_id = 'IBTD_TEST_DUP_TG'

""" 
(@) 한글 프로그램명
"""
description = 'SH1 적재 프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh1'
tmp_schema = 'tmp_sh1'

""" 
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

""" 
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['tmp_sh1_table1', 'tmp_sh1_table2']

""" 
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh1.tmp_sh1_table_1
    select *, sysdate 
    from l0_schema.l0_table
"""

insert_sql_for_tmp_2 = f"""
    insert into tmp_sh1.tmp_sh1_table_2
    select *, sysdate 
    from l0_schema.l0_table
"""

""" 
(@) TMP_SH1 INSERT 쿼리명 리스트 (위에 작성한 쿼리명 나열)
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1, insert_sql_for_tmp_2]

""" 
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shcmtrs003_tmp99', 'pk': ['ta_ym', 'shmdn', 'brn', 'mct_n']},
    1: {'table': 'shcmtrs003_tmp99','pk': ['ta_ym', 'shmdn', 'brn', 'mct_mi_zcd']}
}

""" 
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = ""

""" 
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
# insert_sql_1 = f"""
#     insert into sh1.sh1_dappend_table
#     select *, sysdate
#     from tmp_sh1.tmp_sh1_table_1
# """
# insert_sql_2 = f"""
#     insert into sh1.sh1_dappend_table
#     select *, sysdate
#     from tmp_sh1.tmp_sh1_table_2
# """

""" 
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
# insert_sql_for_sh1 = [insert_sql_1, insert_sql_2]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst' : execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

tags.append('test')

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    # tmp_truncate_task = TmpTruncateOperator(
    #     task_id='tmp_truncate_task',
    #     target_table=tmp_sh1_table,
    # )
    #
    # tmp_load_task = [RedshiftQueryOperator(
    #     task_id='tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
    #     execute_query=select_sql_for_insert,
    # ) for select_sql_for_insert in insert_sql_for_tmp]
    #
    # tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    # sh1_delete_task = RedshiftQueryOperator(
    #     task_id='sh1_delete_task',
    #     execute_query=delete_sql_for_append,
    # )
    #
    # sh1_load_task = [RedshiftQueryOperator(
    #     task_id='sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
    #     execute_query=inert_query,
    # ) for inert_query in insert_sql_for_sh1]
    #
    # task_end = DummyOperator(task_id='task_end')
    #
    # tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> duplicate_valid_task >> sh1_delete_task >> sh1_load_task >> task_end
