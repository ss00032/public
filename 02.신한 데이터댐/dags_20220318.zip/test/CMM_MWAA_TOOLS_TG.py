# -*- coding: utf-8 -*-


from airflow.models.dag import DAG
from airflow.providers.ssh.operators.ssh import SSHOperator

from sgd import config

cmd = "{{ dag_run.conf['cmd'] }}"
dag_ids = "{{ dag_run.conf['dag_ids'] }}"
ssh_command = f"/shchome/ezgator/skoh5/mwaa/sgd_mwaa_tools.py {cmd} {dag_ids}"

dag_id = 'CMM_MWAA_TOOLS_TG'

with DAG(
        dag_id=dag_id,
        description=f'{dag_id} DAG',
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        max_active_runs=1,
        tags=['common', 'mwaa'],
) as dag:
    ssh_task = SSHOperator(
        task_id='ssh_task',
        ssh_conn_id='sgd_dl_ezgator_conn_id',
        command=ssh_command,
    )
    ssh_task