# -*- coding: utf-8 -*-

import datetime
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.ssh.operators.ssh import SSHOperator
from sgd import config
from sgd import logging
from sgd.utils import *

__author__ = "노재홍"
__copyright__ = "Copyright 2021, Shinhan Datadam"
__credits__ = ["노재홍"]
__version__ = "1.0"
__maintainer__ = "노재홍"
__email__ = ""
__status__ = "Production"


"""
(@) 배치 DAG 이름 (겹치지 않도록 주의)
"""
batch_dag_name = 'BATCH_DAG_PBC_IGT_001'

dev_switch = "{{ dag_run.conf['dev_switch'] | d('ON') }}"


args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'dev_switch':dev_switch,
}

dag = DAG(
    dag_id=batch_dag_name,
    description=f'{batch_dag_name} - FOR TRIGGER',
    schedule_interval=None,
    start_date=config.sgd_env['start_date'],
    default_args=args,
    tags=['bundle', 'trigger'],
    catchup=False
)

############################################################
"""
(@) 배치 DAG 리스트 정의
  - 실행 대상 dag_id 입력
  - 최대 32개 이하 권장
"""

dag_id_batch_dict = {
  'ILPM_DATAPORTAL_00565_TG' : '20220208'
, 'ILPM_DATAPORTAL_00566_TG' : '20220208'
, 'ILPM_KOSIS_00590_TG' : '20220208'
, 'ILPM_KOSIS_00591_TG' : '20220208'
, 'ILPM_KOSIS_00592_TG' : '20220208'
, 'ILPM_KOSIS_00593_TG' : '20220208'
, 'ILPM_KOSIS_00594_TG' : '20220208'
, 'ILPM_KOSIS_00595_TG' : '20220208'
, 'ILPM_KOSIS_00596_TG' : '20220208'
, 'ILPM_KOSIS_00597_TG' : '20220208'
, 'ILPM_KOSIS_00598_TG' : '20220208'
, 'ILPM_KOSIS_00599_TG' : '20220208'
, 'ILPM_KOSIS_00600_TG' : '20220208'
, 'ILPM_KOSIS_00601_TG' : '20220208'
, 'ILPM_KOSIS_00602_TG' : '20220208'
, 'ILPM_KOSIS_00603_TG' : '20220208'
, 'ILPM_KOSIS_00604_TG' : '20220208'
, 'ILPM_KOSIS_00605_TG' : '20220208'
, 'ILPM_KOSIS_00606_TG' : '20220208'
, 'ILPM_KOSIS_00607_TG' : '20220208'
, 'ILPM_KOSIS_00608_TG' : '20220208'
, 'ILPM_KOSIS_00609_TG' : '20220208'
, 'ILPM_KOSIS_00610_TG' : '20220208'
, 'ILPM_KOSIS_00611_TG' : '20220208'
, 'ILPM_KOSIS_00612_TG' : '20220208'
, 'ILPM_KOSIS_00613_TG' : '20220208'
, 'ILPM_KOSIS_00614_TG' : '20220208'
, 'ILPM_KOSIS_00615_TG' : '20220208'
, 'ILPM_KOSIS_00616_TG' : '20220208'
, 'ILPM_KOSIS_00617_TG' : '20220208'
, 'ILPM_KOSIS_00618_TG' : '20220208'
, 'ILPM_KOSIS_00619_TG' : '20220208'
, 'ILPM_KOSIS_00620_TG' : '20220208'
, 'ILPM_KOSIS_00621_TG' : '20220208'
, 'ILPM_SEOUL_00589_TG' : '20220208'
}
############################################################

for dag_id in dag_id_batch_dict.keys():

    triggering_task = TriggerDagRunOperator(
        task_id=f'trigger_{dag_id}',
        trigger_dag_id=dag_id,
        execution_date=dag_id_batch_dict[dag_id],
        reset_dag_run=True,
        wait_for_completion=True,
        poke_interval=10,
        dag=dag
    )
    triggering_task

