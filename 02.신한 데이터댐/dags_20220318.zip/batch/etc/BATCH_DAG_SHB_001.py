# -*- coding: utf-8 -*-

import datetime
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.ssh.operators.ssh import SSHOperator
from sgd import config
from sgd import logging
from sgd.utils import *

__author__ = "이종호"
__copyright__ = "Copyright 2021, Shinhan Datadam"
__credits__ = ["이종호"]
__version__ = "1.0"
__maintainer__ = "이종호"
__email__ = "hijack72@xgm.co.kr"
__status__ = "Production"


"""
(@) 배치 DAG 이름 (겹치지 않도록 주의)
"""
batch_dag_name = 'BATCH_DAG_SHB_001'

dev_switch = "{{ dag_run.conf['dev_switch'] | d('ON') }}"


args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'dev_switch':dev_switch,
}

dag = DAG(
    dag_id=batch_dag_name,
    description=f'{batch_dag_name} - FOR TRIGGER',
    schedule_interval=None,
    start_date=config.sgd_env['start_date'],
    default_args=args,
    tags=['bundle', 'trigger'],
    catchup=False
)

############################################################
"""
(@) 배치 DAG 리스트 정의
  - 실행 대상 dag_id 입력
  - 최대 32개 이하 권장
"""

dag_id_batch_dict = {
  'ILBD_DAM_CUS_MAS_TG' : '20220101'
, 'ILBD_DWA_JOB_DATE_TG' : '20220101'
, 'ILBD_DWC_CSS_CODEVAL_TG' : '20220101'
, 'ILBD_DWC_CST_JUM_TG' : '20220101'
, 'ILBD_DWC_CST_TONGHWA_TG' : '20220101'
, 'ILBD_DWC_FCL_TRANHST_TG' : '20220101'
, 'ILBD_DWC_PDM_ATTRYN_COM_TG' : '20220101'
, 'ILBD_DWC_PDM_FUNDINF_DEP_TG' : '20220101'
, 'ILBD_DWC_PDM_GILBON_COM_TG' : '20220101'
, 'ILBD_DWC_PFM_DATE_TG' : '20220101'
, 'ILBD_DWF_FCR_EXCHANGE_HIS_TG' : '20220101'
, 'ILBD_DWF_FER_FXRATE_TG' : '20220101'
, 'ILBD_DWF_FRE_SONGCMM_HIS_TG' : '20220101'
, 'ILBD_DWM_ACC_IYUL_SLV_TG' : '20220101'
, 'ILBD_DWM_CUSFORPRDTBRDTLD_RST_TG' : '20220101'
, 'ILBD_DWM_DEPACD_RST_TG' : '20220101'
, 'ILBD_DWM_NEW_TRX_TG' : '20220101'
, 'ILBD_DWM_YSACD_RST_TG' : '20220101'
, 'ILBD_DWM_YSE_TRX_TG' : '20220101'
, 'ILBD_DWS_SDA_DEPLOAN_SLV_TG' : '20220101'
, 'ILBD_DWS_SDA_GOJEONG_MAS_TG' : '20220101'
, 'ILBD_DWS_SDA_MAIN_MAS_TG' : '20220101'
, 'ILBD_DWS_SDT_DCDRHJE_SLV_TG' : '20220101'
, 'ILBD_DWX_AGL_ACCODE_HNK_TG' : '20220101'
, 'ILBD_DWX_UCL_TRX_LIST_TG' : '20220101'
, 'ILBD_DWY_YCL_SEOLJ_TG' : '20220101'
, 'ILBD_DWY_YER_LONKIMAS_TG' : '20220101'
, 'ILBD_DWY_YER_LONYJMAS_TG' : '20220101'
, 'ILBD_DWY_YLC_GTYSMAS_TG' : '20220101'
}
############################################################

for dag_id in dag_id_batch_dict.keys():

    cmd_unpause = 'unpause'
    ssh_command_unpause = f"/shchome/ezgator/skoh5/mwaa/sgd_mwaa_tools.py {cmd_unpause} {dag_id}"

    ssh_task_unpause = SSHOperator(
        task_id=f'ssh_task_unpause_{dag_id}',
        ssh_conn_id='sgd_dl_ezgator_conn_id',
        command=ssh_command_unpause,
    )

    triggering_task = TriggerDagRunOperator(
        task_id=f'trigger_{dag_id}',
        trigger_dag_id=dag_id,
        execution_date=dag_id_batch_dict[dag_id],
        reset_dag_run=True,
        wait_for_completion=True,
        poke_interval=10,
        dag=dag
    )

    triggering_task_end = DummyOperator(task_id=f'triggering_task_end_{dag_id}')

    cmd_pause = 'pause'
    ssh_command_pause = f"/shchome/ezgator/skoh5/mwaa/sgd_mwaa_tools.py {cmd_pause} {dag_id}"

    ssh_task_pause = SSHOperator(
        task_id=f'ssh_task_pause_{dag_id}',
        ssh_conn_id='sgd_dl_ezgator_conn_id',
        command=ssh_command_pause,
    )

    ssh_task_unpause >> triggering_task >> triggering_task_end >> ssh_task_pause