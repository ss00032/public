# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *

__author__     = "김현진"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["김현진"]
__version__    = "1.0"
__maintainer__ = "김현진"
__email__      = "khj1455@xgm.co.kr"
__status__     = "Production"

"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상   : CLN_
  - 프로그램 ID : IBVD_SHDDCOM003_11
  - 한글 테이블명: COM_적재항목검증집계
  - TMP_SH1 테이블명 
"""
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBVD_SHDDCOM003_11'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L1공통) COM_적재항목검증집계'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh1'
tmp_schema = 'tmp_sh1'

# STEP 변수
step_num = 0

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
# TEMP 테이블
tmp_sh1_table = ['shddcom003_tmp11']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
###############################################################################
# STI_월GIS시군구금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-001(모수)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- AWS적재일시
         , 'SHDMSTI001'                                   -- 테이블영문명
         , 'STI_월GIS시군구금융통계집계'                         -- 테이블한글명
         , 'COUNT'                                        -- 컬럼영문명
         , '모수검증'                                      -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select count(1)   tgt_cnt             -- 적재건수
               from sh2.shdmsti001                        -- STI_월GIS시군구금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select count(1)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                as ta_ym                       -- 기준년월
                             , nvl(t10.hm_zpn, ' ')                  as hm_zpn                      -- 자택우편번호
                             -- 고객수
                             , count(distinct t10.shmdn)             as wl_cln_cn                   -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , nvl(sum(t16.mrp_pd_pss_tf), 0)        as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                             -- 가맹점원장
                             , 0                                     as to_mct_ct                   -- 총가맹점건수
                        from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                        left outer join
                                sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                                on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                        and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
                        left outer join
                                sh2.shdmigd003                        t16                            -- IGD_월고객보유상품기본
                                on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                        and t10.shmdn = t16.shmdn                                                -- 그룹MD번호
                        where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                        and trim(t10.hm_zpn) is not null                                         -- 자택우편번호
                        group by
                                nvl(t10.hm_zpn, ' ')                                                 -- 자택우편번호
                    )
           ) t2
        on 1 = 1
"""

###############################################################################
# STI_월GIS시군구금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-002(전체고객수)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_2 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- AWS적재일시
         , 'SHDMSTI001'                                   -- 테이블영문명
         , 'STI_월GIS시군구금융통계집계'                    -- 테이블한글명
         , 'WL_CLN_CN'                                    -- 컬럼영문명
         , '전체고객수'                                    -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(wl_cln_cn)   tgt_cnt             -- 적재건수
               from sh2.shdmsti001                        -- STI_월GIS시군구금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(wl_cln_cn)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                as ta_ym                       -- 기준년월
                             , nvl(t10.hm_zpn, ' ')                  as hm_zpn                      -- 자택우편번호
                             -- 고객수
                             , count(distinct t10.shmdn)             as wl_cln_cn                   -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , nvl(sum(t16.mrp_pd_pss_tf), 0)        as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                             -- 가맹점원장
                             , 0                                     as to_mct_ct                   -- 총가맹점건수
                        from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                        left outer join
                                sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                                on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                        and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
                        left outer join
                                sh2.shdmigd003                        t16                            -- IGD_월고객보유상품기본
                                on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                        and t10.shmdn = t16.shmdn                                                -- 그룹MD번호
                        where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                        and trim(t10.hm_zpn) is not null                                         -- 자택우편번호
                        group by
                                nvl(t10.hm_zpn, ' ')                                                 -- 자택우편번호
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월GIS시군구금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-003(총자산금액)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_3 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI001'                                   -- 테이블영문명
         , 'STI_월GIS시군구금융통계집계'                    -- 테이블한글명
         , 'TO_ASE_AT'                                    -- 컬럼영문명
         , '총자산금액'                                    -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(to_ase_at)   tgt_cnt             -- 적재건수
               from sh2.shdmsti001                        -- STI_월GIS시군구금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(to_ase_at)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                as ta_ym                       -- 기준년월
                             , nvl(t10.hm_zpn, ' ')                  as hm_zpn                      -- 자택우편번호
                             -- 고객수
                             , count(distinct t10.shmdn)             as wl_cln_cn                   -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , nvl(sum(t16.mrp_pd_pss_tf), 0)        as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                             -- 가맹점원장
                             , 0                                     as to_mct_ct                   -- 총가맹점건수
                        from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                        left outer join
                                sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                                on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                        and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
                        left outer join
                                sh2.shdmigd003                        t16                            -- IGD_월고객보유상품기본
                                on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                        and t10.shmdn = t16.shmdn                                                -- 그룹MD번호
                        where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                        and trim(t10.hm_zpn) is not null                                         -- 자택우편번호
                        group by
                                nvl(t10.hm_zpn, ' ')                                                 -- 자택우편번호
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월GIS행정동금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-004(모수검증)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_4 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI002'                                   -- 테이블영문명
         , 'STI_월GIS행정동금융통계집계'                    -- 테이블한글명
         , 'COUNT'                                        -- 컬럼영문명
         , '모수검증'                                      -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select count(1)   tgt_cnt             -- 적재건수
               from sh2.shdmsti002                        -- STI_월GIS행정동금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select count(1)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                as ta_ym             -- 기준년월
                             , nvl(t10.hm_adm_gds_apb_cd, ' ')       as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                             -- 고객수
                             , count(distinct t10.shmdn)             as wl_cln_cn         -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , nvl(sum(t16.mrp_pd_pss_tf), 0)        as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                             -- 가맹점원장
                             , 0                                     as to_mct_ct                   -- 총가맹점건수
                          from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                          left outer join
                               sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                            on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                           and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
                          left outer join
                               sh2.shdmigd003                        t16                            -- IGD_월고객보유상품기본
                            on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                           and t10.shmdn = t16.shmdn                                                -- 그룹MD번호
                         where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                           and trim(t10.hm_adm_gds_apb_cd) is not null                              -- 자택행정GDS동코드
                         group by
                               nvl(t10.hm_adm_gds_apb_cd, ' ')                                      -- 자택행정GDS동코드
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월GIS행정동금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-005(전체고객수)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_5 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI002'                                   -- 테이블영문명
         , 'STI_월GIS행정동금융통계집계'                    -- 테이블한글명
         , 'WL_CLN_CN'                                    -- 컬럼영문명
         , '전체고객수'                                    -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(wl_cln_cn)   tgt_cnt             -- 적재건수
               from sh2.shdmsti002                        -- STI_월GIS행정동금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(wl_cln_cn)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                as ta_ym             -- 기준년월
                             , nvl(t10.hm_adm_gds_apb_cd, ' ')       as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                             -- 고객수
                             , count(distinct t10.shmdn)             as wl_cln_cn         -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , nvl(sum(t16.mrp_pd_pss_tf), 0)        as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                             -- 가맹점원장
                             , 0                                     as to_mct_ct                   -- 총가맹점건수
                          from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                          left outer join
                               sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                            on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                           and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
                          left outer join
                               sh2.shdmigd003                        t16                            -- IGD_월고객보유상품기본
                            on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                           and t10.shmdn = t16.shmdn                                                -- 그룹MD번호
                         where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                           and trim(t10.hm_adm_gds_apb_cd) is not null                              -- 자택행정GDS동코드
                         group by
                               nvl(t10.hm_adm_gds_apb_cd, ' ')                                      -- 자택행정GDS동코드
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월GIS행정동금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-006(총자산금액)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_6 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI002'                                   -- 테이블영문명
         , 'STI_월GIS행정동금융통계집계'                    -- 테이블한글명
         , 'TO_ASE_AT'                                    -- 컬럼영문명
         , '총자산금액'                                    -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(to_ase_at)   tgt_cnt             -- 적재건수
               from sh2.shdmsti002                        -- STI_월GIS행정동금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(to_ase_at)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                as ta_ym             -- 기준년월
                             , nvl(t10.hm_adm_gds_apb_cd, ' ')       as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                             -- 고객수
                             , count(distinct t10.shmdn)             as wl_cln_cn         -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , nvl(sum(t16.mrp_pd_pss_tf), 0)        as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                             -- 가맹점원장
                             , 0                                     as to_mct_ct                   -- 총가맹점건수
                          from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                          left outer join
                               sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                            on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                           and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
                          left outer join
                               sh2.shdmigd003                        t16                            -- IGD_월고객보유상품기본
                            on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                           and t10.shmdn = t16.shmdn                                                -- 그룹MD번호
                         where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                           and trim(t10.hm_adm_gds_apb_cd) is not null                              -- 자택행정GDS동코드
                         group by
                               nvl(t10.hm_adm_gds_apb_cd, ' ')                                      -- 자택행정GDS동코드
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월GIS법정동금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-007(모수검증)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_7 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI003'                                   -- 테이블영문명
         , 'STI_월GIS법정동금융통계집계'                    -- 테이블한글명
         , 'COUNT'                                        -- 컬럼영문명
         , '모수검증'                                      -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select count(1)   tgt_cnt             -- 적재건수
               from sh2.shdmsti003                        -- STI_월GIS법정동금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select count(1)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
                             , nvl(t10.hm_cou_gds_apb_cd, ' ')                 as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                             -- 고객수
                             , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , nvl(sum(t16.mrp_pd_pss_tf), 0)        as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                             -- 가맹점원장
                             , 0                                     as to_mct_ct                   -- 총가맹점건수
                        from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                        left outer join
                                sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                                on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                        and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
                        left outer join
                                sh2.shdmigd003                        t16                            -- IGD_월고객보유상품기본
                                on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                        and t10.shmdn = t16.shmdn                                                -- 그룹MD번호
                        where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                        and trim(t10.hm_cou_gds_apb_cd) is not null                              -- 자택법정GDS동코드
                        group by
                                nvl(t10.hm_cou_gds_apb_cd, ' ')                                      -- 자택법정GDS동코드
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월GIS법정동금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-008(전체고객수)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_8 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI003'                                   -- 테이블영문명
         , 'STI_월GIS법정동금융통계집계'                    -- 테이블한글명
         , 'WL_CLN_CN'                                    -- 컬럼영문명
         , '전체고객수'                                    -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(wl_cln_cn)   tgt_cnt             -- 적재건수
               from sh2.shdmsti003                        -- STI_월GIS법정동금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(wl_cln_cn)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
                             , nvl(t10.hm_cou_gds_apb_cd, ' ')                 as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                             -- 고객수
                             , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , nvl(sum(t16.mrp_pd_pss_tf), 0)        as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                             -- 가맹점원장
                             , 0                                     as to_mct_ct                   -- 총가맹점건수
                        from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                        left outer join
                                sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                                on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                        and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
                        left outer join
                                sh2.shdmigd003                        t16                            -- IGD_월고객보유상품기본
                                on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                        and t10.shmdn = t16.shmdn                                                -- 그룹MD번호
                        where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                        and trim(t10.hm_cou_gds_apb_cd) is not null                              -- 자택법정GDS동코드
                        group by
                                nvl(t10.hm_cou_gds_apb_cd, ' ')                                      -- 자택법정GDS동코드
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월GIS법정동금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-009(총자산금액)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_9 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI003'                                   -- 테이블영문명
         , 'STI_월GIS법정동금융통계집계'                    -- 테이블한글명
         , 'TO_ASE_AT'                                    -- 컬럼영문명
         , '총자산금액'                                    -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(to_ase_at)   tgt_cnt             -- 적재건수
               from sh2.shdmsti003                        -- STI_월GIS법정동금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(to_ase_at)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
                             , nvl(t10.hm_cou_gds_apb_cd, ' ')                 as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                             -- 고객수
                             , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , nvl(sum(t16.mrp_pd_pss_tf), 0)        as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                             -- 가맹점원장
                             , 0                                     as to_mct_ct                   -- 총가맹점건수
                        from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                        left outer join
                                sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                                on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                        and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
                        left outer join
                                sh2.shdmigd003                        t16                            -- IGD_월고객보유상품기본
                                on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                        and t10.shmdn = t16.shmdn                                                -- 그룹MD번호
                        where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                        and trim(t10.hm_cou_gds_apb_cd) is not null                              -- 자택법정GDS동코드
                        group by
                                nvl(t10.hm_cou_gds_apb_cd, ' ')                                      -- 자택법정GDS동코드
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월연령금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-010(모수검증)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_10 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI004'                                   -- 테이블영문명
         , 'STI_월연령금융통계집계'                         -- 테이블한글명
         , 'COUNT'                                        -- 컬럼영문명
         , '모수검증'                                      -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select count(1)   tgt_cnt             -- 적재건수
               from sh2.shdmsti004                        -- STI_월연령금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select count(1)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
                             , t10.cln_age                                                          -- 고객연령
                             -- 고객수
                             , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , count( distinct case when t16.mrp_pd_pss_tf = 1                      -- 입출금상품보유TF
                                                    then t10.shmdn
                                               end )                 as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                          from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                          left outer join
                               sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                            on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                           and t10.shmdn = t11.shmdn                                                -- 그룹md번호
                          left outer join
                               sh2.shdmigd003                        t16                            -- igd_월고객보유상품기본
                            on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                           and t10.shmdn = t16.shmdn                                                -- 그룹md번호
                         where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                           and t10.cln_age is not null                                              -- 고객연령
                         group by
                               t10.cln_age                                                          -- 고객연령
                      )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월연령금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-011(전체고객수)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_11 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI004'                                   -- 테이블영문명
         , 'STI_월연령금융통계집계'                         -- 테이블한글명
         , 'WL_CLN_CN'                                    -- 컬럼영문명
         , '전체고객수'                                    -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(wl_cln_cn)   tgt_cnt             -- 적재건수
               from sh2.shdmsti004                        -- STI_월연령금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(wl_cln_cn)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
                             , t10.cln_age                                                          -- 고객연령
                             -- 고객수
                             , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , count( distinct case when t16.mrp_pd_pss_tf = 1                      -- 입출금상품보유TF
                                                    then t10.shmdn
                                               end )                 as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                          from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                          left outer join
                               sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                            on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                           and t10.shmdn = t11.shmdn                                                -- 그룹md번호
                          left outer join
                               sh2.shdmigd003                        t16                            -- igd_월고객보유상품기본
                            on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                           and t10.shmdn = t16.shmdn                                                -- 그룹md번호
                         where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                           and t10.cln_age is not null                                              -- 고객연령
                         group by
                               t10.cln_age                                                          -- 고객연령
                      )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월연령금융통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-012(총자산금액)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_12 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI004'                                   -- 테이블영문명
         , 'STI_월연령금융통계집계'                         -- 테이블한글명
         , 'TO_ASE_AT'                                    -- 컬럼영문명
         , '총자산금액'                                    -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(to_ase_at)   tgt_cnt             -- 적재건수
               from sh2.shdmsti004                        -- STI_월연령금융통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(to_ase_at)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
                             , t10.cln_age                                                          -- 고객연령
                             -- 고객수
                             , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
                             -- 자산
                             , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
                             -- 부채
                             , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
                             -- 지출
                             , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
                             -- 상품보유고객수
                             , count( distinct case when t16.mrp_pd_pss_tf = 1                      -- 입출금상품보유TF
                                                    then t10.shmdn
                                               end )                 as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
                          from sh2.shdmigd011                        t10                            -- IGD_월고객기본
                          left outer join
                               sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
                            on t10.ta_ym = t11.ta_ym                                                -- 기준년월
                           and t10.shmdn = t11.shmdn                                                -- 그룹md번호
                          left outer join
                               sh2.shdmigd003                        t16                            -- igd_월고객보유상품기본
                            on t10.ta_ym = t16.ta_ym                                                -- 기준년월
                           and t10.shmdn = t16.shmdn                                                -- 그룹md번호
                         where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
                           and t10.cln_age is not null                                              -- 고객연령
                         group by
                               t10.cln_age                                                          -- 고객연령
                      )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월상품통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-013(모수검증)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_13 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI005'                                   -- 테이블영문명
         , 'STI_월상품통계집계'                            -- 테이블한글명
         , 'COUNT'                                        -- 컬럼영문명
         , '모수검증'                                     -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select count(1)   tgt_cnt             -- 적재건수
               from sh2.shdmsti005                        -- STI_월상품통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select count(1)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
                             , t10.shd_pd_zcd                                                       -- 데이터댐상품분류코드
                             -- 고객수
                             , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
                             -- 가입건수
                             , nvl(sum(t10.lat_ct), 0)                         as wl_pd_jn_ct       -- 전체상품가입건수
                             -- 상품금액
                             , nvl(sum(t10.al), 0)                             as wl_pd_at          -- 전체상품금액
                          from (
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , t20.lat_ct                                                -- 신규건수
                                     , t20.al                                                    -- 잔액
                                  from sh1.shbmtrs001             t20                            -- TRS_월고객계좌거래실적_은행
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                 union all
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , t20.lat_ue_tf                                             -- 신규이용TF
                                     , t20.ln_al                                                 -- 대출잔액
                                  from sh1.shcmtrs001             t20                            -- TRS_월고객카드거래실적_카드
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                 union all
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , 0                                  as lat_ct              -- 신규건수
                                     , t20.al                                                    -- 잔액
                                  from sh1.shimtrs001             t20                            -- TRS_월고객계좌거래실적_금투
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                 union all
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , t20.lat_ct                                                -- 신규건수
                                     , t20.al                                                    -- 잔액
                                  from sh1.shlmtrs001             t20                            -- TRS_월고객계약거래실적_라이프
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                )                                     t10
                           left outer join
                                sh2.shdmigd011                        t11                        -- IGD_월고객기본
                                on t11.ta_ym = '{date_cd('P_TA_YM')}'                            -- 기준년월
                               and t10.shmdn = t11.shmdn                                         -- 그룹MD번호
                             group by
                                   t10.shd_pd_zcd                                                -- 데이터댐상품분류코드
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월상품통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-014(전체고객수)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_14 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI005'                                   -- 테이블영문명
         , 'STI_월상품통계집계'                            -- 테이블한글명
         , 'WL_CLN_CN'                                    -- 컬럼영문명
         , '전체고객수'                                    -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(wl_cln_cn)   tgt_cnt             -- 적재건수
               from sh2.shdmsti005                        -- STI_월상품통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(wl_cln_cn)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
                             , t10.shd_pd_zcd                                                       -- 데이터댐상품분류코드
                             -- 고객수
                             , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
                             -- 가입건수
                             , nvl(sum(t10.lat_ct), 0)                         as wl_pd_jn_ct       -- 전체상품가입건수
                             -- 상품금액
                             , nvl(sum(t10.al), 0)                             as wl_pd_at          -- 전체상품금액
                          from (
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , t20.lat_ct                                                -- 신규건수
                                     , t20.al                                                    -- 잔액
                                  from sh1.shbmtrs001             t20                            -- TRS_월고객계좌거래실적_은행
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                 union all
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , t20.lat_ue_tf                                             -- 신규이용TF
                                     , t20.ln_al                                                 -- 대출잔액
                                  from sh1.shcmtrs001             t20                            -- TRS_월고객카드거래실적_카드
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                 union all
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , 0                                  as lat_ct              -- 신규건수
                                     , t20.al                                                    -- 잔액
                                  from sh1.shimtrs001             t20                            -- TRS_월고객계좌거래실적_금투
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                 union all
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , t20.lat_ct                                                -- 신규건수
                                     , t20.al                                                    -- 잔액
                                  from sh1.shlmtrs001             t20                            -- TRS_월고객계약거래실적_라이프
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                )                                     t10
                           left outer join
                                sh2.shdmigd011                        t11                        -- IGD_월고객기본
                                on t11.ta_ym = '{date_cd('P_TA_YM')}'                            -- 기준년월
                               and t10.shmdn = t11.shmdn                                         -- 그룹MD번호
                             group by
                                   t10.shd_pd_zcd                                                -- 데이터댐상품분류코드
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월상품통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-015(전체상품금액)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_15 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI005'                                   -- 테이블영문명
         , 'STI_월상품통계집계'                           -- 테이블한글명
         , 'WL_PD_AT'                                     -- 컬럼영문명
         , '전체상품금액'                                  -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(wl_pd_at)   tgt_cnt             -- 적재건수
               from sh2.shdmsti005                        -- STI_월상품통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(wl_pd_at)   src_cnt             -- 원천건수
               from (
                        select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
                             , t10.shd_pd_zcd                                                       -- 데이터댐상품분류코드
                             -- 고객수
                             , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
                             -- 가입건수
                             , nvl(sum(t10.lat_ct), 0)                         as wl_pd_jn_ct       -- 전체상품가입건수
                             -- 상품금액
                             , nvl(sum(t10.al), 0)                             as wl_pd_at          -- 전체상품금액
                          from (
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , t20.lat_ct                                                -- 신규건수
                                     , t20.al                                                    -- 잔액
                                  from sh1.shbmtrs001             t20                            -- TRS_월고객계좌거래실적_은행
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                 union all
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , t20.lat_ue_tf                                             -- 신규이용TF
                                     , t20.ln_al                                                 -- 대출잔액
                                  from sh1.shcmtrs001             t20                            -- TRS_월고객카드거래실적_카드
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                 union all
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , 0                                  as lat_ct              -- 신규건수
                                     , t20.al                                                    -- 잔액
                                  from sh1.shimtrs001             t20                            -- TRS_월고객계좌거래실적_금투
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                 union all
                                select t20.ta_ym                                                 -- 기준년월
                                     , t20.shmdn                                                 -- 그룹MD번호
                                     , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                                     , t20.lat_ct                                                -- 신규건수
                                     , t20.al                                                    -- 잔액
                                  from sh1.shlmtrs001             t20                            -- TRS_월고객계약거래실적_라이프
                                 where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                                )                                     t10
                           left outer join
                                sh2.shdmigd011                        t11                        -- IGD_월고객기본
                                on t11.ta_ym = '{date_cd('P_TA_YM')}'                            -- 기준년월
                               and t10.shmdn = t11.shmdn                                         -- 그룹MD번호
                             group by
                                   t10.shd_pd_zcd                                                -- 데이터댐상품분류코드
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월가맹점업종매출통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-016(모수검증)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_16 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI006'                                   -- 테이블영문명
         , 'STI_월가맹점업종매출통계집계'                   -- 테이블한글명
         , 'COUNT'                                        -- 컬럼영문명
         , '모수검증'                                      -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select count(1)   tgt_cnt                  -- 적재건수
               from sh2.shdmsti006                      -- STI_월가맹점업종매출통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select count(1)   src_cnt                  -- 원천건수
               from (
                      select ta_ym
                           , mct_ry_cd
                           , current_timestamp AT TIME ZONE 'Asia/Seoul'  as aws_ld_dt                -- aws적재일시
                           , count(mct_n)                          as mct_ct                          -- 가맹점건수
                           , sum(saa)                              as saa                             -- 매출금액
                           , sum(ue_ct)                            as ue_ct                           -- 이용건수
                           , sum(mal_saa)                          as mal_saa                         -- 남성매출금액
                           , sum(fme_saa)                          as fme_saa                         -- 여성매출금액
                           , sum(mal_ue_ct)                        as mal_ue_ct                       -- 남성이용건수
                           , sum(fme_ue_ct)                        as fme_ue_ct                       -- 여성이용건수
                       from sh1.shcmtrs003
                       where ta_ym = '{date_cd('P_TA_YM')}'
                       group by ta_ym
                              , mct_ry_cd
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월가맹점업종매출통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-017(매출금액)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_17 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI006'                                   -- 테이블영문명
         , 'STI_월가맹점업종매출통계집계'                   -- 테이블한글명
         , 'SAA'                                          -- 컬럼영문명
         , '매출금액'                                      -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(saa)   tgt_cnt                  -- 적재건수
               from sh2.shdmsti006                      -- STI_월가맹점업종매출통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(saa)   src_cnt                  -- 원천건수
               from (
                      select ta_ym
                           , mct_ry_cd
                           , current_timestamp AT TIME ZONE 'Asia/Seoul'  as aws_ld_dt                -- aws적재일시
                           , count(mct_n)                          as mct_ct                          -- 가맹점건수
                           , sum(saa)                              as saa                             -- 매출금액
                           , sum(ue_ct)                            as ue_ct                           -- 이용건수
                           , sum(mal_saa)                          as mal_saa                         -- 남성매출금액
                           , sum(fme_saa)                          as fme_saa                         -- 여성매출금액
                           , sum(mal_ue_ct)                        as mal_ue_ct                       -- 남성이용건수
                           , sum(fme_ue_ct)                        as fme_ue_ct                       -- 여성이용건수
                       from sh1.shcmtrs003
                       where ta_ym = '{date_cd('P_TA_YM')}'
                       group by ta_ym
                              , mct_ry_cd
                    )
           ) t2
        on 1 = 1
"""
###############################################################################
# STI_월가맹점업종매출통계집계 검증
# 검증 항목 : IBVD_SHDDCOM003_11-018(이용건수)
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_18 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHDMSTI006'                                   -- 테이블영문명
         , 'STI_월가맹점업종매출통계집계'                   -- 테이블한글명
         , 'UE_CT'                                        -- 컬럼영문명
         , '이용건수'                                      -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(ue_ct)   tgt_cnt                  -- 적재건수
               from sh2.shdmsti006                      -- STI_월가맹점업종매출통계집계
              where ta_ym = '{date_cd('P_TA_YM')}'
           ) t1
     inner join
           (
             select sum(ue_ct)   src_cnt                  -- 원천건수
               from (
                   select ta_ym
                        , mct_ry_cd
                        , sum(ue_ct)   as ue_ct            -- 이용건수
                     from sh1.shcmtrs003
                    where ta_ym = '{date_cd('P_TA_YM')}'
                    group by ta_ym
                           , mct_ry_cd
                    )
           ) t2
        on 1 = 1
"""
"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1, insert_sql_for_tmp_2, insert_sql_for_tmp_3, insert_sql_for_tmp_4 \
                     ,insert_sql_for_tmp_5, insert_sql_for_tmp_6, insert_sql_for_tmp_7, insert_sql_for_tmp_8 \
                     ,insert_sql_for_tmp_9, insert_sql_for_tmp_10, insert_sql_for_tmp_11, insert_sql_for_tmp_12 \
                     ,insert_sql_for_tmp_13, insert_sql_for_tmp_14, insert_sql_for_tmp_15, insert_sql_for_tmp_16 \
                     ,insert_sql_for_tmp_17, insert_sql_for_tmp_18]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': tmp_sh1_table[0], 'pk': ['ced', 'aws_vrf_itm_vl']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh1.shddcom003                                   -- COM_적재항목검증집계
     where ced = '{date_cd('P_CED')}'
       and aws_vrf_itm_vl like '{pgm_id}%'
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh1.shddcom003                                   -- CLN_일고객마스터_은행
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
      from tmp_sh1.{tmp_sh1_table[0]}  t10      -- COM_적재항목검증집계_TMP01
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end