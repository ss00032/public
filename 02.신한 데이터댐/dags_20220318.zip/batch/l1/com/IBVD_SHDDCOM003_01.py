# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *

__author__     = "김현진"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["김현진"]
__version__    = "1.0"
__maintainer__ = "김현진"
__email__      = "khj1455@xgm.co.kr"
__status__     = "Production"

"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상   : CLN_
  - 프로그램 ID : IBVD_SHDDCOM003_01
  - 한글 테이블명: COM_적재항목검증집계
  - TMP_SH1 테이블명 
"""

### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBVD_SHDDCOM003_01'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L1공통) COM_적재항목검증집계'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh1'
tmp_schema = 'tmp_sh1'

# STEP 변수
step_num = 0

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
# TEMP 테이블
tmp_sh1_table = ['shddcom003_tmp01']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
###############################################################################
# CLN_일고객마스터_은행 검증
# 검증 항목 : 모수검증
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- AWS적재일시
         , 'SHBDCLN001'                                   -- 테이블영문명
         , 'CLN_일고객마스터_은행'                          -- 테이블한글명
         , 'COUNT'                                        -- 컬럼영문명
         , '모수검증'                                      -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select count(1)   tgt_cnt             -- 적재건수
               from sh1.shbdcln001      t20        -- CLN_일고객마스터_은행
           ) t10
     inner join
           (
             select count(1)   src_cnt             -- 원천건수
               from shb.dam_cus_mas t20            -- dam_그룹데이터댐_고객_mas
           ) t11
        on 1 = 1
"""

###############################################################################
# CLN_일고객마스터_은행 검증
# 검증 항목 : 내국인TF
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_2 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- AWS적재일시
         , 'SHBDCLN001'                                   -- 테이블영문명
         , 'CLN_일고객마스터_은행'                          -- 테이블한글명
         , 'LCR_TF'                                       -- 컬럼영문명
         , '내국인TF'                                     -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟항목결과값
         , nvl(src_cnt, 0)                                -- 소스항목결과값
      from (
             select sum(lcr_tf)   tgt_cnt          -- 적재건수
               from sh1.shbdcln001      t20        -- CLN_일고객마스터_은행
           ) t10
     inner join
           (
             select sum(case when t20.ntlty_nat_c= 'KR'       --국적국가CODE
                             then 1
                             else 0
                        end)      src_cnt          -- 원천건수
               from shb.dam_cus_mas t20            -- dam_그룹데이터댐_고객_mas
           ) t11
        on 1 = 1
"""
###############################################################################
# CLN_일개인사업자마스터_은행 검증
# 검증 항목 : 모수검증
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_3 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHBDCLN003'                                   -- 검증테이블
         , 'CLN_일개인사업자마스터_은행'                    -- 검증테이블한글명
         , 'COUNT'                                        -- 컬럼영문명
         , '모수검증'                                      -- 컬럼영문명
         , nvl(tgt_cnt, 0)                                -- 타겟검증
         , nvl(src_cnt, 0)                                -- 소스검증
      from (
             select count(1)   tgt_cnt             -- 적재건수
               from sh1.shbdcln003 t20             -- CLN_일개인사업자마스터_은행
           ) t10
     inner join
           (
             select count(1)   src_cnt             -- 원천건수
               from shb.dam_cus_mas t20            -- dam_그룹데이터댐_고객_mas
              where t20.cus_inf_s < 6              -- 고객정보상태
                and t20.psn_corp_g = 2             -- 개인기업구분
           ) t11
        on 1 = 1
"""
###############################################################################
# CLN_일개인사업자마스터_은행 검증
# 검증 항목 : 카드가맹점TF
###############################################################################
# STEP 증가 
step_num += 1

insert_sql_for_tmp_4 = f"""
    insert into tmp_sh1.{tmp_sh1_table[0]}                 -- COM_적재항목검증집계_TMP01
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select '{date_cd('P_CED')}'                           -- 기준일자
         , '{pgm_id}-{step_num:03d}'                      -- AWS검증항목값
         , current_timestamp AT TIME ZONE 'Asia/Seoul'    -- 적재일시
         , 'SHBDCLN003'                                   -- 검증테이블
         , 'CLN_일개인사업자마스터_은행'                    -- 검증테이블한글명
         , 'CRD_MCT_TF'                                   -- 컬럼영문명
         , '카드가맹점TF'                                  -- 컬럼한글명
         , nvl(tgt_cnt, 0)                                -- 타겟검증
         , nvl(src_cnt, 0)                                -- 소스검증
      from (
             select sum(crd_mct_tf)   tgt_cnt      -- 적재건수
               from sh1.shbdcln003 t20             -- CLN_일개인사업자마스터_은행
           ) t10
     inner join
           (
             select sum(case when t21.rlp_mct_ct > 0 then 1 else 0 end) src_cnt
               from shb.dam_cus_mas t20            -- dam_그룹데이터댐_고객_mas
               left outer join
                    (
                      select t30.rpk_sgdmd                                             -- 대표자그룹MD번호
                           , t30.mct_brn                                               -- 가맹점사업자등록번호
                           , count(distinct t30.mct_n) as rlp_mct_ct                   -- 실질가맹점건수
                        from shc.mtdia5011	       t30   -- 일가맹점디멘젼마스터
                       where t30.rlp_mct_tf = 1                                        -- 실질가맹점TF
                         and t30.psn_etk_tf = 1                                        -- 개인사업자TF
                       group by
                             t30.rpk_sgdmd                                             -- 대표자그룹MD번호
                           , t30.mct_brn                                               -- 가맹점사업자등록번호
                    ) t21
                 on t20.cusno = t21.rpk_sgdmd
                and t20.bizno = t21.mct_brn
              where t20.cus_inf_s < 6              -- 고객정보상태
                and t20.psn_corp_g = 2             -- 개인기업구분
           ) t11
        on 1 = 1
"""
"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1, insert_sql_for_tmp_2, insert_sql_for_tmp_3, insert_sql_for_tmp_4]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': tmp_sh1_table[0], 'pk': ['ced', 'aws_vrf_itm_vl']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh1.shddcom003                                   -- COM_적재항목검증집계
     where ced = '{date_cd('P_CED')}'
       and aws_vrf_itm_vl like '{pgm_id}%'
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh1.shddcom003                                   -- CLN_일고객마스터_은행
         (
           ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
         )
    select ced	                                  -- 기준일자
         , aws_vrf_itm_vl	                      -- AWS검증항목값
         , aws_ld_dt	                          -- AWS적재일시
         , tbl_eng_nm	                          -- 테이블영문명
         , tbl_hg_nm	                          -- 테이블한글명
         , col_eng_nm	                          -- 컬럼영문명
         , col_hg_nm	                          -- 컬럼한글명
         , tar_itm_ru_vl	                      -- 타겟항목결과값
         , src_itm_ru_vl	                      -- 소스항목결과값
      from tmp_sh1.{tmp_sh1_table[0]}  t10      -- COM_적재항목검증집계_TMP01
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end