# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "윤혁준"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["윤혁준"]
__version__    = "1.0"
__maintainer__ = "윤혁준"
__email__      = "ss00032@xgm.co.kr"
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID  : IBTM_SHLMPDT001_TG
  - 한글 테이블명: PDT_월계약보유상품기본_라이프
  - TMP_SH1 테이블명: tmp_sh1.shlmpdt001_tmp99
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHLMPDT001_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = 'PDT_월계약보유상품기본_라이프'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

##날짜변수 사용관련 
execution_kst = '{{ dag.timezonT14.convert(execution_date).strftime("%Y%m%d") }}'

# 적재 스키마명
target_schema = 'sh1'
tmp_schema = 'tmp_sh1'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shlmpdt001_tmp99']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
## 20220113 : 테이블 레이아웃 현행화
insert_sql_for_tmp_1 = f"""
     insert into tmp_sh1.shlmpdt001_tmp99
          (
            ta_ym                                                           -- 기준년월
          , shmdn                                                           -- 그룹md번호
          , ts_dtn_n                                                        -- 거래식별번호
          , aws_ld_dt                                                       -- aws적재일시
          , shd_pd_zcd                                                      -- 데이터댐상품분류코드
          , nl_tf                                                           -- 정상tf
          , shl_are_scd                                                     -- 신한라이프계약상태코드
          , ni_jn_d                                                         -- 최초가입일자
          , mn_are_xp_d                                                     -- 주계약만기일자
          , exi_d                                                           -- 소멸일자
          , shl_li_chl_ccd                                                  -- 신한라이프판매채널구분코드
          )
     select '{date_cd('P_TA_YM')}'                                          -- 기준년월
          , t10.coor_cs_no                                                  -- 그룹md번호
          , t10.inon_no                                                     -- 거래식별번호
          , current_timestamp at time zone 'asia/seoul'                     -- aws적재일시
          , case when t11.ins_sbsn_good_smcl_cd = '06' then 'L18'
                 when t11.ins_sbsn_good_lrcl_cd = '01' then 'L11'
                 when t11.ins_sbsn_good_lrcl_cd = '05' then 'L12'
                 when t11.ins_sbsn_good_lrcl_cd = '07' then 'L13'
                 when t11.ins_sbsn_good_lrcl_cd = '08' then 'L14'
                 when t11.ins_sbsn_good_lrcl_cd in ('09','10','02') then 'L15'
                 when t11.ins_sbsn_good_lrcl_cd = '12' then 'L16'
                 when t11.ins_sbsn_good_lrcl_cd = '13' then 'L17'
                 when t11.ins_sbsn_good_lrcl_cd = '11' then 'L19'
            else 'L1Z' end                                                  -- 데이터댐상품분류코드
          , case when t10.ctst_cd = 'A' then '1'
                 else '0'
             end                                                            -- 정상tf
          , case when ctst_cd in ('A','B','C','D') then '0'||ctst_cd 
                 when ctst_cd = 'Z' then 'ZZ' 
                 else 'ZZ' 
             end                                                            -- 신한라이프계약상태코드
          , t10.frst_con_ymd                                                -- 최초가입일자
          , t10.mnpr_eprt_ymd                                               -- 주계약만기일자
          , t10.etnc_ymd                                                    -- 소멸일자
          , t10.sln_chnn_sc_cd                                              -- 신규채널코드
       from shl.dm_mthl_con t10
       left outer join shl.dm_inty t11
         on t11.inty_cd = t10.good_cd
      where t10.str_ym            = '{date_cd('P_TA_YM')}'
        and t10.indv_asct_sc_cd   = '01' --개인
      union all
     select '{date_cd('P_TA_YM')}'                                          -- 기준년월
          , t10.cs_no                                                       -- 그룹md번호
          , t10.lnco_no                                                     -- 거래식별번호
          , current_timestamp at time zone 'asia/seoul'                     -- aws적재일시
          , case when t10.lnco_sc_cd = '10'    then    'L21'
                 when t10.lnco_sc_cd = '20'    then    'L22'
            else 'L2Z'
             end                                                            -- 데이터댐상품분류코드
          , case when t10.lon_stat_cd = '01' then '1'
            else '0' end                                                    -- 정상tf
          , t10.lon_stat_cd                                                 -- 신한라이프계약상태코드
          , t10.lon_ymd                                                     -- 최초가입일자
          , t10.eprt_ymd                                                    -- 주계약만기일자
          , t10.eprt_ymd                                                    -- 소멸일자
          , null                                                            -- 신한라이프판매채널구분코드
       from shl.fn_mmln t10
       left outer join shl.pr_intvcd t11
         on t11.inty_cd = t10.lon_good_cd
      where t10.clos_ym = '{date_cd('P_TA_YM')}'
        and t10.lnco_sc_cd = '10'
        and t11.inty_nm_sc_cd in ('B')
"""

"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""                     
insert_sql_for_tmp = [insert_sql_for_tmp_1]


"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shlmpdt001_tmp99', 'pk': ['ta_ym', 'shmdn', 'ts_dtn_n']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh1.shlmpdt001
    where TA_YM = '{date_cd('P_TA_YM')}'
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh1.shlmpdt001
    select *
    from tmp_sh1.shlmpdt001_tmp99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]
### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end