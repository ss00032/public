# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "윤혁준"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["윤혁준"]
__version__    = "1.0"
__maintainer__ = "윤혁준"
__email__      = "ss00032@xgm.co.kr"
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID  : IBTM_SHCMPDT003_TG
  - 한글 테이블명: PDT_월오토금융대출상품기본_카드
  - TMP_SH1 테이블명: tmp_sh1.shcmpdt003_tmp99
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHCMPDT003_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = 'PDT_월오토금융대출상품기본_카드'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

##날짜변수 사용관련 
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

# 적재 스키마명
target_schema = 'sh1'
tmp_schema = 'tmp_sh1'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shcmpdt003_tmp99']
"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh1.shcmpdt003_tmp99
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹md번호
         , ln_n                                   -- 대출번호
         , aws_ld_dt                              -- aws적재일시
         , bsn_pd_cd                              -- 영업상품코드
         , fnc_hdg_pd_cd                          -- 오토금융취급상품코드
         , ln_pd_zcd                              -- 대출상품분류코드
         , mfg_gp_cd                              -- 제품그룹코드
         , nn_ir_ccd                              -- 무이자구분코드
         , ln_trm_ms_cn                           -- 대출기간개월수
         , sub_nn_ir_ms_cn                        -- 부분무이자개월수
         , pv_py_mcd                              -- 대표상환방법코드
         , ftt_irt_f                              -- 변동금리여부
         , ivl_ira                                -- 실효이자금액
         , pyf_tf                                 -- 완납tf
         , ln_d                                   -- 대출일자
         , de_d                                   -- 확정일자
         , xp_d                                   -- 만기일자
         , ni_st_d                                -- 최초결제일자
         , ls_bil_d                               -- 최종청구일자
         , ls_bil_dgt                             -- 최종청구회차
         , ls_rip_d                               -- 최종수납일자
         , ce_f                                   -- 취소여부
         , ce_d                                   -- 취소일자
         , ln_su_mf_cd                            -- 대출상태변경코드
         , suc_f                                  -- 승계여부
         , rv_hcd                                 -- 접수지점코드
         , ln_hcd                                 -- 대출지점코드
         , ln_al                                  -- 대출잔액
         , lna                                    -- 대출금액
         )
    select '{date_cd('P_TA_YM')}'                 -- 기준년월
         , sgdmd                                  -- 그룹md번호
         , ln_n                                   -- 대출번호
         , current_timestamp at time zone 'asia/seoul'
         , bsn_pd_cd                              -- 영업상품코드
         , fnc_hdg_pd_cd                          -- 오토금융취급상품코드
         , ln_pd_zcd                              -- 대출상품분류코드
         , mfg_gp_cd                              -- 제품그룹코드
         , nn_ir_ccd                              -- 무이자구분코드
         , ln_trm_ms_cn                           -- 대출기간개월수
         , sub_nn_ir_ms_cn                        -- 부분무이자개월수
         , pv_py_mcd                              -- 대표상환방법코드
         , ftt_irt_f                              -- 변동금리여부
         , ivl_ira                                -- 실효이자금액
         , pyf_tf                                 -- 완납tf
         , ln_d                                   -- 대출일자
         , de_d                                   -- 확정일자
         , xp_d                                   -- 만기일자
         , ni_st_d                                -- 최초결제일자
         , ls_bil_d                               -- 최종청구일자
         , ls_bil_dgt                             -- 최종청구회차
         , ls_rip_d                               -- 최종수납일자
         , ce_f                                   -- 취소여부
         , ce_d                                   -- 취소일자
         , ln_su_mf_cd                            -- 대출상태변경코드
         , suc_f                                  -- 승계여부
         , rv_hcd                                 -- 접수지점코드
         , ln_hcd                                 -- 대출지점코드
         , ln_al                                  -- 대출잔액
         , lna                                    -- 대출금액
      from shc.swoac0020
     where ta_ym = '{date_cd('P_TA_YM')}'
       and pyf_tf = '0'
"""

"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""                     
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shcmpdt003_tmp99', 'pk': ['ta_ym', 'shmdn', 'ln_n']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh1.shcmpdt003
    where TA_YM = '{date_cd('P_TA_YM')}'
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh1.shcmpdt003
    select *
    from tmp_sh1.shcmpdt003_tmp99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]
### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end