# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "노재홍"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["노재홍"]
__version__    = "1.0"
__maintainer__ = "노재홍"
__email__      = ""
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 한글 테이블명
  - TMP_SH1 테이블명
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHCMPDT001_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L1상품) PDT_월카드상품기본_카드 배치프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh1'
tmp_schema = 'tmp_sh1'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shcmpdt001_tmp99']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh1.shcmpdt001_tmp99                                        -- PDT_월카드상품기본_카드_TMP99
    (
           ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹md번호
         , crd_rpl_n                                                            -- 카드대체번호
         , aws_ld_dt                                                            -- aws적재일시
         , cus_ccd                                                              -- 회원구분코드
         , crd_tcd                                                              -- 카드유형코드
         , o_fml_ccd                                                            -- 본인가족구분코드
         , crd_pd_n                                                             -- 카드상품번호
         , crd_pdg_tcd                                                          -- 카드상품군유형코드
         , cct1_crd_pd_n                                                        -- 개념1카드상품번호
         , cct2_crd_pd_n                                                        -- 개념2카드상품번호
         , o_crd_tf                                                             -- 본인카드tf
         , fml_crd_tf                                                           -- 가족카드tf
         , cre_crd_tf                                                           -- 신용카드tf
         , chc_tf                                                               -- 체크카드tf
         , wf_crd_tf                                                            -- 복지카드tf
         , trf_crd_tf                                                           -- 교통카드tf
         , crd_afl_tf                                                           -- 카드제휴tf
         , afe_exo_tf                                                           -- 연회비면제tf
         , el_crd_tf                                                            -- 삭제카드tf
         , xp_crd_tf                                                            -- 만기카드tf
         , ivd_crd_tf                                                           -- 무효카드tf
         , ivd_bl_rr_crd_tf                                                     -- 무효bl등재카드tf
         , sp_bl_rr_crd_tf                                                      -- 정지bl등재카드tf
         , lm_rst_ef_crd_tf                                                     -- 한도제한적용카드tf
         , rlp_crd_tf                                                           -- 실질카드tf
         , lat_crd_tf                                                           -- 신규카드tf
         , scs_crd_tf                                                           -- 탈회카드tf
         , me_crd_tf                                                            -- 해지카드tf
         , sln_lot_crd_tf                                                       -- 도난분실카드tf
         , ts_sp_crd_tf                                                         -- 거래정지카드tf
         , ris_iac_ccd                                                          -- 재발급휴면구분코드
         , ris_crd_tf                                                           -- 재발급카드tf
         , rw_bj_crd_tf                                                         -- 갱신대상카드tf
         , au_rw_crd_tf                                                         -- 자동갱신카드tf
         , crd_rw_be_tf                                                         -- 카드갱신가능tf
         , ies_rw_tf                                                            -- 조기갱신tf
         , imd_iss_pt_tf                                                        -- 즉시발급신청tf
         , cut_iss_crd_tf                                                       -- 부정발급카드tf
         , bse_crd_tf                                                           -- 기본카드tf
         , cs_ruf_giv_tf                                                        -- 현금기능부여tf
         , crd_de_ce_tf                                                         -- 카드확정취소tf
         , rw_xl_tf                                                             -- 갱신제외tf
         , scs_ccd                                                              -- 탈회구분코드
         , crd_lok_ccd                                                          -- 카드외형구분코드
         , trf_ruf_ccd                                                          -- 교통기능구분코드
         , crd_brd_cd                                                           -- 카드브랜드코드
         , iss_elp_dd_cn                                                        -- 발급경과일수
         , iss_elp_ms_cn                                                        -- 발급경과개월수
         , afe_bil_cy_m                                                         -- 연회비청구주기월
         , crd_bl_rr_tf                                                         -- 카드bl등재tf
         , crd_su_tcd                                                           -- 카드상태유형코드
         , crd_su_ccd                                                           -- 카드상태구분코드
         , crd_pt_ps_tcd                                                        -- 카드신청처리유형코드
         , crd_de_d                                                             -- 카드확정일자
         , crd_pt_d                                                             -- 카드신청일자
         , crd_iss_d                                                            -- 카드발급일자
         , ent_rid                                                              -- 입회접수일자
         , ent_rv_sn                                                            -- 입회접수순번
         , crd_clt_mcd                                                          -- 카드모집방법코드
         , pv_hcd                                                               -- 대표지점코드
         , clt_hcd                                                              -- 모집지점코드
         , nr_hcd                                                               -- 관리지점코드
         , cll_tcd                                                              -- 모집인유형코드
         , cre_cl_hga                                                           -- 신용신판취급금액
         , chc_hga                                                              -- 체크카드취급금액
         , p_hga                                                                -- 일시불취급금액
         , ns_hga                                                               -- 할부취급금액
         , vv_cl_hga                                                            -- 리볼빙신판취급금액
         , vv_cv_hga                                                            -- 리볼빙현금서비스취급금액
         , cv_hga                                                               -- 현금서비스취급금액
    )
    select t10.ta_ym                                                            -- 기준년월
         , t10.sgdmd                                                            -- 그룹MD번호
         , t10.crd_rpl_n                                                        -- 카드대체번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         --  상품속성(상품코드)
         , t10.cus_ccd                                                          -- 회원구분코드
         , t10.crd_tcd                                                          -- 카드유형코드
         , t10.o_fml_ccd                                                        -- 본인가족구분코드
         , t10.crd_pd_n                                                         -- 카드상품번호
         , t10.crd_pdg_tcd                                                      -- 카드상품군유형코드
         , t10.cct1_crd_pd_n                                                    -- 개념1카드상품번호
         , t10.cct2_crd_pd_n                                                    -- 개념2카드상품번호
         -- 상품상세속성
         , t10.o_crd_tf                                                         -- 본인카드
         , t10.fml_crd_tf                                                       -- 가족카드tf
         , t10.cre_crd_tf                                                       -- 신용카드tf
         , t10.chc_tf                                                           -- 체크카드tf
         , t10.wf_crd_tf                                                        -- 복지카드
         , t10.trf_crd_tf                                                       -- 교통카드tf
         , t10.crd_afl_tf                                                       -- 카드제휴tf
         , t10.afe_exo_tf                                                       -- 연회비면제tf
         , t10.el_crd_tf                                                        -- 삭제카드tf
         , t10.xp_crd_tf                                                        -- 만기카드tf
         , t10.ivd_crd_tf                                                       -- 무효카드tf
         , t10.ivd_bl_rr_crd_tf                                                 -- 무효bl등재카드tf
         , t10.sp_bl_rr_crd_tf                                                  -- 정지bl등재카드tf
         , t10.lm_rst_ef_crd_tf                                                 -- 한도제한적용카드tf
         , t10.rlp_crd_tf                                                       -- 실질카드tf
         , t10.lat_crd_tf                                                       -- 신규카드tf
         , t10.scs_crd_tf                                                       -- 탈회카드tf
         , t10.me_crd_tf                                                        -- 해지카드tf
         , t10.sln_lot_crd_tf                                                   -- 도난분실카드tf
         , t10.ts_sp_crd_tf                                                     -- 거래정지카드tf
         , t10.ris_iac_ccd                                                      -- 재발급휴면구분코드
         , t10.ris_crd_tf                                                       -- 재발급카드tf
         , t10.rw_bj_crd_tf                                                     -- 갱신대상카드tf
         , t10.au_rw_crd_tf                                                     -- 자동갱신카드tf
         , t10.crd_rw_be_tf                                                     -- 카드갱신가능tf
         , t10.ies_rw_tf                                                        -- 조기갱신tf
         , t10.imd_iss_pt_tf                                                    -- 즉시발급신청tf
         , t10.cut_iss_crd_tf                                                   -- 부정발급카드tf
         , t10.bse_crd_tf                                                       -- 기본카드tf
         , t10.cs_ruf_giv_tf                                                    -- 현금기능부여tf
         , t10.crd_de_ce_tf                                                     -- 카드확정취소tf
         , t10.rw_xl_tf                                                         -- 갱신제외tf
         , t10.scs_ccd                                                          -- 탈회구분코드
         , t10.crd_lok_ccd                                                      -- 카드외형구분코드
         , t10.trf_ruf_ccd                                                      -- 교통기능구분코드
         , t10.crd_brd_cd                                                       -- 카드브랜드코드
         , t10.iss_elp_dd_cn                                                    -- 발급경과일수
         , t10.iss_elp_ms_cn                                                    -- 발급경과개월수
         , t10.afe_bil_cy_m                                                     -- 연회비청구주기월
         , t10.crd_bl_rr_tf                                                     -- 카드bl등재tf
         -- 상품상태속성
         , t10.crd_su_tcd                                                       -- 카드상태유형코드
         , t10.crd_su_ccd                                                       -- 카드상태구분코드
         , t10.crd_pt_ps_tcd                                                    -- 카드신청처리유형코드
         -- 상품일자속성
         , t10.crd_de_d                                                         -- 카드확정일자
         , t10.crd_pt_d                                                         -- 카드신청일자
         , t10.crd_iss_d                                                        -- 카드발급일자
         , t10.ent_rid                                                          -- 입회접수일자
         , t10.ent_rv_sn                                                        -- 입회접수순번
        -- 상품채널속성
         , t10.crd_clt_mcd                                                      -- 카드모집방법코드
         , t10.pv_hcd                                                           -- 대표지점코드
         , t10.clt_hcd                                                          -- 모집지점코드
         , t10.nr_hcd                                                           -- 관리지점코드
         , t10.cll_tcd                                                          -- 모집인유형코드
         -- 실적항목
         , nvl(t11.cre_cl_hga, 0)                          as cre_cl_hga        -- 신용신판취급금액
         , nvl(t11.chc_hga   , 0)                          as chc_hga           -- 체크카드취급금액
         , nvl(t11.p_hga     , 0)                          as p_hga             -- 일시불취급금액
         , nvl(t11.ns_hga    , 0)                          as ns_hga            -- 할부취급금액
         , nvl(t11.vv_cl_hga , 0)                          as vv_cl_hga         -- 리볼빙신판취급금액
         , nvl(t11.vv_cv_hga , 0)                          as vv_cv_hga         -- 리볼빙현금서비스취급금액
         , nvl(t11.cv_hga    , 0)                          as cv_hga            -- 현금서비스취급금액
      from shc.mtdia0001                         t10                            -- 월카드디멘젼
      left outer join
           shc.mtfua0002                         t11                            -- 월카드매출
        on t10.ta_ym = t11.ta_ym                                                -- 기준년월
       and t10.sgdmd = t11.sgdmd                                                -- 그룹MD번호
       and t10.crd_rpl_n = t11.crd_rpl_n                                        -- 카드대체번호
     where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
       and t10.crd_su_tcd = 'S'                                                 -- 카드상태유형코드(실질 카드)
"""

"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shcmpdt001_tmp99', 'pk': ['ta_ym', 'shmdn', 'crd_rpl_n']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh1.shcmpdt001                                                  -- PDT_월카드상품기본_카드
     where ta_ym= '{date_cd('P_TA_YM')}'                                        -- 기준일자
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh1.shcmpdt001                                                  -- PDT_월카드상품기본_카드
    (
           ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹md번호
         , crd_rpl_n                                                            -- 카드대체번호
         , aws_ld_dt                                                            -- aws적재일시
         , cus_ccd                                                              -- 회원구분코드
         , crd_tcd                                                              -- 카드유형코드
         , o_fml_ccd                                                            -- 본인가족구분코드
         , crd_pd_n                                                             -- 카드상품번호
         , crd_pdg_tcd                                                          -- 카드상품군유형코드
         , cct1_crd_pd_n                                                        -- 개념1카드상품번호
         , cct2_crd_pd_n                                                        -- 개념2카드상품번호
         , o_crd_tf                                                             -- 본인카드tf
         , fml_crd_tf                                                           -- 가족카드tf
         , cre_crd_tf                                                           -- 신용카드tf
         , chc_tf                                                               -- 체크카드tf
         , wf_crd_tf                                                            -- 복지카드tf
         , trf_crd_tf                                                           -- 교통카드tf
         , crd_afl_tf                                                           -- 카드제휴tf
         , afe_exo_tf                                                           -- 연회비면제tf
         , el_crd_tf                                                            -- 삭제카드tf
         , xp_crd_tf                                                            -- 만기카드tf
         , ivd_crd_tf                                                           -- 무효카드tf
         , ivd_bl_rr_crd_tf                                                     -- 무효bl등재카드tf
         , sp_bl_rr_crd_tf                                                      -- 정지bl등재카드tf
         , lm_rst_ef_crd_tf                                                     -- 한도제한적용카드tf
         , rlp_crd_tf                                                           -- 실질카드tf
         , lat_crd_tf                                                           -- 신규카드tf
         , scs_crd_tf                                                           -- 탈회카드tf
         , me_crd_tf                                                            -- 해지카드tf
         , sln_lot_crd_tf                                                       -- 도난분실카드tf
         , ts_sp_crd_tf                                                         -- 거래정지카드tf
         , ris_iac_ccd                                                          -- 재발급휴면구분코드
         , ris_crd_tf                                                           -- 재발급카드tf
         , rw_bj_crd_tf                                                         -- 갱신대상카드tf
         , au_rw_crd_tf                                                         -- 자동갱신카드tf
         , crd_rw_be_tf                                                         -- 카드갱신가능tf
         , ies_rw_tf                                                            -- 조기갱신tf
         , imd_iss_pt_tf                                                        -- 즉시발급신청tf
         , cut_iss_crd_tf                                                       -- 부정발급카드tf
         , bse_crd_tf                                                           -- 기본카드tf
         , cs_ruf_giv_tf                                                        -- 현금기능부여tf
         , crd_de_ce_tf                                                         -- 카드확정취소tf
         , rw_xl_tf                                                             -- 갱신제외tf
         , scs_ccd                                                              -- 탈회구분코드
         , crd_lok_ccd                                                          -- 카드외형구분코드
         , trf_ruf_ccd                                                          -- 교통기능구분코드
         , crd_brd_cd                                                           -- 카드브랜드코드
         , iss_elp_dd_cn                                                        -- 발급경과일수
         , iss_elp_ms_cn                                                        -- 발급경과개월수
         , afe_bil_cy_m                                                         -- 연회비청구주기월
         , crd_bl_rr_tf                                                         -- 카드bl등재tf
         , crd_su_tcd                                                           -- 카드상태유형코드
         , crd_su_ccd                                                           -- 카드상태구분코드
         , crd_pt_ps_tcd                                                        -- 카드신청처리유형코드
         , crd_de_d                                                             -- 카드확정일자
         , crd_pt_d                                                             -- 카드신청일자
         , crd_iss_d                                                            -- 카드발급일자
         , ent_rid                                                              -- 입회접수일자
         , ent_rv_sn                                                            -- 입회접수순번
         , crd_clt_mcd                                                          -- 카드모집방법코드
         , pv_hcd                                                               -- 대표지점코드
         , clt_hcd                                                              -- 모집지점코드
         , nr_hcd                                                               -- 관리지점코드
         , cll_tcd                                                              -- 모집인유형코드
         , cre_cl_hga                                                           -- 신용신판취급금액
         , chc_hga                                                              -- 체크카드취급금액
         , p_hga                                                                -- 일시불취급금액
         , ns_hga                                                               -- 할부취급금액
         , vv_cl_hga                                                            -- 리볼빙신판취급금액
         , vv_cv_hga                                                            -- 리볼빙현금서비스취급금액
         , cv_hga                                                               -- 현금서비스취급금액
    )
    select ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹md번호
         , crd_rpl_n                                                            -- 카드대체번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , cus_ccd                                                              -- 회원구분코드
         , crd_tcd                                                              -- 카드유형코드
         , o_fml_ccd                                                            -- 본인가족구분코드
         , crd_pd_n                                                             -- 카드상품번호
         , crd_pdg_tcd                                                          -- 카드상품군유형코드
         , cct1_crd_pd_n                                                        -- 개념1카드상품번호
         , cct2_crd_pd_n                                                        -- 개념2카드상품번호
         , o_crd_tf                                                             -- 본인카드tf
         , fml_crd_tf                                                           -- 가족카드tf
         , cre_crd_tf                                                           -- 신용카드tf
         , chc_tf                                                               -- 체크카드tf
         , wf_crd_tf                                                            -- 복지카드tf
         , trf_crd_tf                                                           -- 교통카드tf
         , crd_afl_tf                                                           -- 카드제휴tf
         , afe_exo_tf                                                           -- 연회비면제tf
         , el_crd_tf                                                            -- 삭제카드tf
         , xp_crd_tf                                                            -- 만기카드tf
         , ivd_crd_tf                                                           -- 무효카드tf
         , ivd_bl_rr_crd_tf                                                     -- 무효bl등재카드tf
         , sp_bl_rr_crd_tf                                                      -- 정지bl등재카드tf
         , lm_rst_ef_crd_tf                                                     -- 한도제한적용카드tf
         , rlp_crd_tf                                                           -- 실질카드tf
         , lat_crd_tf                                                           -- 신규카드tf
         , scs_crd_tf                                                           -- 탈회카드tf
         , me_crd_tf                                                            -- 해지카드tf
         , sln_lot_crd_tf                                                       -- 도난분실카드tf
         , ts_sp_crd_tf                                                         -- 거래정지카드tf
         , ris_iac_ccd                                                          -- 재발급휴면구분코드
         , ris_crd_tf                                                           -- 재발급카드tf
         , rw_bj_crd_tf                                                         -- 갱신대상카드tf
         , au_rw_crd_tf                                                         -- 자동갱신카드tf
         , crd_rw_be_tf                                                         -- 카드갱신가능tf
         , ies_rw_tf                                                            -- 조기갱신tf
         , imd_iss_pt_tf                                                        -- 즉시발급신청tf
         , cut_iss_crd_tf                                                       -- 부정발급카드tf
         , bse_crd_tf                                                           -- 기본카드tf
         , cs_ruf_giv_tf                                                        -- 현금기능부여tf
         , crd_de_ce_tf                                                         -- 카드확정취소tf
         , rw_xl_tf                                                             -- 갱신제외tf
         , scs_ccd                                                              -- 탈회구분코드
         , crd_lok_ccd                                                          -- 카드외형구분코드
         , trf_ruf_ccd                                                          -- 교통기능구분코드
         , crd_brd_cd                                                           -- 카드브랜드코드
         , iss_elp_dd_cn                                                        -- 발급경과일수
         , iss_elp_ms_cn                                                        -- 발급경과개월수
         , afe_bil_cy_m                                                         -- 연회비청구주기월
         , crd_bl_rr_tf                                                         -- 카드bl등재tf
         , crd_su_tcd                                                           -- 카드상태유형코드
         , crd_su_ccd                                                           -- 카드상태구분코드
         , crd_pt_ps_tcd                                                        -- 카드신청처리유형코드
         , crd_de_d                                                             -- 카드확정일자
         , crd_pt_d                                                             -- 카드신청일자
         , crd_iss_d                                                            -- 카드발급일자
         , ent_rid                                                              -- 입회접수일자
         , ent_rv_sn                                                            -- 입회접수순번
         , crd_clt_mcd                                                          -- 카드모집방법코드
         , pv_hcd                                                               -- 대표지점코드
         , clt_hcd                                                              -- 모집지점코드
         , nr_hcd                                                               -- 관리지점코드
         , cll_tcd                                                              -- 모집인유형코드
         , cre_cl_hga                                                           -- 신용신판취급금액
         , chc_hga                                                              -- 체크카드취급금액
         , p_hga                                                                -- 일시불취급금액
         , ns_hga                                                               -- 할부취급금액
         , vv_cl_hga                                                            -- 리볼빙신판취급금액
         , vv_cv_hga                                                            -- 리볼빙현금서비스취급금액
         , cv_hga                                                               -- 현금서비스취급금액
      from tmp_sh1.shcmpdt001_tmp99                                             -- PDT_월카드상품기본_카드_TMP99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end