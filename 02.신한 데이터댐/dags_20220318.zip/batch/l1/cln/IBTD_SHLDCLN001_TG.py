# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "이종호"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["이종호"]
__version__    = "1.0"
__maintainer__ = "이종호"
__email__      = "hijack72@xgm.co.kr"
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상   : CLN_일고객마스터_라이프
  - 프로그램 ID : IBTD_SHLDCLN001_TG
  - 한글 테이블명: CLN_일고객마스터_라이프
  - TMP_SH1 테이블명
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTD_SHLDCLN001_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L1고객) CLN_일고객마스터_라이프 배치프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh1'
tmp_schema = 'tmp_sh1'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""

tmp_sh1_table = ['shldcln001_tmp99']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh1.shldcln001_tmp99
         (
           shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , cln_xp_age                             -- 고객만기연령
         , sex_ccd                                -- 성별구분코드
         , age_ccd                                -- 연령구분코드
         , age_y5_blk_cd                          -- 연령5년구간코드
         , lcr_tf                                 -- 내국인TF
         , shl_tps_clb_gcd                        -- 신한라이프탑스클럽등급코드
         , shp_tps_clb_gcd                        -- 신한그룹탑스클럽등급코드
         , ni_ts_d                                -- 최초거래일자
         , atv_tf                                 -- 활동TF
         , hm_zpn                                 -- 자택우편번호
         , hm_abn_nm                              -- 자택행정동명
         , hm_cou_gds_apb_cd                      -- 자택법정GDS동코드
         )
    select t10.cs_no                                                            --그룹MD번호
         , current_timestamp at time zone 'asia/seoul'                          --AWS적재일시
         , max(t10.cst_fage_ag)                                                      --고객만기연령
         , max(case when t10.gndr_sc_cd = '1' then 'M'
                    when t10.gndr_sc_cd = '2' then 'F'
               end)                                                                  --성별구분코드
         , max(case when t10.cst_fage_ag between 10 and 19 then '01'
                    when t10.cst_fage_ag between 20 and 29 then '02'
                    when t10.cst_fage_ag between 30 and 39 then '03'
                    when t10.cst_fage_ag between 40 and 49 then '04'
                    when t10.cst_fage_ag between 50 and 59 then '05'
                    when t10.cst_fage_ag between 60 and 69 then '06'
                    when t10.cst_fage_ag between 70 and 79 then '07'
                    when t10.cst_fage_ag >= 80             then '08'
               end)                                                                  --연령구분코드
         , max(case when t10.cst_fage_ag  < 15                          then '001'
                    when t10.cst_fage_ag >= 15 and t10.cst_fage_ag < 20 then '002'
                    when t10.cst_fage_ag >= 20 and t10.cst_fage_ag < 25 then '003'
                    when t10.cst_fage_ag >= 25 and t10.cst_fage_ag < 30 then '004'
                    when t10.cst_fage_ag >= 30 and t10.cst_fage_ag < 35 then '005'
                    when t10.cst_fage_ag >= 35 and t10.cst_fage_ag < 40 then '006'
                    when t10.cst_fage_ag >= 40 and t10.cst_fage_ag < 45 then '007'
                    when t10.cst_fage_ag >= 45 and t10.cst_fage_ag < 50 then '008'
                    when t10.cst_fage_ag >= 50 and t10.cst_fage_ag < 55 then '009'
                    when t10.cst_fage_ag >= 55 and t10.cst_fage_ag < 60 then '010'
                    when t10.cst_fage_ag >= 60 and t10.cst_fage_ag < 65 then '011'
                    when t10.cst_fage_ag >= 65 and t10.cst_fage_ag < 70 then '012'
                    when t10.cst_fage_ag >= 70 and t10.cst_fage_ag < 75 then '013'
                    when t10.cst_fage_ag >= 75 and t10.cst_fage_ag < 80 then '014'
                    when t10.cst_fage_ag >= 80                          then '015'
               end)                                                                  --연령5년구간코드
         , max(case when t10.cst_dtpt_type_cd = '11' then 1
                    else 0
               end)                                                                  --내외국인여부
         , min(case when t11.new_tops_shli_apm_cst_grd_cd = '1'        then '01'  --프리미어
                    when t11.new_tops_shli_apm_cst_grd_cd = '2'        then '02'  --에이스
                    when t11.new_tops_shli_apm_cst_grd_cd = '3'        then '03'  --베스트
                    when t11.new_tops_shli_apm_cst_grd_cd = '4'        then '04'  --클래식
                    when t11.new_tops_shli_apm_cst_grd_cd in ('5','9') then '09'  --일반고객
                    when t11.new_tops_shli_apm_cst_grd_cd = '6'        then '06'  --프리미어++
                    when t11.new_tops_shli_apm_cst_grd_cd = '7'        then '07'  --프리미어+
                    when t11.new_tops_shli_apm_cst_grd_cd = 'Z'        then '99'  --비대상
               end)                                                             --신한라이프탑스클럽등급코드
         , min(case when t11.new_tops_unfc_cst_grd_cd = '1'        then '01'  --프리미어
                    when t11.new_tops_unfc_cst_grd_cd = '2'        then '02'  --에이스
                    when t11.new_tops_unfc_cst_grd_cd = '3'        then '03'  --베스트
                    when t11.new_tops_unfc_cst_grd_cd = '4'        then '04'  --클래식
                    when t11.new_tops_unfc_cst_grd_cd in ('5','9') then '09'  --일반고객
                    when t11.new_tops_unfc_cst_grd_cd = '6'        then '06'  --프리미어++
                    when t11.new_tops_unfc_cst_grd_cd = '7'        then '07'  --프리미어+
                    when t11.new_tops_unfc_cst_grd_cd = 'Z'        then '99'  --비대상
               end)                                                             -- 신규tops통합고객등급코드
         , max(t10.frst_cst_rgi_ymd        )                                    -- 최초거래일자
         , null                                                                 -- 활동TF
         , max(t10.home_new_zip_no)                                             -- 자택우편번호
         , max(t12.advi_nm        )                                             -- 자택행정동명
         , max(t12.stdo_cd        )                                             -- 자택법정GDS동코드
      from shl.dm_mthl_cust      t10                                            -- dm_월별고객
      left outer join shl.cs_groutops_his   t11                                 -- cs_그룹tops이력
        on t10.str_ym = t11.str_ym                                              -- 기준년월
       and t10.cs_no  = t11.gpco_unfc_cst_mda_no
      left outer join shl.cs_newzip_cod t12                                     --cs_우편번호
        on t10.home_new_zip_no         = t12.new_zip_no                         --자택새우편번호 = 새우편번호
       and t10.home_new_zip_no_sria_no = t12.new_zip_no_sria_no                 --자택새우편번호일련번호 = 새우편번호일련번호
     where t10.str_ym = (select max(str_ym) from shl.dm_mthl_cust)              --최근 적재데이터추출
       and t10.cst_type_cd = '1'                                                --개인고객
     group by t10.cs_no
"""

"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shldcln001_tmp99', 'pk': ['shmdn']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh1.shldcln001                                                  -- CLN_일고객마스터_라이프
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh1.shldcln001                                                  -- CLN_일고객마스터_라이프
    (
           shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , cln_xp_age                             -- 고객만기연령
         , sex_ccd                                -- 성별구분코드
         , age_ccd                                -- 연령구분코드
         , age_y5_blk_cd                          -- 연령5년구간코드
         , lcr_tf                                 -- 내국인TF
         , shl_tps_clb_gcd                        -- 신한라이프탑스클럽등급코드
         , shp_tps_clb_gcd                        -- 신한그룹탑스클럽등급코드
         , ni_ts_d                                -- 최초거래일자
         , atv_tf                                 -- 활동TF
         , hm_zpn                                 -- 자택우편번호
         , hm_abn_nm                              -- 자택행정동명
         , hm_cou_gds_apb_cd                      -- 자택법정GDS동코드
    )
    select shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , cln_xp_age                             -- 고객만기연령
         , sex_ccd                                -- 성별구분코드
         , age_ccd                                -- 연령구분코드
         , age_y5_blk_cd                          -- 연령5년구간코드
         , lcr_tf                                 -- 내국인TF
         , shl_tps_clb_gcd                        -- 신한라이프탑스클럽등급코드
         , shp_tps_clb_gcd                        -- 신한그룹탑스클럽등급코드
         , ni_ts_d                                -- 최초거래일자
         , atv_tf                                 -- 활동TF
         , hm_zpn                                 -- 자택우편번호
         , hm_abn_nm                              -- 자택행정동명
         , hm_cou_gds_apb_cd                      -- 자택법정GDS동코드
      from tmp_sh1.shldcln001_tmp99               -- CLN_일고객마스터_라이프_TMP99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end