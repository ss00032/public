# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "노재홍"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["노재홍"]
__version__    = "1.0"
__maintainer__ = "노재홍"
__email__      = ""
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 한글 테이블명
  - TMP_SH1 테이블명
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHCMTRS002_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L1거래) TRS_월개인사업자자산실적_카드 배치프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh1'
tmp_schema = 'tmp_sh1'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shcmtrs002_tmp99']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh1.shcmtrs002_tmp99                                        -- TRS_월개인사업자자산실적_카드_TMP99
    (
           ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , brn                                                                  -- 사업자등록번호
         , aws_ld_dt                                                            -- AWS적재일시
         , shc_hga                                                              -- 신한카드취급금액
    )
    select t10.ta_ym                                                            -- 기준년월
         , t10.rpk_sgdmd                                as shmdn                -- 그룹MD번호(대표자그룹MD번호)
         , t10.mct_brn                                  as brn                  -- 사업자등록번호(가맹점사업자등록번호)
         , current_timestamp AT TIME ZONE 'Asia/Seoul'  as aws_ld_dt            -- AWS적재일시
         , nvl(sum(t11.hga), 0)                         as shc_hga              -- 신한카드취급금액취급금액(취급금액)
      from shc.mtdia0005                         t10                            -- 월가맹점디멘젼
      left outer join
           shc.mtfua0017                         t11                            -- 월가맹점매출
        on t10.ta_ym = t11.ta_ym                                                -- 기준년월
       and t10.mct_n = t11.mct_n                                                -- 가맹점번호
     where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
       and t10.psn_etk_tf = 1                                                   -- 개인사업자TF
       and t10.rlp_mct_tf = 1                                                   -- 실질가맹점TF
     group by
           t10.ta_ym                                                            -- 기준년월
         , t10.rpk_sgdmd                                                        -- 대표자그룹MD번호
         , t10.mct_brn                                                          -- 가맹점사업자등록번호
"""

"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shcmtrs002_tmp99', 'pk': ['ta_ym', 'shmdn', 'brn']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh1.shcmtrs002                                                  -- TRS_월개인사업자자산실적_카드
     where ta_ym = '{date_cd('P_TA_YM')}'                                       -- 기준년월
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh1.shcmtrs002                                                  -- TRS_월개인사업자자산실적_카드
    (
           ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , brn                                                                  -- 사업자등록번호
         , aws_ld_dt                                                            -- AWS적재일시
         , shc_hga                                                              -- 신한카드취급금액
    )
    select ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , brn                                                                  -- 사업자등록번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , shc_hga                                                              -- 신한카드취급금액
      from tmp_sh1.shcmtrs002_tmp99                                             -- TRS_월개인사업자자산실적_카드_TMP99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end