# -*- coding: utf-8 -*-

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *


__author__     = "이일주"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["이일주"]
__version__    = "1.0"
__maintainer__ = "이일주"
__email__      = "LEE1122334@xgm.co.kr"
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID  : IBTM_SHLMTRS001_TG
  - 한글 테이블명: TRS_월고객계좌거래실적_라이프
  - TMP_SH1 테이블명: tmp_sh1.shlmtrs001_tmp99
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHLMTRS001_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = 'TRS_월고객계좌거래실적_라이프'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

##날짜변수 사용관련 
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

# 적재 스키마명
target_schema = 'sh1'
tmp_schema = 'tmp_sh1'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shlmtrs001_tmp99']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh1.shlmtrs001_tmp99
         (
           ta_ym
         , shmdn
         , ts_dtn_n
         , shd_pd_zcd
         , aws_ld_dt
         , to_ts_ct
         , lat_ct
         , me_ct
         , rcp_ct
         , aow_ct
         , to_ts_at
         , lat_at
         , me_at
         , aow_at
         , rca
         , pra_at
         , al
         )
    select t10.str_ym                                          as ta_ym             -- 기준년월
         , t10.cs_no                                           as shmdn             -- 그룹MD번호
         , t10.inon_no                                         as ts_dtn_n          -- 거래식별번호
         , t10.good_cd                                         as shd_pd_zcd        -- 데이터댐상품분류코드
         , current_timestamp AT TIME ZONE 'Asia/Seoul'         as aws_ld_dt
         , sum(t10.a_cnt + t10.b_cnt + t10.c_cnt + t10.d_cnt
             + t10.e_cnt + t10.f_cnt + t10.g_cnt)              as to_ts_ct          -- 총거래건수
         , sum(t10.a_cnt + t10.b_cnt)                          as lat_ct            -- 신규건수
         , sum(t10.c_cnt)                                      as me_ct             -- 해지건수
         , sum(t10.e_cnt + t10.f_cnt)                          as rcp_ct            -- 입금건수
         , sum(t10.d_cnt + t10.g_cnt)                          as aow_ct            -- 출금건수
         , sum(t10.a_amt + t10.b_amt + t10.c_amt + t10.d_amt
             + t10.e_amt + t10.f_amt + t10.g_amt)              as to_ts_at          -- 총거래금액
         , sum(t10.a_amt+t10.b_amt)                            as lat_at            -- 신규금액
         , sum(t10.c_amt)                                      as me_at             -- 해지금액
         , sum(t10.d_amt+t10.g_amt)                            as aow_at            -- 출금금액
         , sum(t10.e_amt+t10.f_amt)                            as rca               -- 입금금액
         , 0                                                   as pra_at            -- 실행금액
         , sum(t10.al)                                         as al                -- 대출잔액
      from (select t20.str_ym
                 , t20.cs_no
                 , t20.inon_no
                 , case when t20.ins_sbsn_good_smcl_cd = '06'
                        then 'L18'                                                  -- '변액보험'
                        when t20.ins_sbsn_good_lrcl_cd = '01'
                        then 'L11'                                                  -- '건강보험'
                        when t20.ins_sbsn_good_lrcl_cd = '05'
                        then 'L12'                                                  -- '상해보험'
                        when t20.ins_sbsn_good_lrcl_cd = '07'
                        then 'L13'                                                  -- '양로보험'
                        when t20.ins_sbsn_good_lrcl_cd = '08'
                        then 'L14'                                                  -- '어린이보험'
                        when t20.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then 'L15'                                                  -- '연금/저축/교육보험'
                        when t20.ins_sbsn_good_lrcl_cd = '12'
                        then 'L16'                                                  -- '종신보험'
                        when t20.ins_sbsn_good_lrcl_cd = '13'
                        then 'L17'                                                  -- '종합보험'
                        when t20.ins_sbsn_good_lrcl_cd = '11'
                        then 'L19'                                                  -- '제휴보험'
                        else 'L1Z'                                                  -- '기타보험'
                    end                                         as good_cd
                 , case when t20.suco_ym = t20.str_ym                               -- 청약년월
                         and t20.ctst_cd = 'A'
                        then 1
                        else 0
                    end                                         as a_cnt            -- 신계약건수
                 , case when t20.lst_inon_lon_ym = t20.str_ym                       -- 최종보험계약대출년월
                        then 1
                        else 0
                    end                                         as b_cnt            -- 보험계약대출건수
                 , case when t20.etnc_ym = t20.str_ym
                         and t20.ctst_cd = 'B'
                         and t20.fur_rs_cd in ('AA','AB','AC')                      -- 해약,만기,해지
                        then 1
                        else 0
                    end                                         as c_cnt            -- 해지건수
                 , case when t20.ctst_cd in ('A','C')                               -- 계약상태: 정상, 실효
                        then 1
                        else 0
                    end                                         as d_cnt            -- 보험료납입건수
                 , case when t20.fur_rs_cd in ('BA')                                -- 사고지급
                        then 1
                        else 0
                    end                                         as e_cnt            -- 보험금건수
                 , case when t20.fur_rs_cd in ('AD','AE','AF','AG')                 -- 분할,배당,중도인출,연금
                        then 1
                        else 0
                    end                                         as f_cnt            -- 제지급건수
                 , case when t20.fur_rs_cd in ('AI')                                -- 보험계약대출수납
                        then 1
                        else 0
                    end                                         as g_cnt            -- 보험계약대출수납건수
                 , case when t20.suco_ym = t20.str_ym
                         and t20.ctst_cd = 'A'
                        then t20.cmip
                        else 0
                    end                                         as a_amt            -- 신계약금액
                 , case when t20.lst_inon_lon_ym = t20.str_ym
                         and t20.tra_ym = t20.str_ym
                         and t20.fur_rs_cd in ('AH')
                        then t20.fur_am
                        else 0
                    end                                         as b_amt            -- 보험계약대출금액
                 , case when t20.etnc_ym = t20.str_ym
                         and t20.ctst_cd = 'B'
                         and t20.fur_rs_cd in ('AA','AB','AC')                      -- 해약,만기,해지
                        then 1
                        else 0
                    end                                         as c_amt            -- 해지금액
                 , case when t20.ctst_cd in ('A','C')                               -- 계약상태: 정상, 실효
                        then t20.cmip
                        else 0
                    end                                         as d_amt            -- 보험료납입금액
                 , case when t20.tra_ym = t20.str_ym
                         and t20.fur_rs_cd in ('BA')                                -- 사고지급
                        then t20.fur_am
                        else 0
                    end                                         as e_amt            -- 보험금지급금액
                 , case when t20.tra_ym = t20.str_ym
                         and t20.fur_rs_cd in ('AD','AE','AF','AG')                 -- 분할,배당,중도인출,연금
                        then t20.fur_am
                        else 0
                    end                                         as f_amt            -- 제지급지급금액
                 , case when t20.tra_ym = t20.str_ym
                         and t20.fur_rs_cd in ('AI')
                        then t20.myre_am
                        else 0
                    end                                         as g_amt            -- 보험계약대출수납금액
                 , sum(t20.inon_lrem_am)                        as al               -- 대출잔액
              from (select t30.str_ym
                         , t30.coor_cs_no                       as cs_no            -- 계약자고객번호(md변환)
                         , t30.inon_no
                         , t30.ctst_cd
                         , t30.ins_sbsn_good_smcl_cd
                         , t30.ins_sbsn_good_lrcl_cd
                         , to_char(t30.suco_ymd,'yyyymm')       as suco_ym          -- 청약년월
                         , to_char(t30.etnc_ymd,'yyyymm')       as etnc_ym          -- 소멸년월
                         , tra_ym                                                   -- 거래년월
                         , t31.cmip
                         , t31.inon_lrem_am                                         -- 보험계약대출잔액
                         , to_char(t31.lst_inon_lon_ymd,'yyyymm') as lst_inon_lon_ym -- 최종보험계약대출년월
                         , t32.fur_rs_cd
                         , t32.fur_am
                         , t32.myre_am
                      from shl.dm_mthl_con           t30                            -- dm_월별계약
                     inner join
                           shl.dm_mthl_con_anx_info  t31                            -- dm_월별계약부가정보
                        on t30.str_ym  = t31.str_ym
                       and t30.inon_no = t31.inon_no
                      left outer join
                           (select substring(tra_ymd,1,6)       as tra_ym
                                 , inon_no
                                 , fur_rs_cd
                                 , sum(fur_am)                  as fur_am
                                 , sum(myre_am)                 as myre_am
                              from shl.dm_py_det                                    -- dm_지급상세
                             where fur_can_sc_cd = '00'                             -- 정상
                               and substring(tra_ymd,1,6) = '{date_cd('P_TA_YM')}'
                             group by substring(tra_ymd,1,6)
                                    , inon_no
                                    , fur_rs_cd
                            ) t32
                        on t30.str_ym  = t32.tra_ym
                       and t30.inon_no = t32.inon_no
                     where t30.str_ym  = '{date_cd('P_TA_YM')}'
                       and t30.indv_asct_sc_cd = '01'                               -- 개인
                    ) t20
             group by t20.str_ym
                    , t20.cs_no
                    , t20.inon_no
                    , case when t20.ins_sbsn_good_smcl_cd = '06'
                           then 'L18'                                               -- '변액보험'
                           when t20.ins_sbsn_good_lrcl_cd = '01'
                           then 'L11'                                               -- '건강보험'
                           when t20.ins_sbsn_good_lrcl_cd = '05'
                           then 'L12'                                               -- '상해보험'
                           when t20.ins_sbsn_good_lrcl_cd = '07'
                           then 'L13'                                               -- '양로보험'
                           when t20.ins_sbsn_good_lrcl_cd = '08'
                           then 'L14'                                               -- '어린이보험'
                           when t20.ins_sbsn_good_lrcl_cd in ('09','10','02')
                           then 'L15'                                               -- '연금/저축/교육보험'
                           when t20.ins_sbsn_good_lrcl_cd = '12'
                           then 'L16'                                               -- '종신보험'
                           when t20.ins_sbsn_good_lrcl_cd = '13'
                           then 'L17'                                               -- '종합보험'
                           when t20.ins_sbsn_good_lrcl_cd = '11'
                           then 'L19'                                               -- '제휴보험'
                           else 'L1Z'                                               -- '기타보험'
                       end
                    , case when t20.suco_ym = t20.str_ym
                            and t20.ctst_cd = 'A'
                           then 1
                           else 0
                       end
                    , case when t20.lst_inon_lon_ym = t20.str_ym
                           then 1
                           else 0
                       end
                    , case when t20.etnc_ym = t20.str_ym
                            and t20.ctst_cd = 'B'
                            and t20.fur_rs_cd in ('AA','AB','AC')
                           then 1
                           else 0
                       end
                    , case when t20.ctst_cd in ('A','C')
                           then 1
                           else 0
                       end
                    , case when t20.fur_rs_cd in ('BA')
                           then 1
                           else 0
                       end
                    , case when t20.fur_rs_cd in ('AD','AE','AF','AG')
                           then 1
                           else 0
                       end
                    , case when t20.fur_rs_cd in ('AI')
                           then 1
                           else 0
                       end
                    , case when t20.suco_ym = t20.str_ym
                            and t20.ctst_cd = 'A'
                           then t20.cmip
                           else 0
                       end
                    , case when t20.lst_inon_lon_ym = t20.str_ym
                            and t20.tra_ym = t20.str_ym
                            and t20.fur_rs_cd in ('AH')
                           then t20.fur_am
                           else 0
                       end
                    , case when t20.etnc_ym = t20.str_ym
                            and t20.ctst_cd = 'B'
                            and t20.fur_rs_cd in ('AA','AB','AC')
                           then 1
                           else 0
                       end
                    , case when t20.ctst_cd in ('A','C')
                           then t20.cmip
                           else 0
                       end
                    , case when t20.tra_ym = t20.str_ym
                            and t20.fur_rs_cd in ('BA')
                           then t20.fur_am
                           else 0
                       end
                    , case when t20.tra_ym = t20.str_ym
                            and t20.fur_rs_cd in ('AD','AE','AF','AG')
                           then t20.fur_am
                           else 0
                       end
                    , case when t20.tra_ym = t20.str_ym
                            and t20.fur_rs_cd in ('AI')
                           then myre_am
                           else 0
                       end
            ) t10
        group by t10.str_ym
               , t10.cs_no
               , t10.inon_no
               , t10.good_cd
    union all
    select t10.clos_ym                                         as ta_ym             -- 기준년월
         , t10.cs_no                                           as shmdn             -- 그룹MD번호
         , t10.lnco_no                                         as ts_dtn_n          -- 거래식별번호
         , t10.good_cd                                         as shd_pd_zcd        -- 데이터댐상품분류코드
         , current_timestamp AT TIME ZONE 'Asia/Seoul'         as aws_ld_dt
         , sum(t10.a_cnt + t10.b_cnt + t10.c_cnt + t10.d_cnt
             + t10.e_cnt + t10.f_cnt + t10.g_cnt)              as to_ts_ct          -- 총거래건수
         , sum(t10.a_cnt + t10.b_cnt)                          as lat_ct            -- 신규건수
         , sum(t10.c_cnt)                                      as me_ct             -- 해지건수
         , sum(t10.e_cnt + t10.f_cnt)                          as rcp_ct            -- 입금건수
         , sum(t10.d_cnt + t10.g_cnt)                          as aow_ct            -- 출금건수
         , sum(t10.a_amt + t10.b_amt + t10.c_amt + t10.d_amt
             + t10.e_amt + t10.f_amt + t10.g_amt)              as to_ts_at          -- 총거래금액
         , sum(t10.a_amt+t10.b_amt)                            as lat_at            -- 신규금액
         , sum(t10.c_amt)                                      as me_at             -- 해지금액
         , sum(t10.d_amt+t10.g_amt)                            as aow_at            -- 출금금액
         , sum(t10.e_amt+t10.f_amt)                            as rca               -- 입금금액
         , 0                                                   as pra_at            -- 실행금액
         , sum(t10.al)                                         as al                -- 대출잔액
      from (select t30.clos_ym
                 , t30.cs_no                                                        -- 고객번호(md변환)
                 , t30.lnco_no
                 , case when t30.lnco_sc_cd = '10'
                        then 'L21'                                                  -- '신용대출'
                        when t30.lnco_sc_cd = '20'
                        then 'L22'                                                  -- '부동산담보대출'
                        else 'L2Z'                                                  -- '기타담보대출'
                    end                                         as good_cd
                 , 0                                            as a_cnt            -- 신계약건수
                 , case when to_char(t30.lon_ymd,'yyyymm') = t30.clos_ym
                         and t30.lon_am > 0
                        then 1
                        else 0
                    end                                         as b_cnt            -- 대출건수
                 , 0                                            as c_cnt            -- 해지건수
                 , 0                                            as d_cnt            -- 보험료납입건수
                 , 0                                            as e_cnt            -- 보험금건수
                 , 0                                            as f_cnt            -- 제지급건수
                 , case when to_char(t30.lspa_ymd,'yyyymm') = t30.clos_ym
                         and t30.rep_am > 0
                        then 1
                        else 0
                    end                                         as g_cnt            -- 대출수납건수
                 , 0                                            as a_amt            -- 신계약금액
                 , case when to_char(t30.lon_ymd,'yyyymm') = t30.clos_ym
                         and t30.lon_am > 0
                        then t30.lon_am
                        else 0
                    end                                         as b_amt            -- 대출금액
                 , 0                                            as c_amt            -- 해지금액
                 , 0                                            as d_amt            -- 보험료납입금액
                 , 0                                            as e_amt            -- 보험금지급금액
                 , 0                                            as f_amt            -- 제지급지급금액
                 , case when to_char(t30.lspa_ymd,'yyyymm') = t30.clos_ym
                         and t30.rep_am > 0
                        then t30.rep_am
                        else 0
                    end                                         as g_amt            -- 대출수납금액
                 , sum(t30.lrem_am)                             as al               -- 대출잔액
              from shl.fn_mmln   t30                                                -- fn_대출월마감
             where t30.clos_ym    = '{date_cd('P_TA_YM')}'
               and t30.lnco_sc_cd = '10' --개인
             group by t30.clos_ym
                    , t30.cs_no
                    , t30.lnco_no
                    , case when t30.lnco_sc_cd = '10'
                           then 'L21'                                               -- '신용대출'
                           when t30.lnco_sc_cd = '20'
                           then 'L22'                                               -- '부동산담보대출'
                           else 'L2Z'                                               -- '기타담보대출'
                       end
                    , case when to_char(t30.lon_ymd,'yyyymm') = t30.clos_ym
                            and t30.lon_am > 0
                           then 1
                           else 0
                       end
                    , case when to_char(t30.lspa_ymd,'yyyymm') = t30.clos_ym
                            and t30.rep_am > 0
                           then 1
                           else 0
                       end
                    , case when to_char(t30.lon_ymd,'yyyymm') = t30.clos_ym
                            and t30.lon_am > 0
                           then t30.lon_am
                           else 0
                       end
                    , case when to_char(t30.lspa_ymd,'yyyymm') = t30.clos_ym
                            and t30.rep_am > 0
                           then t30.rep_am
                           else 0
                       end
            ) t10
        group by t10.clos_ym
               , t10.cs_no
               , t10.lnco_no
               , t10.good_cd
"""

"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""                     
insert_sql_for_tmp = [insert_sql_for_tmp_1]

""" 
(@) TMP_SH2 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shlmtrs001_tmp99', 'pk': ['ta_ym', 'shmdn', 'ts_dtn_n', 'shd_pd_zcd']}
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh1.shlmtrs001
    where ta_ym = '{date_cd('P_TA_YM')}'
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh1.shlmtrs001
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , ts_dtn_n                               -- 거래식별번호
         , shd_pd_zcd                             -- 데이터댐상품분류코드
         , aws_ld_dt                              -- AWS적재일시
         , to_ts_ct                               -- 총거래건수
         , lat_ct                                 -- 신규건수
         , me_ct                                  -- 해지건수
         , rcp_ct                                 -- 입금건수
         , aow_ct                                 -- 출금건수
         , to_ts_at                               -- 총거래금액
         , lat_at                                 -- 신규금액
         , me_at                                  -- 해지금액
         , aow_at                                 -- 출금금액
         , rca                                    -- 입금금액
         , pra_at                                 -- 실행금액
         , al                                     -- 잔액
         )
    select ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , ts_dtn_n                               -- 거래식별번호
         , shd_pd_zcd                             -- 데이터댐상품분류코드
         , aws_ld_dt                              -- AWS적재일시
         , to_ts_ct                               -- 총거래건수
         , lat_ct                                 -- 신규건수
         , me_ct                                  -- 해지건수
         , rcp_ct                                 -- 입금건수
         , aow_ct                                 -- 출금건수
         , to_ts_at                               -- 총거래금액
         , lat_at                                 -- 신규금액
         , me_at                                  -- 해지금액
         , aow_at                                 -- 출금금액
         , rca                                    -- 입금금액
         , pra_at                                 -- 실행금액
         , al                                     -- 잔액
      from tmp_sh1.shlmtrs001_tmp99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]
### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    tmp_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_tmp_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> tmp_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end