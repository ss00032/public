# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "노재홍"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["노재홍"]
__version__    = "1.0"
__maintainer__ = "노재홍"
__email__      = ""
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 한글 테이블명
  - TMP_SH1 테이블명
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHCMTRS003_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L1거래) TRS_월개인사업자가맹점매출실적_카드 배치프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh1'
tmp_schema = 'tmp_sh1'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shcmtrs003_tmp99']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""

############################################################################################
# TO_DO
############################################################################################
# mtdia0005(월가맹점디멘젼)이 가맹점번호(mct_n)로 유니크한지...
############################################################################################

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh1.shcmtrs003_tmp99                                        -- TRS_월개인사업자가맹점매출실적_카드_TMP99
    (
           ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , brn                                                                  -- 사업자등록번호
         , mct_n                                                                -- 가맹점번호
         , aws_ld_dt                                                            -- AWS적재일시
         , mct_ry_cd                                                            -- 가맹점업종코드
         , mct_kcd                                                              -- 가맹점종류코드
         , mct_mi_zcd                                                           -- 가맹점중분류코드
         , mct_zpn                                                              -- 가맹점우편번호
         , mct_adm_gds_apb_cd                                                   -- 가맹점행정gds동코드
         , mct_cou_gds_apb_cd                                                   -- 가맹점법정gds동코드
         , mct_are_d                                                            -- 가맹점계약일자
         , mct_me_d                                                             -- 가맹점해지일자
         , saa                                                                  -- 매출금액
         , ue_ct                                                                -- 이용건수
         , ue_crd_cn                                                            -- 이용카드수
         , ue_cus_cn                                                            -- 이용회원수
         , mon_ue_ct                                                            -- 월요일이용건수
         , tue_ue_ct                                                            -- 화요일이용건수
         , wed_ue_ct                                                            -- 수요일이용건수
         , thu_ue_ct                                                            -- 목요일이용건수
         , fri_ue_ct                                                            -- 금요일이용건수
         , sat_ue_ct                                                            -- 토요일이용건수
         , sun_ue_ct                                                            -- 일요일이용건수
         , mrn_ue_ct                                                            -- 오전이용건수
         , lch_ue_ct                                                            -- 중식이용건수
         , aft_ue_ct                                                            -- 오후이용건수
         , nht_ue_ct                                                            -- 야간이용건수
         , hr5_hr11_blk_ue_ct                                                   -- 5시11시구간이용건수
         , hr12_hr13_blk_ue_ct                                                  -- 12시13시구간이용건수
         , hr14_hr17_blk_ue_ct                                                  -- 14시17시구간이용건수
         , hr18_hr22_blk_ue_ct                                                  -- 18시22시구간이용건수
         , hr23_hr4_blk_ue_ct                                                   -- 23시4시구간이용건수
         , ag10_saa                                                             -- 10대매출금액
         , ag20_saa                                                             -- 20대매출금액
         , ag30_saa                                                             -- 30대매출금액
         , ag40_saa                                                             -- 40대매출금액
         , ag50_saa                                                             -- 50대매출금액
         , ag60_ab_saa                                                          -- 60대이상매출금액
         , ag10_ue_ct                                                           -- 10대이용건수
         , ag20_ue_ct                                                           -- 20대이용건수
         , ag30_ue_ct                                                           -- 30대이용건수
         , ag40_ue_ct                                                           -- 40대이용건수
         , ag50_ue_ct                                                           -- 50대이용건수
         , ag60_ab_ue_ct                                                        -- 60대이상이용건수
         , mal_saa                                                              -- 남성매출금액
         , fme_saa                                                              -- 여성매출금액
         , mal_ue_ct                                                            -- 남성이용건수
         , fme_ue_ct                                                            -- 여성이용건수
    )
    select t10.ta_ym                                                            -- 기준년월
         , t10.rpk_sgdmd                                as shmdn                -- 그룹MD번호(대표자그룹MD번호)
         , t10.mct_brn                                  as brn                  -- 사업자등록번호(가맹점사업자등록번호)
         , t10.mct_n                                                            -- 가맹점번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'  as aws_ld_dt            -- AWS적재일시
         , t10.mct_ry_cd                                                        -- 가맹점업종코드
         , t10.mct_kcd                                                          -- 가맹점종류코드
         , t10.mct_mi_zcd                                                       -- 가맹점중분류코드
         , t11.mct_zpn                                                          -- 가맹점우편번호
         , t11.mct_adm_gds_apb_cd                                               -- 가맹점행정동코드
         , t11.mct_cou_gds_apb_cd                                               -- 가맹점법정동코드
         , t10.mct_are_d                                                        -- 가맹점계약일자
         , t10.mct_me_d                                                         -- 가맹점해지일자
         , nvl(t12.hga                , 0)              as saa                  -- 매출금액(취급금액)
         , nvl(t12.ue_ct              , 0)              as ue_ct                -- 이용건수
         , nvl(t12.ue_crd_cn          , 0)              as ue_crd_cn            -- 이용카드수
         , nvl(t12.ue_cus_cn          , 0)              as ue_cus_cn            -- 이용회원수
         , nvl(t12.mon_ue_ct          , 0)              as mon_ue_ct            -- 월요일이용건수
         , nvl(t12.tue_ue_ct          , 0)              as tue_ue_ct            -- 화요일이용건수
         , nvl(t12.wed_ue_ct          , 0)              as wed_ue_ct            -- 수요일이용건수
         , nvl(t12.thu_ue_ct          , 0)              as thu_ue_ct            -- 목요일이용건수
         , nvl(t12.fri_ue_ct          , 0)              as fri_ue_ct            -- 금요일이용건수
         , nvl(t12.sat_ue_ct          , 0)              as sat_ue_ct            -- 토요일이용건수
         , nvl(t12.sun_ue_ct          , 0)              as sun_ue_ct            -- 일요일이용건수
         , nvl(t12.mrn_ue_ct          , 0)              as mrn_ue_ct            -- 오전이용건수
         , nvl(t12.lch_ue_ct          , 0)              as lch_ue_ct            -- 중식이용건수
         , nvl(t12.aft_ue_ct          , 0)              as aft_ue_ct            -- 오후이용건수
         , nvl(t12.nht_ue_ct          , 0)              as nht_ue_ct            -- 야간이용건수
         , nvl(t12.hr5_hr11_blk_ue_ct , 0)              as hr5_hr11_blk_ue_ct   -- 5시11시구간이용건수
         , nvl(t12.hr12_hr13_blk_ue_ct, 0)              as hr12_hr13_blk_ue_ct  -- 12시13시구간이용건수
         , nvl(t12.hr14_hr17_blk_ue_ct, 0)              as hr14_hr17_blk_ue_ct  -- 14시17시구간이용건수
         , nvl(t12.hr18_hr22_blk_ue_ct, 0)              as hr18_hr22_blk_ue_ct  -- 18시22시구간이용건수
         , nvl(t12.hr23_hr4_blk_ue_ct , 0)              as hr23_hr4_blk_ue_ct   -- 23시4시구간이용건수
         , nvl(t13.ag10_saa           , 0)              as ag10_saa             -- 10대매출금액
         , nvl(t13.ag20_saa           , 0)              as ag20_saa             -- 20대매출금액
         , nvl(t13.ag30_saa           , 0)              as ag30_saa             -- 30대매출금액
         , nvl(t13.ag40_saa           , 0)              as ag40_saa             -- 40대매출금액
         , nvl(t13.ag50_saa           , 0)              as ag50_saa             -- 50대매출금액
         , nvl(t13.ag60_ab_saa        , 0)              as ag60_ab_saa          -- 60대이상매출금액
         , nvl(t13.ag10_ue_ct         , 0)              as ag10_ue_ct           -- 10대이용건수
         , nvl(t13.ag20_ue_ct         , 0)              as ag20_ue_ct           -- 20대이용건수
         , nvl(t13.ag30_ue_ct         , 0)              as ag30_ue_ct           -- 30대이용건수
         , nvl(t13.ag40_ue_ct         , 0)              as ag40_ue_ct           -- 40대이용건수
         , nvl(t13.ag50_ue_ct         , 0)              as ag50_ue_ct           -- 50대이용건수
         , nvl(t13.ag60_ab_ue_ct      , 0)              as ag60_ab_ue_ct        -- 60대이상이용건수
         , nvl(t13.mal_saa            , 0)              as mal_saa              -- 남성매출금액
         , nvl(t13.fme_saa            , 0)              as fme_saa              -- 여성매출금액
         , nvl(t13.mal_ue_ct          , 0)              as mal_ue_ct            -- 남성이용건수
         , nvl(t13.fme_ue_ct          , 0)              as fme_ue_ct            -- 여성이용건수
      from shc.mtdia0005                         t10                            -- 월가맹점디멘젼
      left outer join
           shc.swoae0004                         t11                            -- 표준화가맹점회원
        on t10.mct_n = t11.mct_n                                                -- 가맹점번호
      left outer join
           shc.mtfua0017                         t12                            -- 월가맹점매출
        on t10.ta_ym = t12.ta_ym                                                -- 기준년월
       and t10.mct_n = t12.mct_n                                                -- 가맹점번호
      left outer join
           (
              select t20.ta_ym                                                  -- 기준년월
                   , t20.mct_n                                                  -- 가맹점번호
                   , sum( case when t20.cln_age_cd = '01'                       -- 고객연령코드
                               then t20.hga                                     -- 취급금액
                               else 0
                          end )                         as ag10_saa             -- 10대매출금액
                   , sum( case when t20.cln_age_cd = '02'                       -- 고객연령코드
                               then t20.hga                                     -- 취급금액
                               else 0
                          end )                         as ag20_saa             -- 20대매출금액
                   , sum( case when t20.cln_age_cd = '03'                       -- 고객연령코드
                               then t20.hga                                     -- 취급금액
                               else 0
                          end )                         as ag30_saa             -- 30대매출금액
                   , sum( case when t20.cln_age_cd = '04'                       -- 고객연령코드
                               then t20.hga                                     -- 취급금액
                               else 0
                          end )                         as ag40_saa             -- 40대매출금액
                   , sum( case when t20.cln_age_cd = '05'                       -- 고객연령코드
                               then t20.hga                                     -- 취급금액
                               else 0
                          end )                         as ag50_saa             -- 50대매출금액
                   , sum( case when t20.cln_age_cd >= '06'                      -- 고객연령코드
                               then t20.hga                                     -- 취급금액
                               else 0
                          end )                         as ag60_ab_saa          -- 60대이상매출금액
                   , sum( case when t20.cln_age_cd = '01'                       -- 고객연령코드
                               then t20.ue_ct                                   -- 이용건수
                               else 0
                          end )                         as ag10_ue_ct           -- 10대이용건수
                   , sum( case when t20.cln_age_cd = '02'                       -- 고객연령코드
                               then t20.ue_ct                                   -- 이용건수
                               else 0
                          end )                         as ag20_ue_ct           -- 20대이용건수
                   , sum( case when t20.cln_age_cd = '03'                       -- 고객연령코드
                               then t20.ue_ct                                   -- 이용건수
                               else 0
                          end )                         as ag30_ue_ct           -- 30대이용건수
                   , sum( case when t20.cln_age_cd = '04'                       -- 고객연령코드
                               then t20.ue_ct                                   -- 이용건수
                               else 0
                          end )                         as ag40_ue_ct           -- 40대이용건수
                   , sum( case when t20.cln_age_cd = '05'                       -- 고객연령코드
                               then t20.ue_ct                                   -- 이용건수
                               else 0
                          end )                         as ag50_ue_ct           -- 50대이용건수
                   , sum( case when t20.cln_age_cd >= '06'                      -- 고객연령코드
                               then t20.ue_ct                                   -- 이용건수
                               else 0
                          end )                         as ag60_ab_ue_ct        -- 60대이상이용건수
                   , sum( case when t20.sex_ccd = 'M'                           -- 성별구분코드
                               then t20.hga                                     -- 취급금액
                               else 0
                          end )                         as mal_saa              -- 남성매출금액
                   , sum( case when t20.sex_ccd = 'F'                           -- 성별구분코드
                               then t20.hga                                     -- 취급금액
                               else 0
                          end )                         as fme_saa              -- 여성매출금액
                   , sum( case when t20.sex_ccd = 'M'                           -- 성별구분코드
                               then t20.ue_ct                                   -- 이용건수
                               else 0
                          end )                         as mal_ue_ct            -- 남성이용건수
                   , sum( case when t20.sex_ccd = 'F'                           -- 성별구분코드
                               then t20.ue_ct                                   -- 이용건수
                               else 0
                          end )                         as fme_ue_ct            -- 여성이용건수
                from shc.mtfua0022               t20                            -- 월고객가맹점매출
               where t20.ta_ym = '{date_cd('P_TA_YM')}'                         -- 기준년월
               group by
                     t20.ta_ym                                                  -- 기준년월
                   , t20.mct_n                                                  -- 가맹점번호
           )                                     t13
        on t10.ta_ym = t13.ta_ym                                                -- 기준년월
       and t10.mct_n = t13.mct_n                                                -- 가맹점번호
     where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
       and t10.psn_etk_tf = 1                                                   -- 개인사업자TF
"""

"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shcmtrs003_tmp99', 'pk': ['ta_ym', 'shmdn', 'brn', 'mct_n']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh1.shcmtrs003                                                  -- TRS_월개인사업자가맹점매출실적_카드
     where ta_ym = '{date_cd('P_TA_YM')}'                                       -- 기준년월
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh1.shcmtrs003                                                  -- TRS_월개인사업자가맹점매출실적_카드
    (
           ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , brn                                                                  -- 사업자등록번호
         , mct_n                                                                -- 가맹점번호
         , aws_ld_dt                                                            -- AWS적재일시
         , mct_ry_cd                                                            -- 가맹점업종코드
         , mct_kcd                                                              -- 가맹점종류코드
         , mct_mi_zcd                                                           -- 가맹점중분류코드
         , mct_zpn                                                              -- 가맹점우편번호
         , mct_adm_gds_apb_cd                                                   -- 가맹점행정gds동코드
         , mct_cou_gds_apb_cd                                                   -- 가맹점법정gds동코드
         , mct_are_d                                                            -- 가맹점계약일자
         , mct_me_d                                                             -- 가맹점해지일자
         , saa                                                                  -- 매출금액
         , ue_ct                                                                -- 이용건수
         , ue_crd_cn                                                            -- 이용카드수
         , ue_cus_cn                                                            -- 이용회원수
         , mon_ue_ct                                                            -- 월요일이용건수
         , tue_ue_ct                                                            -- 화요일이용건수
         , wed_ue_ct                                                            -- 수요일이용건수
         , thu_ue_ct                                                            -- 목요일이용건수
         , fri_ue_ct                                                            -- 금요일이용건수
         , sat_ue_ct                                                            -- 토요일이용건수
         , sun_ue_ct                                                            -- 일요일이용건수
         , mrn_ue_ct                                                            -- 오전이용건수
         , lch_ue_ct                                                            -- 중식이용건수
         , aft_ue_ct                                                            -- 오후이용건수
         , nht_ue_ct                                                            -- 야간이용건수
         , hr5_hr11_blk_ue_ct                                                   -- 5시11시구간이용건수
         , hr12_hr13_blk_ue_ct                                                  -- 12시13시구간이용건수
         , hr14_hr17_blk_ue_ct                                                  -- 14시17시구간이용건수
         , hr18_hr22_blk_ue_ct                                                  -- 18시22시구간이용건수
         , hr23_hr4_blk_ue_ct                                                   -- 23시4시구간이용건수
         , ag10_saa                                                             -- 10대매출금액
         , ag20_saa                                                             -- 20대매출금액
         , ag30_saa                                                             -- 30대매출금액
         , ag40_saa                                                             -- 40대매출금액
         , ag50_saa                                                             -- 50대매출금액
         , ag60_ab_saa                                                          -- 60대이상매출금액
         , ag10_ue_ct                                                           -- 10대이용건수
         , ag20_ue_ct                                                           -- 20대이용건수
         , ag30_ue_ct                                                           -- 30대이용건수
         , ag40_ue_ct                                                           -- 40대이용건수
         , ag50_ue_ct                                                           -- 50대이용건수
         , ag60_ab_ue_ct                                                        -- 60대이상이용건수
         , mal_saa                                                              -- 남성매출금액
         , fme_saa                                                              -- 여성매출금액
         , mal_ue_ct                                                            -- 남성이용건수
         , fme_ue_ct                                                            -- 여성이용건수
    )
    select ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , brn                                                                  -- 사업자등록번호
         , mct_n                                                                -- 가맹점번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , mct_ry_cd                                                            -- 가맹점업종코드
         , mct_kcd                                                              -- 가맹점종류코드
         , mct_mi_zcd                                                           -- 가맹점중분류코드
         , mct_zpn                                                              -- 가맹점우편번호
         , mct_adm_gds_apb_cd                                                   -- 가맹점행정gds동코드
         , mct_cou_gds_apb_cd                                                   -- 가맹점법정gds동코드
         , mct_are_d                                                            -- 가맹점계약일자
         , mct_me_d                                                             -- 가맹점해지일자
         , saa                                                                  -- 매출금액
         , ue_ct                                                                -- 이용건수
         , ue_crd_cn                                                            -- 이용카드수
         , ue_cus_cn                                                            -- 이용회원수
         , mon_ue_ct                                                            -- 월요일이용건수
         , tue_ue_ct                                                            -- 화요일이용건수
         , wed_ue_ct                                                            -- 수요일이용건수
         , thu_ue_ct                                                            -- 목요일이용건수
         , fri_ue_ct                                                            -- 금요일이용건수
         , sat_ue_ct                                                            -- 토요일이용건수
         , sun_ue_ct                                                            -- 일요일이용건수
         , mrn_ue_ct                                                            -- 오전이용건수
         , lch_ue_ct                                                            -- 중식이용건수
         , aft_ue_ct                                                            -- 오후이용건수
         , nht_ue_ct                                                            -- 야간이용건수
         , hr5_hr11_blk_ue_ct                                                   -- 5시11시구간이용건수
         , hr12_hr13_blk_ue_ct                                                  -- 12시13시구간이용건수
         , hr14_hr17_blk_ue_ct                                                  -- 14시17시구간이용건수
         , hr18_hr22_blk_ue_ct                                                  -- 18시22시구간이용건수
         , hr23_hr4_blk_ue_ct                                                   -- 23시4시구간이용건수
         , ag10_saa                                                             -- 10대매출금액
         , ag20_saa                                                             -- 20대매출금액
         , ag30_saa                                                             -- 30대매출금액
         , ag40_saa                                                             -- 40대매출금액
         , ag50_saa                                                             -- 50대매출금액
         , ag60_ab_saa                                                          -- 60대이상매출금액
         , ag10_ue_ct                                                           -- 10대이용건수
         , ag20_ue_ct                                                           -- 20대이용건수
         , ag30_ue_ct                                                           -- 30대이용건수
         , ag40_ue_ct                                                           -- 40대이용건수
         , ag50_ue_ct                                                           -- 50대이용건수
         , ag60_ab_ue_ct                                                        -- 60대이상이용건수
         , mal_saa                                                              -- 남성매출금액
         , fme_saa                                                              -- 여성매출금액
         , mal_ue_ct                                                            -- 남성이용건수
         , fme_ue_ct                                                            -- 여성이용건수
      from tmp_sh1.shcmtrs003_tmp99                                             -- TRS_월개인사업자가맹점매출실적_카드_TMP99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end