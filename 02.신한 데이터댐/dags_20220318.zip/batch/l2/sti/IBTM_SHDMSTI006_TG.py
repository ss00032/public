# -*- coding: utf-8 -*-

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *

__author__     = "이일주"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["이일주"]
__version__    = "1.0"
__maintainer__ = "이일주"
__email__      = "LEE1122334@xgm.co.kr"
__status__     = "Production"

"""
L0 데이터를 SH2 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID  : IBTM_SHDMSTI006_TG
  - 한글 테이블명: STI_월가맹점업종매출통계집계
  - tmp_sh2 테이블명: tmp_sh2.shdmsti006_tmp99
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMSTI006_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = 'STI_월가맹점업종매출통계집계'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

##날짜변수 사용관련 
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) tmp_sh2 테이블명 (TRUNCATE 대상)
"""
tmp_sh2_table = ['shdmsti006_tmp99']

"""
(@) tmp_sh2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmsti006_tmp99
         (
           ta_ym                                  -- 기준년월
         , mct_ry_cd                              -- 가맹점업종코드
         , aws_ld_dt                              -- AWS적재일시
         , mct_ct                                 -- 가맹점건수
         , saa                                    -- 매출금액
         , ue_ct                                  -- 이용건수
         , mon_ue_ct                              -- 월요일이용건수
         , tue_ue_ct                              -- 화요일이용건수
         , wed_ue_ct                              -- 수요일이용건수
         , thu_ue_ct                              -- 목요일이용건수
         , fri_ue_ct                              -- 금요일이용건수
         , sat_ue_ct                              -- 토요일이용건수
         , sun_ue_ct                              -- 일요일이용건수
         , mrn_ue_ct                              -- 오전이용건수
         , lch_ue_ct                              -- 중식이용건수
         , aft_ue_ct                              -- 오후이용건수
         , nht_ue_ct                              -- 야간이용건수
         , hr5_hr11_blk_ue_ct                     -- 5시11시구간이용건수
         , hr12_hr13_blk_ue_ct                    -- 12시13시구간이용건수
         , hr14_hr17_blk_ue_ct                    -- 14시17시구간이용건수
         , hr18_hr22_blk_ue_ct                    -- 18시22시구간이용건수
         , hr23_hr4_blk_ue_ct                     -- 23시4시구간이용건수
         , ag10_saa                               -- 10대매출금액
         , ag20_saa                               -- 20대매출금액
         , ag30_saa                               -- 30대매출금액
         , ag40_saa                               -- 40대매출금액
         , ag50_saa                               -- 50대매출금액
         , ag60_ab_saa                            -- 60대이상매출금액
         , ag10_ue_ct                             -- 10대이용건수
         , ag20_ue_ct                             -- 20대이용건수
         , ag30_ue_ct                             -- 30대이용건수
         , ag40_ue_ct                             -- 40대이용건수
         , ag50_ue_ct                             -- 50대이용건수
         , ag60_ab_ue_ct                          -- 60대이상이용건수
         , mal_saa                                -- 남성매출금액
         , fme_saa                                -- 여성매출금액
         , mal_ue_ct                              -- 남성이용건수
         , fme_ue_ct                              -- 여성이용건수
         )
    select ta_ym
         , mct_ry_cd
         , current_timestamp AT TIME ZONE 'Asia/Seoul'  as aws_ld_dt                -- aws적재일시
         , count(mct_n)                          as mct_ct                          -- 가맹점건수
         , sum(saa)                              as saa                             -- 매출금액
         , sum(ue_ct)                            as ue_ct                           -- 이용건수
         , sum(mon_ue_ct)                        as mon_ue_ct                       -- 월요일이용건수
         , sum(tue_ue_ct)                        as tue_ue_ct                       -- 화요일이용건수
         , sum(wed_ue_ct)                        as wed_ue_ct                       -- 수요일이용건수
         , sum(thu_ue_ct)                        as thu_ue_ct                       -- 목요일이용건수
         , sum(fri_ue_ct)                        as fri_ue_ct                       -- 금요일이용건수
         , sum(sat_ue_ct)                        as sat_ue_ct                       -- 토요일이용건수
         , sum(sun_ue_ct)                        as sun_ue_ct                       -- 일요일이용건수
         , sum(mrn_ue_ct)                        as mrn_ue_ct                       -- 오전이용건수
         , sum(lch_ue_ct)                        as lch_ue_ct                       -- 중식이용건수
         , sum(aft_ue_ct)                        as aft_ue_ct                       -- 오후이용건수
         , sum(nht_ue_ct)                        as nht_ue_ct                       -- 야간이용건수
         , sum(hr5_hr11_blk_ue_ct)               as hr5_hr11_blk_ue_ct              -- 5시11시구간이용건수
         , sum(hr12_hr13_blk_ue_ct)              as hr12_hr13_blk_ue_ct             -- 12시13시구간이용건수
         , sum(hr14_hr17_blk_ue_ct)              as hr14_hr17_blk_ue_ct             -- 14시17시구간이용건수
         , sum(hr18_hr22_blk_ue_ct)              as hr18_hr22_blk_ue_ct             -- 18시22시구간이용건수
         , sum(hr23_hr4_blk_ue_ct)               as hr23_hr4_blk_ue_ct              -- 23시4시구간이용건수
         , sum(ag10_saa)                         as ag10_saa                        -- 10대매출금액
         , sum(ag20_saa)                         as ag20_saa                        -- 20대매출금액
         , sum(ag30_saa)                         as ag30_saa                        -- 30대매출금액
         , sum(ag40_saa)                         as ag40_saa                        -- 40대매출금액
         , sum(ag50_saa)                         as ag50_saa                        -- 50대매출금액
         , sum(ag60_ab_saa)                      as ag60_ab_saa                     -- 60대이상매출금액
         , sum(ag10_ue_ct)                       as ag10_ue_ct                      -- 10대이용건수
         , sum(ag20_ue_ct)                       as ag20_ue_ct                      -- 20대이용건수
         , sum(ag30_ue_ct)                       as ag30_ue_ct                      -- 30대이용건수
         , sum(ag40_ue_ct)                       as ag40_ue_ct                      -- 40대이용건수
         , sum(ag50_ue_ct)                       as ag50_ue_ct                      -- 50대이용건수
         , sum(ag60_ab_ue_ct)                    as ag60_ab_ue_ct                   -- 60대이상이용건수
         , sum(mal_saa)                          as mal_saa                         -- 남성매출금액
         , sum(fme_saa)                          as fme_saa                         -- 여성매출금액
         , sum(mal_ue_ct)                        as mal_ue_ct                       -- 남성이용건수
         , sum(fme_ue_ct)                        as fme_ue_ct                       -- 여성이용건수
      from sh1.shcmtrs003
     where ta_ym = '{date_cd('P_TA_YM')}'
     group by ta_ym
            , mct_ry_cd
"""

"""
(@) tmp_sh2 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""                     
insert_sql_for_tmp = [insert_sql_for_tmp_1]

""" 
(@) TMP_SH2 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmsti006_tmp99', 'pk': ['ta_ym', 'mct_ry_cd']}
}

"""
(@) SH2 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmsti006
    where ta_ym = '{date_cd('P_TA_YM')}'
"""

"""
(@) SH2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shdmsti006
         (
           ta_ym                                  -- 기준년월
         , mct_ry_cd                              -- 가맹점업종코드
         , aws_ld_dt                              -- AWS적재일시
         , mct_ct                                 -- 가맹점건수
         , saa                                    -- 매출금액
         , ue_ct                                  -- 이용건수
         , mon_ue_ct                              -- 월요일이용건수
         , tue_ue_ct                              -- 화요일이용건수
         , wed_ue_ct                              -- 수요일이용건수
         , thu_ue_ct                              -- 목요일이용건수
         , fri_ue_ct                              -- 금요일이용건수
         , sat_ue_ct                              -- 토요일이용건수
         , sun_ue_ct                              -- 일요일이용건수
         , mrn_ue_ct                              -- 오전이용건수
         , lch_ue_ct                              -- 중식이용건수
         , aft_ue_ct                              -- 오후이용건수
         , nht_ue_ct                              -- 야간이용건수
         , hr5_hr11_blk_ue_ct                     -- 5시11시구간이용건수
         , hr12_hr13_blk_ue_ct                    -- 12시13시구간이용건수
         , hr14_hr17_blk_ue_ct                    -- 14시17시구간이용건수
         , hr18_hr22_blk_ue_ct                    -- 18시22시구간이용건수
         , hr23_hr4_blk_ue_ct                     -- 23시4시구간이용건수
         , ag10_saa                               -- 10대매출금액
         , ag20_saa                               -- 20대매출금액
         , ag30_saa                               -- 30대매출금액
         , ag40_saa                               -- 40대매출금액
         , ag50_saa                               -- 50대매출금액
         , ag60_ab_saa                            -- 60대이상매출금액
         , ag10_ue_ct                             -- 10대이용건수
         , ag20_ue_ct                             -- 20대이용건수
         , ag30_ue_ct                             -- 30대이용건수
         , ag40_ue_ct                             -- 40대이용건수
         , ag50_ue_ct                             -- 50대이용건수
         , ag60_ab_ue_ct                          -- 60대이상이용건수
         , mal_saa                                -- 남성매출금액
         , fme_saa                                -- 여성매출금액
         , mal_ue_ct                              -- 남성이용건수
         , fme_ue_ct                              -- 여성이용건수
         )
    select ta_ym                                  -- 기준년월
         , mct_ry_cd                              -- 가맹점업종코드
         , aws_ld_dt                              -- AWS적재일시
         , mct_ct                                 -- 가맹점건수
         , saa                                    -- 매출금액
         , ue_ct                                  -- 이용건수
         , mon_ue_ct                              -- 월요일이용건수
         , tue_ue_ct                              -- 화요일이용건수
         , wed_ue_ct                              -- 수요일이용건수
         , thu_ue_ct                              -- 목요일이용건수
         , fri_ue_ct                              -- 금요일이용건수
         , sat_ue_ct                              -- 토요일이용건수
         , sun_ue_ct                              -- 일요일이용건수
         , mrn_ue_ct                              -- 오전이용건수
         , lch_ue_ct                              -- 중식이용건수
         , aft_ue_ct                              -- 오후이용건수
         , nht_ue_ct                              -- 야간이용건수
         , hr5_hr11_blk_ue_ct                     -- 5시11시구간이용건수
         , hr12_hr13_blk_ue_ct                    -- 12시13시구간이용건수
         , hr14_hr17_blk_ue_ct                    -- 14시17시구간이용건수
         , hr18_hr22_blk_ue_ct                    -- 18시22시구간이용건수
         , hr23_hr4_blk_ue_ct                     -- 23시4시구간이용건수
         , ag10_saa                               -- 10대매출금액
         , ag20_saa                               -- 20대매출금액
         , ag30_saa                               -- 30대매출금액
         , ag40_saa                               -- 40대매출금액
         , ag50_saa                               -- 50대매출금액
         , ag60_ab_saa                            -- 60대이상매출금액
         , ag10_ue_ct                             -- 10대이용건수
         , ag20_ue_ct                             -- 20대이용건수
         , ag30_ue_ct                             -- 30대이용건수
         , ag40_ue_ct                             -- 40대이용건수
         , ag50_ue_ct                             -- 50대이용건수
         , ag60_ab_ue_ct                          -- 60대이상이용건수
         , mal_saa                                -- 남성매출금액
         , fme_saa                                -- 여성매출금액
         , mal_ue_ct                              -- 남성이용건수
         , fme_ue_ct                              -- 여성이용건수
      from tmp_sh2.shdmsti006_tmp99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh2 = [insert_sql_1]
### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh2_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]
    
    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    tmp_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_tmp_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh2_delete_task = RedshiftQueryOperator(
        task_id='004_sh2_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh2_load_task = [RedshiftQueryOperator(
        task_id='005_sh2_load_task_' + str(insert_sql_for_sh2.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh2]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> tmp_pk_valid_task >> sh2_delete_task >> sh2_load_task >> task_end
