# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "노재홍"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["노재홍"]
__version__    = "1.0"
__maintainer__ = "노재홍"
__email__      = ""
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 한글 테이블명
  - TMP_SH1 테이블명
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMSTI005_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L2금융통계) STI_월상품통계집계 배치프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shdmsti005_tmp99']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmsti005_tmp99                                        -- STI_월상품통계집계_TMP99
    (
           ta_ym                                                                -- 기준년월
         , shd_pd_zcd                                                           -- 데이터댐상품분류코드
         , aws_ld_dt                                                            -- AWS적재일시
         , wl_cln_cn                                                            -- 전체고객수
         , ag10_cln_cn                                                          -- 10대고객수
         , ag20_cln_cn                                                          -- 20대고객수
         , ag30_cln_cn                                                          -- 30대고객수
         , ag40_cln_cn                                                          -- 40대고객수
         , ag50_cln_cn                                                          -- 50대고객수
         , ag60_cln_cn                                                          -- 60대고객수
         , ag70_ab_cln_cn                                                       -- 70대이상고객수
         , pmr_ga_cln_cn                                                        -- 프리미어등급고객수
         , ace_ga_cln_cn                                                        -- 에이스등급고객수
         , bst_ga_cln_cn                                                        -- 베스트등급고객수
         , clsi_ga_cln_cn                                                       -- 클래식등급고객수
         , psn_etk_cln_cn                                                       -- 개인사업자고객수
         , wl_pd_jn_ct                                                          -- 전체상품가입건수
         , ag10_pd_jn_ct                                                        -- 10대상품가입건수
         , ag20_pd_jn_ct                                                        -- 20대상품가입건수
         , ag30_pd_jn_ct                                                        -- 30대상품가입건수
         , ag40_pd_jn_ct                                                        -- 40대상품가입건수
         , ag50_pd_jn_ct                                                        -- 50대상품가입건수
         , ag60_pd_jn_ct                                                        -- 60대상품가입건수
         , ag70_ab_pd_jn_ct                                                     -- 70대이상상품가입건수
         , pmr_ga_pd_jn_ct                                                      -- 프리미어등급상품가입건수
         , ace_ga_pd_jn_ct                                                      -- 에이스등급상품가입건수
         , bst_ga_pd_jn_ct                                                      -- 베스트등급상품가입건수
         , clsi_ga_pd_jn_ct                                                     -- 클래식등급상품가입건수
         , psn_etk_pd_jn_ct                                                     -- 개인사업자상품가입건수
         , wl_pd_at                                                             -- 전체상품금액
         , ag10_pd_at                                                           -- 10대상품금액
         , ag20_pd_at                                                           -- 20대상품금액
         , ag30_pd_at                                                           -- 30대상품금액
         , ag40_pd_at                                                           -- 40대상품금액
         , ag50_pd_at                                                           -- 50대상품금액
         , ag60_pd_at                                                           -- 60대상품금액
         , ag70_ab_pd_at                                                        -- 70대이상상품금액
         , pmr_pd_at                                                            -- 프리미어상품금액
         , ace_pd_at                                                            -- 에이스상품금액
         , bst_pd_at                                                            -- 베스트상품금액
         , clsi_pd_at                                                           -- 클래식상품금액
         , psn_etk_pd_at                                                        -- 개인사업자상품금액
    )
    select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
         , t10.shd_pd_zcd                                                       -- 데이터댐상품분류코드
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         -- 고객수
         , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
         , count( distinct case when t11.age_ccd = '01'                         -- 연령구분코드(10대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag10_cln_cn       -- 10대고객수
         , count( distinct case when t11.age_ccd = '02'                         -- 연령구분코드(20대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag20_cln_cn       -- 20대고객수
         , count( distinct case when t11.age_ccd = '03'                         -- 연령구분코드(30대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag30_cln_cn       -- 30대고객수
         , count( distinct case when t11.age_ccd = '04'                         -- 연령구분코드(40대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag40_cln_cn       -- 40대고객수
         , count( distinct case when t11.age_ccd = '05'                         -- 연령구분코드(50대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag50_cln_cn       -- 50대고객수
         , count( distinct case when t11.age_ccd = '06'                         -- 연령구분코드(60대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag60_cln_cn       -- 60대고객수
         , count( distinct case when t11.age_ccd >= '07'                        -- 연령구분코드(70대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag70_ab_cln_cn    -- 70대이상고객수
         , count( distinct case when t11.shp_tps_clb_gcd = '01'                 -- 신한그룹탑스클럽등급코드(프리미어)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as pmr_ga_cln_cn     -- 프리미어등급고객수
         , count( distinct case when t11.shp_tps_clb_gcd = '02'                 -- 신한그룹탑스클럽등급코드(에이스)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ace_ga_cln_cn     -- 에이스등급고객수
         , count( distinct case when t11.shp_tps_clb_gcd = '03'                 -- 신한그룹탑스클럽등급코드(베스트)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as bst_ga_cln_cn     -- 베스트등급고객수
         , count( distinct case when t11.shp_tps_clb_gcd = '04'                 -- 신한그룹탑스클럽등급코드(클래식)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as clsi_ga_cln_cn    -- 클래식등급고객수
         , count( distinct case when t11.psn_etk_tf = 1                         -- 개인사업자tf
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as psn_etk_cln_cn    -- 개인사업자고객수
         -- 가입건수
         , nvl(sum(t10.lat_ct), 0)                         as wl_pd_jn_ct       -- 전체상품가입건수
         , nvl(sum( case when t11.age_ccd = '01'                                -- 연령구분코드(10대)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as ag10_pd_jn_ct     -- 10대상품가입건수
         , nvl(sum( case when t11.age_ccd = '02'                                -- 연령구분코드(20대)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as ag20_pd_jn_ct     -- 20대상품가입건수
         , nvl(sum( case when t11.age_ccd = '03'                                -- 연령구분코드(30대)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as ag30_pd_jn_ct     -- 30대상품가입건수
         , nvl(sum( case when t11.age_ccd = '04'                                -- 연령구분코드(40대)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as ag40_pd_jn_ct     -- 40대상품가입건수
         , nvl(sum( case when t11.age_ccd = '05'                                -- 연령구분코드(50대)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as ag50_pd_jn_ct     -- 50대상품가입건수
         , nvl(sum( case when t11.age_ccd = '06'                                -- 연령구분코드(60대)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as ag60_pd_jn_ct     -- 60대상품가입건수
         , nvl(sum( case when t11.age_ccd >= '07'                               -- 연령구분코드(70대)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as ag70_ab_pd_jn_ct  -- 70대이상상품가입건수
         , nvl(sum( case when t11.shp_tps_clb_gcd = '01'                        -- 신한그룹탑스클럽등급코드(프리미어)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as pmr_ga_pd_jn_ct   -- 프리미어등급상품가입건수
         , nvl(sum( case when t11.shp_tps_clb_gcd = '02'                        -- 신한그룹탑스클럽등급코드(에이스)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as ace_ga_pd_jn_ct   -- 에이스등급상품가입건수
         , nvl(sum( case when t11.shp_tps_clb_gcd = '03'                        -- 신한그룹탑스클럽등급코드(베스트)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as bst_ga_pd_jn_ct   -- 베스트등급상품가입건수
         , nvl(sum( case when t11.shp_tps_clb_gcd = '04'                        -- 신한그룹탑스클럽등급코드(클래식)
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as clsi_ga_pd_jn_ct  -- 클래식등급상품가입건수
         , nvl(sum( case when t11.psn_etk_tf = 1                                -- 개인사업자tf
                         then t10.lat_ct                                        -- 신규건수
                    end ), 0)                              as psn_etk_pd_jn_ct  -- 개인사업자상품가입건수
         -- 상품금액
         , nvl(sum(t10.al), 0)                             as wl_pd_at          -- 전체상품금액
         , nvl(sum( case when t11.age_ccd = '01'                                -- 연령구분코드(10대)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as ag10_pd_at        -- 10대상품금액
         , nvl(sum( case when t11.age_ccd = '02'                                -- 연령구분코드(20대)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as ag20_pd_at        -- 20대상품금액
         , nvl(sum( case when t11.age_ccd = '03'                                -- 연령구분코드(30대)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as ag30_pd_at        -- 30대상품금액
         , nvl(sum( case when t11.age_ccd = '04'                                -- 연령구분코드(40대)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as ag40_pd_at        -- 40대상품금액
         , nvl(sum( case when t11.age_ccd = '05'                                -- 연령구분코드(50대)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as ag50_pd_at        -- 50대상품금액
         , nvl(sum( case when t11.age_ccd = '06'                                -- 연령구분코드(60대)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as ag60_pd_at        -- 60대상품금액
         , nvl(sum( case when t11.age_ccd >= '07'                               -- 연령구분코드(70대)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as ag70_pd_at        -- 70대이상상품금액
         , nvl(sum( case when t11.shp_tps_clb_gcd = '01'                        -- 신한그룹탑스클럽등급코드(프리미어)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as pmr_pd_at         -- 프리미어상품금액
         , nvl(sum( case when t11.shp_tps_clb_gcd = '02'                        -- 신한그룹탑스클럽등급코드(에이스)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as ace_pd_at         -- 에이스상품금액
         , nvl(sum( case when t11.shp_tps_clb_gcd = '03'                        -- 신한그룹탑스클럽등급코드(베스트)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as bst_pd_at         -- 베스트상품금액
         , nvl(sum( case when t11.shp_tps_clb_gcd = '04'                        -- 신한그룹탑스클럽등급코드(클래식)
                         then t10.al                                            -- 잔액
                    end ), 0)                              as clsi_pd_at        -- 클래식상품금액
         , nvl(sum( case when t11.psn_etk_tf = 1                                -- 개인사업자tf
                         then t10.al                                            -- 잔액
                    end ), 0)                              as psn_etk_pd_at     -- 개인사업자상품금액
      from
           (
               select t20.ta_ym                                                 -- 기준년월
                    , t20.shmdn                                                 -- 그룹MD번호
                    , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                    , t20.lat_ct                                                -- 신규건수
                    , t20.al                                                    -- 잔액
                 from sh1.shbmtrs001             t20                            -- TRS_월고객계좌거래실적_은행
                where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                union all
               select t20.ta_ym                                                 -- 기준년월
                    , t20.shmdn                                                 -- 그룹MD번호
                    , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                    , t20.lat_ue_tf                                             -- 신규이용TF
                    , t20.ln_al                                                 -- 대출잔액
                 from sh1.shcmtrs001             t20                            -- TRS_월고객카드거래실적_카드
                where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                union all
               select t20.ta_ym                                                 -- 기준년월
                    , t20.shmdn                                                 -- 그룹MD번호
                    , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                    , 0                                  as lat_ct              -- 신규건수
                    , t20.al                                                    -- 잔액
                 from sh1.shimtrs001             t20                            -- TRS_월고객계좌거래실적_금투
                where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
                union all
               select t20.ta_ym                                                 -- 기준년월
                    , t20.shmdn                                                 -- 그룹MD번호
                    , t20.shd_pd_zcd                                            -- 데이터댐상품분류코드
                    , t20.lat_ct                                                -- 신규건수
                    , t20.al                                                    -- 잔액
                 from sh1.shlmtrs001             t20                            -- TRS_월고객계약거래실적_라이프
                where t20.ta_ym = '{date_cd('P_TA_YM')}'                        -- 기준년월
           )                                     t10
      left outer join
           sh2.shdmigd011                        t11                            -- IGD_월고객기본
        on t11.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
       and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
     group by
           t10.shd_pd_zcd                                                       -- 데이터댐상품분류코드
"""


"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmsti005_tmp99', 'pk': ['ta_ym', 'shd_pd_zcd']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmsti005                                                  -- STI_월상품통계집계
     where ta_ym = '{date_cd('P_TA_YM')}'                                       -- 기준년월
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shdmsti005                                                  -- STI_월상품통계집계
    (
           ta_ym                                                                -- 기준년월
         , shd_pd_zcd                                                           -- 데이터댐상품분류코드
         , aws_ld_dt                                                            -- AWS적재일시
         , wl_cln_cn                                                            -- 전체고객수
         , ag10_cln_cn                                                          -- 10대고객수
         , ag20_cln_cn                                                          -- 20대고객수
         , ag30_cln_cn                                                          -- 30대고객수
         , ag40_cln_cn                                                          -- 40대고객수
         , ag50_cln_cn                                                          -- 50대고객수
         , ag60_cln_cn                                                          -- 60대고객수
         , ag70_ab_cln_cn                                                       -- 70대이상고객수
         , pmr_ga_cln_cn                                                        -- 프리미어등급고객수
         , ace_ga_cln_cn                                                        -- 에이스등급고객수
         , bst_ga_cln_cn                                                        -- 베스트등급고객수
         , clsi_ga_cln_cn                                                       -- 클래식등급고객수
         , psn_etk_cln_cn                                                       -- 개인사업자고객수
         , wl_pd_jn_ct                                                          -- 전체상품가입건수
         , ag10_pd_jn_ct                                                        -- 10대상품가입건수
         , ag20_pd_jn_ct                                                        -- 20대상품가입건수
         , ag30_pd_jn_ct                                                        -- 30대상품가입건수
         , ag40_pd_jn_ct                                                        -- 40대상품가입건수
         , ag50_pd_jn_ct                                                        -- 50대상품가입건수
         , ag60_pd_jn_ct                                                        -- 60대상품가입건수
         , ag70_ab_pd_jn_ct                                                     -- 70대이상상품가입건수
         , pmr_ga_pd_jn_ct                                                      -- 프리미어등급상품가입건수
         , ace_ga_pd_jn_ct                                                      -- 에이스등급상품가입건수
         , bst_ga_pd_jn_ct                                                      -- 베스트등급상품가입건수
         , clsi_ga_pd_jn_ct                                                     -- 클래식등급상품가입건수
         , psn_etk_pd_jn_ct                                                     -- 개인사업자상품가입건수
         , wl_pd_at                                                             -- 전체상품금액
         , ag10_pd_at                                                           -- 10대상품금액
         , ag20_pd_at                                                           -- 20대상품금액
         , ag30_pd_at                                                           -- 30대상품금액
         , ag40_pd_at                                                           -- 40대상품금액
         , ag50_pd_at                                                           -- 50대상품금액
         , ag60_pd_at                                                           -- 60대상품금액
         , ag70_ab_pd_at                                                        -- 70대이상상품금액
         , pmr_pd_at                                                            -- 프리미어상품금액
         , ace_pd_at                                                            -- 에이스상품금액
         , bst_pd_at                                                            -- 베스트상품금액
         , clsi_pd_at                                                           -- 클래식상품금액
         , psn_etk_pd_at                                                        -- 개인사업자상품금액
    )
    select ta_ym                                                                -- 기준년월
         , shd_pd_zcd                                                           -- 데이터댐상품분류코드
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , wl_cln_cn                                                            -- 전체고객수
         , ag10_cln_cn                                                          -- 10대고객수
         , ag20_cln_cn                                                          -- 20대고객수
         , ag30_cln_cn                                                          -- 30대고객수
         , ag40_cln_cn                                                          -- 40대고객수
         , ag50_cln_cn                                                          -- 50대고객수
         , ag60_cln_cn                                                          -- 60대고객수
         , ag70_ab_cln_cn                                                       -- 70대이상고객수
         , pmr_ga_cln_cn                                                        -- 프리미어등급고객수
         , ace_ga_cln_cn                                                        -- 에이스등급고객수
         , bst_ga_cln_cn                                                        -- 베스트등급고객수
         , clsi_ga_cln_cn                                                       -- 클래식등급고객수
         , psn_etk_cln_cn                                                       -- 개인사업자고객수
         , wl_pd_jn_ct                                                          -- 전체상품가입건수
         , ag10_pd_jn_ct                                                        -- 10대상품가입건수
         , ag20_pd_jn_ct                                                        -- 20대상품가입건수
         , ag30_pd_jn_ct                                                        -- 30대상품가입건수
         , ag40_pd_jn_ct                                                        -- 40대상품가입건수
         , ag50_pd_jn_ct                                                        -- 50대상품가입건수
         , ag60_pd_jn_ct                                                        -- 60대상품가입건수
         , ag70_ab_pd_jn_ct                                                     -- 70대이상상품가입건수
         , pmr_ga_pd_jn_ct                                                      -- 프리미어등급상품가입건수
         , ace_ga_pd_jn_ct                                                      -- 에이스등급상품가입건수
         , bst_ga_pd_jn_ct                                                      -- 베스트등급상품가입건수
         , clsi_ga_pd_jn_ct                                                     -- 클래식등급상품가입건수
         , psn_etk_pd_jn_ct                                                     -- 개인사업자상품가입건수
         , wl_pd_at                                                             -- 전체상품금액
         , ag10_pd_at                                                           -- 10대상품금액
         , ag20_pd_at                                                           -- 20대상품금액
         , ag30_pd_at                                                           -- 30대상품금액
         , ag40_pd_at                                                           -- 40대상품금액
         , ag50_pd_at                                                           -- 50대상품금액
         , ag60_pd_at                                                           -- 60대상품금액
         , ag70_ab_pd_at                                                        -- 70대이상상품금액
         , pmr_pd_at                                                            -- 프리미어상품금액
         , ace_pd_at                                                            -- 에이스상품금액
         , bst_pd_at                                                            -- 베스트상품금액
         , clsi_pd_at                                                           -- 클래식상품금액
         , psn_etk_pd_at                                                        -- 개인사업자상품금액
      from tmp_sh2.shdmsti005_tmp99                                             -- STI_월상품통계집계_TMP99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end