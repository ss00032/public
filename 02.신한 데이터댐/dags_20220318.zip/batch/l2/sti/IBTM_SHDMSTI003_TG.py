# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "윤혁준"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["윤혁준"]
__version__    = "1.0"
__maintainer__ = "윤혁준"
__email__      = ""
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 한글 테이블명
  - TMP_SH1 테이블명
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMSTI003_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L2금융통계) STI_월GIS법정동금융통계집계 배치프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shdmsti003_tmp99', 'shdmsti003_tmp01']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmsti003_tmp01                                        -- STI_월GIS법정동금융통계집계_TMP01
    (
           ta_ym                                                                -- 기준년월
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , aws_ld_dt                                                            -- aws적재일시
         , wl_cln_cn                                                            -- 전체고객수
         , mal_cln_cn                                                           -- 남성고객수
         , fme_cln_cn                                                           -- 여성고객수
         , ag10_cln_cn                                                          -- 10대고객수
         , ag20_cln_cn                                                          -- 20대고객수
         , ag30_cln_cn                                                          -- 30대고객수
         , ag40_cln_cn                                                          -- 40대고객수
         , ag50_cln_cn                                                          -- 50대고객수
         , ag60_cln_cn                                                          -- 60대고객수
         , ag70_ab_cln_cn                                                       -- 70대이상고객수
         , psn_etk_cln_cn	                                                  -- 개인사업자고객수
         , shb_cln_cn                                                           -- 신한은행고객수
         , shc_cln_cn                                                           -- 신한카드고객수
         , shi_cln_cn                                                           -- 신한금융투자고객수
         , shl_cln_cn                                                           -- 신한라이프고객수
         , shb_atv_cln_cn                                                       -- 신한은행활동고객수
         , shc_atv_cln_cn                                                       -- 신한카드활동고객수
         , shi_atv_cln_cn                                                       -- 신한금융투자활동고객수
         , shl_atv_cln_cn                                                       -- 신한라이프활동고객수
         , pmr_ga_cln_cn                                                        -- 프리미어등급고객수
         , ace_ga_cln_cn                                                        -- 에이스등급고객수
         , bst_ga_cln_cn                                                        -- 베스트등급고객수
         , clsi_ga_cln_cn                                                       -- 클래식등급고객수
         , to_ase_at                                                            -- 총자산금액
         , cs_ase_at                                                            -- 현금자산금액
         , shb_liq_al                                                           -- 신한은행유동성잔액
         , shb_sav_al                                                           -- 신한은행예금잔액
         , shb_issv_al                                                          -- 신한은행적금잔액
         , ivs_ase_at                                                           -- 투자자산금액
         , shb_trt_al                                                           -- 신한은행신탁잔액
         , shb_fud_al                                                           -- 신한은행펀드잔액
         , shi_to_ase_at                                                        -- 신한금융투자총자산금액
         , iu_ase_at                                                            -- 보험자산금액
         , pnz_ase_at                                                           -- 연금자산금액
         , shb_rtr_pnz_al                                                       -- 신한은행퇴직연금잔액
         , shb_pnz_trt_al                                                       -- 신한은행연금신탁잔액
         , shl_pnz_iu_al                                                        -- 신한라이프연금보험잔액
         , to_lbt_at                                                            -- 총부채금액
         , cre_ln_al                                                            -- 신용대출잔액
         , shb_cre_ln_al                                                        -- 신한은행신용대출잔액
         , shc_crd_lln_al                                                       -- 신한카드카드론대출잔액
         , shc_df_lln_al                                                        -- 신한카드대환론대출잔액
         , shl_cre_ln_al                                                        -- 신한라이프신용대출잔액
         , esa_ln_al                                                            -- 부동산대출잔액
         , shb_hsg_ll_ln_al                                                     -- 신한은행주택담보대출잔액
         , shb_leh_mny_ln_al                                                    -- 신한은행전세자금대출잔액
         , shb_et_esa_ln_al                                                     -- 신한은행기타부동산대출잔액
         , shl_esa_ll_ln_al                                                     -- 신한라이프부동산담보대출잔액
         , fnn_pd_ll_ln_al                                                      -- 금융상품담보대출잔액
         , shb_fnn_pd_ll_ln_al                                                  -- 신한은행금융상품담보대출잔액
         , shl_fnn_pd_ll_ln_al                                                  -- 신한라이프금융상품담보대출잔액
         , fnc_ln_al                                                            -- 오토금융대출잔액
         , shc_fna_ncr_ln_al                                                    -- 신한카드할부금융신차대출잔액
         , shc_fna_uca_ln_al                                                    -- 신한카드할부금융중고차대출잔액
         , shc_atl_ln_al                                                        -- 신한카드오토리스대출잔액
         , shc_ltm_rntc_ln_al                                                   -- 신한카드장기렌터카대출잔액
         , shb_car_ln_al                                                        -- 신한은행자동차대출잔액
         , et_ln_al                                                             -- 기타대출잔액
         , shb_eco_ln_al                                                        -- 신한은행기업대출잔액
         , shb_psn_etk_ln_al                                                    -- 신한은행개인사업자대출잔액
         , shb_et_ln_al                                                         -- 신한은행기타대출잔액
         , shl_et_ll_ln_al                                                      -- 신한라이프기타담보대출잔액
         , to_ina                                                               -- 총소득금액
         , shb_pay_bt_at                                                        -- 신한은행급여이체금액
         , shb_pnz_bt_at                                                        -- 신한은행연금이체금액
         , to_epn_at                                                            -- 총지출금액
         , shc_cre_cl_uea                                                       -- 신한카드신용신판이용금액
         , shc_chc_uea                                                          -- 신한카드체크카드이용금액
         , shc_utb_uea                                                          -- 신한카드공과금이용금액
         , shc_cmu_rain_uea                                                     -- 신한카드통신비이용금액
         , shc_irg_uea                                                          -- 신한카드보험료이용금액
         , shc_trf_uea                                                          -- 신한카드교통이용금액
         , shc_dot_uea                                                          -- 신한카드외식이용금액
         , shc_car_oln_uea                                                      -- 신한카드자동차주유이용금액
         , shc_cnvs_uea                                                         -- 신한카드편의점이용금액
         , shc_byu_hlt_uea                                                      -- 신한카드미용건강이용금액
         , shc_dpr_uea                                                          -- 신한카드백화점이용금액
         , shc_bkry_uea                                                         -- 신한카드제과이용금액
         , shc_hspt_phmc_uea                                                    -- 신한카드병원약국이용금액
         , gpm_irg_at                                                           -- 납입보험료금액
         , mrp_pd_pss_cln_cn                                                    -- 입출금상품보유고객수
         , sai_pd_pss_cln_cn                                                    -- 예적금상품보유고객수
         , ln_pd_pss_cln_cn                                                     -- 대출상품보유고객수
         , ivs_pd_pss_cln_cn                                                    -- 투자상품보유고객수
         , pnz_pd_pss_cln_cn                                                    -- 연금상품보유고객수
         , iu_pd_pss_cln_cn                                                     -- 보험상품보유고객수
         , crd_pd_pss_cln_cn                                                    -- 카드상품보유고객수
         , to_mct_ct                                                            -- 총가맹점건수
         , to_mct_saa                                                           -- 총가맹점매출금액
         , to_mct_ue_ct                                                         -- 총가맹점이용건수
         , shc_dot_mct_saa                                                      -- 신한카드외식가맹점매출금액
         , shc_car_oln_mct_saa                                                  -- 신한카드자동차주유가맹점매출금액
         , shc_cnvs_mct_saa                                                     -- 신한카드편의점가맹점매출금액
         , shc_byu_hlt_mct_saa                                                  -- 신한카드미용건강가맹점매출금액
         , shc_dpr_mct_saa                                                      -- 신한카드백화점가맹점매출금액
         , shc_bkry_mct_saa                                                     -- 신한카드제과가맹점매출금액
         , shc_hspt_phmc_mct_saa                                                -- 신한카드병원약국가맹점매출금액
    )
    select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
         , nvl(t10.hm_cou_gds_apb_cd, ' ')                 as hm_cou_gds_apb_cd -- 자택법정GDS동코드
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         -- 고객수
         , count(distinct t10.shmdn)                       as wl_cln_cn         -- 전체고객수
         , count( distinct case when t10.sex_ccd = 'M'                          -- 성별구분코드(남자)
                                then t10.shmdn
                           end )                           as mal_cln_cn        -- 남성고객수
         , count( distinct case when t10.sex_ccd = 'F'                          -- 성별구분코드(여자)
                                then t10.shmdn
                           end )                           as fme_cln_cn        -- 여성고객수
         , count( distinct case when t10.age_ccd = '01'                         -- 연령구분코드(10대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag10_cln_cn       -- 10대고객수
         , count( distinct case when t10.age_ccd = '02'                         -- 연령구분코드(20대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag20_cln_cn       -- 20대고객수
         , count( distinct case when t10.age_ccd = '03'                         -- 연령구분코드(30대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag30_cln_cn       -- 30대고객수
         , count( distinct case when t10.age_ccd = '04'                         -- 연령구분코드(40대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag40_cln_cn       -- 40대고객수
         , count( distinct case when t10.age_ccd = '05'                         -- 연령구분코드(50대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag50_cln_cn       -- 50대고객수
         , count( distinct case when t10.age_ccd = '06'                         -- 연령구분코드(60대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag60_cln_cn       -- 60대고객수
         , count( distinct case when t10.age_ccd >= '07'                        -- 연령구분코드(70대)
                                then t10.shmdn                                  -- 그룹MD번호
                           end )                           as ag70_ab_cln_cn    -- 70대이상고객수
         , nvl(sum(t10.psn_etk_tf), 0)                     as psn_etk_cln_cn    -- 개인사업자고객수(개인사업자tf)
         , nvl(sum(t10.shb_cln_tf), 0)                     as shb_cln_cn        -- 신한은행고객수(신한은행고객tf)
         , nvl(sum(t10.shc_cln_tf), 0)                     as shc_cln_cn        -- 신한카드고객수(신한카드고객tf)
         , nvl(sum(t10.shi_cln_tf), 0)                     as shi_cln_cn        -- 신한금융투자고객수(신한금융투자고객tf)
         , nvl(sum(t10.shl_cln_tf), 0)                     as shl_cln_cn        -- 신한라이프고객수(신한라이프고객tf)
         , nvl(sum(t10.shb_atv_tf), 0)                     as shb_atv_cln_cn    -- 신한은행활동고객수(신한은행활동tf)
         , nvl(sum(t10.shc_atv_tf), 0)                     as shc_atv_cln_cn    -- 신한카드활동고객수(신한카드활동tf)
         , nvl(sum(t10.shi_atv_tf), 0)                     as shi_atv_cln_cn    -- 신한금융투자활동고객수(신한금융투자활동tf)
         , nvl(sum(t10.shl_atv_tf), 0)                     as shl_atv_cln_cn    -- 신한라이프활동고객수(신한라이프활동tf)
         , count( distinct case when t10.shp_tps_clb_gcd = '01'                 -- 신한그룹탑스클럽등급코드(프리미어)
                                then t10.shmdn
                           end )                           as pmr_ga_cln_cn     -- 프리미어등급고객수
         , count( distinct case when t10.shp_tps_clb_gcd = '02'                 -- 신한그룹탑스클럽등급코드(에이스)
                                then t10.shmdn
                           end )                           as ace_ga_cln_cn     -- 에이스등급고객수
         , count( distinct case when t10.shp_tps_clb_gcd = '03'                 -- 신한그룹탑스클럽등급코드(베스트)
                                then t10.shmdn
                           end )                           as bst_ga_cln_cn     -- 베스트등급고객수
         , count( distinct case when t10.shp_tps_clb_gcd = '04'                 -- 신한그룹탑스클럽등급코드(클래식)
                                then t10.shmdn
                           end )                           as clsi_ga_cln_cn    -- 클래식등급고객수
         -- 자산
         , nvl(sum(t11.to_ase_at), 0)            as to_ase_at                   -- 총자산금액
         , nvl(sum(t11.cs_ase_at), 0)            as cs_ase_at                   -- 현금자산금액
         , nvl(sum(t12.liq_al), 0)               as shb_liq_al                  -- 신한은행유동성잔액
         , nvl(sum(t12.sav_al), 0)               as shb_sav_al                  -- 신한은행예금잔액
         , nvl(sum(t12.issv_al), 0)              as shb_issv_al                 -- 신한은행적금잔액
         , nvl(sum(t11.ivs_ase_at), 0)           as ivs_ase_at                  -- 투자자산금액
         , nvl(sum(t12.trt_al), 0)               as shb_trt_al                  -- 신한은행신탁잔액
         , nvl(sum(t12.fud_al), 0)               as shb_fud_al                  -- 신한은행펀드잔액
         , nvl(sum(t14.to_ase_at), 0)            as shi_to_ase_at               -- 신한금융투자총자산금액
         , nvl(sum(t11.iu_ase_at), 0)            as iu_ase_at                   -- 보험자산금액
         , nvl(sum(t11.pnz_ase_at), 0)           as pnz_ase_at                  -- 연금자산금액
         , nvl(sum(t12.rtr_pnz_al), 0)           as shb_rtr_pnz_al              -- 신한은행퇴직연금잔액
         , nvl(sum(t12.pnz_trt_al), 0)           as shb_pnz_trt_al              -- 신한은행연금신탁잔액
         , nvl(sum(t15.pnz_iu_al), 0)            as shl_pnz_iu_al               -- 신한라이프연금보험잔액(연금보험잔액)
         -- 부채
         , nvl(sum(t11.to_lbt_at), 0)            as to_lbt_at                   -- 총부채금액
         , nvl(sum(t11.cre_ln_al), 0)            as cre_ln_al                   -- 신용대출잔액
         , nvl(sum(t12.cre_ln_al), 0)            as shb_cre_ln_al               -- 신한은행신용대출잔액
         , nvl(sum(t13.crd_lln_al), 0)           as shc_crd_lln_al              -- 신한카드카드론대출잔액
         , nvl(sum(t13.dfl_ln_al), 0)            as shc_df_lln_al               -- 신한카드대환론대출잔액
         , nvl(sum(t15.cre_ln_al), 0)            as shl_cre_ln_al               -- 신한라이프신용대출잔액
         , nvl(sum(t11.esa_ln_al), 0)            as esa_ln_al                   -- 부동산대출잔액
         , nvl(sum(t12.hsg_ll_ln_al), 0)         as shb_hsg_ll_ln_al            -- 신한은행주택담보대출잔액
         , nvl(sum(t12.leh_mny_ln_al), 0)        as shb_leh_mny_ln_al           -- 신한은행전세자금대출잔액
         , nvl(sum(t12.et_esa_ln_al), 0)         as shb_et_esa_ln_al            -- 신한은행기타부동산대출잔액
         , nvl(sum(t15.esa_ll_ln_al), 0)         as shl_esa_ll_ln_al            -- 신한라이프부동산담보대출잔액
         , nvl(sum(t11.fnn_pd_ll_ln_al), 0)      as fnn_pd_ll_ln_al             -- 금융상품담보대출잔액
         , nvl(sum(t12.fnn_pd_ll_ln_al), 0)      as shb_fnn_pd_ll_ln_al         -- 신한은행금융상품담보대출잔액
         , nvl(sum(t15.iu_are_ln_al), 0)         as shl_fnn_pd_ll_ln_al         -- 신한라이프금융상품담보대출잔액(보험계약대출잔액)
         , nvl(sum(t11.fnc_ln_al), 0)            as fnc_ln_al                   -- 오토금융대출잔액
         , nvl(sum(t13.fna_ncr_ln_al), 0)        as shc_fna_ncr_ln_al           -- 신한카드할부금융신차대출잔액
         , nvl(sum(t13.fna_uca_ln_al), 0)        as shc_fna_uca_ln_al           -- 신한카드할부금융중고차대출잔액
         , nvl(sum(t13.atl_ln_al), 0)            as shc_atl_ln_al               -- 신한카드오토리스대출잔액
         , nvl(sum(t13.ltm_rntc_ln_al), 0)       as shc_ltm_rntc_ln_al          -- 신한카드장기렌터카대출잔액
         , nvl(sum(t12.car_ln_al), 0)            as shb_car_ln_al               -- 신한은행자동차대출잔액
         , nvl(sum(t11.et_ln_al), 0)             as et_ln_al                    -- 기타대출잔액
         , nvl(sum(t12.eco_ln_al), 0)            as shb_eco_ln_al               -- 신한은행기업대출잔액
         , nvl(sum(t12.psn_etk_ln_al), 0)        as shb_psn_etk_ln_al           -- 신한은행개인사업자대출잔액
         , nvl(sum(t12.et_ln_al), 0)             as shb_et_ln_al                -- 신한은행기타대출잔액
         , nvl(sum(t15.et_ll_ln_al), 0)          as shl_et_ll_ln_al             -- 신한라이프기타담보대출잔액
         , nvl(sum(t11.to_ina), 0)               as to_ina                      -- 총소득금액
         , nvl(sum(t12.pay_bt_at), 0)            as shb_pay_bt_at               -- 신한은행급여이체금액
         , nvl(sum(t12.pnz_bt_at), 0)            as shb_pnz_bt_at               -- 신한은행연금이체금액
         -- 지출
         , nvl(sum(t11.to_epn_at), 0)            as to_epn_at                   -- 총지출금액
         , nvl(sum(t11.cre_cl_uea), 0)           as shc_cre_cl_uea              -- 신한카드신용신판이용금액
         , nvl(sum(t11.chc_uea), 0)              as shc_chc_uea                 -- 신한카드체크카드이용금액
         , nvl(sum(t13.utb_uea), 0)              as shc_utb_uea                 -- 신한카드공과금이용금액
         , nvl(sum(t13.cmu_rain_uea), 0)         as shc_cmu_rain_uea            -- 신한카드통신비이용금액
         , nvl(sum(t13.irg_uea), 0)              as shc_irg_uea                 -- 신한카드보험료이용금액
         , nvl(sum(t13.trf_uea), 0)              as shc_trf_uea                 -- 신한카드교통이용금액
         , nvl(sum(t13.dot_uea), 0)              as shc_dot_uea                 -- 신한카드외식이용금액
         , nvl(sum(t13.car_oln_uea), 0)          as shc_car_oln_uea             -- 신한카드자동차주유이용금액
         , nvl(sum(t13.cnvs_uea), 0)             as shc_cnvs_uea                -- 신한카드편의점이용금액
         , nvl(sum(t13.byu_hlt_uea), 0)          as shc_byu_hlt_uea             -- 신한카드미용건강이용금액
         , nvl(sum(t13.dpr_uea), 0)              as shc_dpr_uea                 -- 신한카드백화점이용금액
         , nvl(sum(t13.bkry_uea), 0)             as shc_bkry_uea                -- 신한카드제과이용금액
         , nvl(sum(t13.hspt_phmc_uea), 0)        as shc_hspt_phmc_uea           -- 신한카드병원약국이용금액
         , nvl(sum(t11.gpm_irg_at), 0)           as gpm_irg_at                  -- 납입보험료금액
         -- 상품보유고객수
         , count( distinct case when t16.mrp_pd_pss_tf = 1                      -- 입출금상품보유TF
                                then t10.shmdn
                           end )                 as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
         , count( distinct case when t16.sai_pd_pss_tf = 1                      -- 예적금상품보유TF
                                then t10.shmdn
                           end )                 as sai_pd_pss_cln_cn           -- 예적금상품보유고객수
         , count( distinct case when t16.ln_pd_pss_tf = 1                       -- 대출상품보유TF
                                then t10.shmdn
                           end )                 as ln_pd_pss_cln_cn            -- 대출상품보유고객수
         , count( distinct case when t16.ivs_pd_pss_tf = 1                      -- 투자상품보유TF
                                then t10.shmdn
                           end )                 as ivs_pd_pss_cln_cn           -- 투자상품보유고객수
         , count( distinct case when t16.pnz_pd_pss_tf = 1                      -- 연금상품보유TF
                                then t10.shmdn
                           end )                 as pnz_pd_pss_cln_cn           -- 연금상품보유고객수
         , count( distinct case when t16.iu_pd_pss_tf = 1                       -- 보험상품보유TF
                                then t10.shmdn
                           end )                  as iu_pd_pss_cln_cn           -- 보험상품보유고객수

         , count( distinct case when t16.crd_pd_pss_tf = 1                      -- 카드상품보유TF
                                then t10.shmdn
                           end )                  as crd_pd_pss_cln_cn          -- 카드상품보유고객수
         -- 가맹점원장
         , 0                                     as to_mct_ct                   -- 총가맹점건수
         , 0                                     as to_mct_saa                  -- 총가맹점매출금액
         , 0                                     as to_mct_ue_ct                -- 총가맹점이용건수
         , 0                                     as shc_dot_mct_saa             -- 신한카드외식가맹점매출금액(외식이용금액)
         , 0                                     as shc_car_oln_mct_saa         -- 신한카드자동차주유가맹점매출금액(자동차주유이용금액)
         , 0                                     as shc_cnvs_mct_saa            -- 신한카드편의점가맹점매출금액(편의점이용금액)
         , 0                                     as shc_byu_hlt_mct_saa         -- 신한카드미용건강가맹점매출금액(미용건강이용금액)
         , 0                                     as shc_dpr_mct_saa             -- 신한카드백화점가맹점매출금액(백화점이용금액)
         , 0                                     as shc_bkry_mct_saa            -- 신한카드제과가맹점매출금액(제과이용금액)
         , 0                                     as shc_hspt_phmc_mct_saa       -- 신한카드병원약국가맹점매출금액(병원약국이용금액)
      from sh2.shdmigd011                        t10                            -- IGD_월고객기본
      left outer join
           sh2.shdmigd006                        t11                            -- IGD_월고객거래실적
        on t10.ta_ym = t11.ta_ym                                                -- 기준년월
       and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
      left outer join
           sh2.shdmigd007                        t12                            -- IGD_월고객거래실적_은행
        on t10.ta_ym = t12.ta_ym                                                -- 기준년월
       and t10.shmdn = t12.shmdn                                                -- 그룹MD번호
      left outer join
           sh2.shdmigd008                        t13                            -- IGD_월고객거래실적_카드
        on t10.ta_ym = t13.ta_ym                                                -- 기준년월
       and t10.shmdn = t13.shmdn                                                -- 그룹MD번호
      left outer join
           sh2.shdmigd009                        t14                            -- IGD_월고객거래실적_금투
        on t10.ta_ym = t14.ta_ym                                                -- 기준년월
       and t10.shmdn = t14.shmdn                                                -- 그룹MD번호
      left outer join
           sh2.shdmigd010                        t15                            -- IGD_월고객거래실적_라이프
        on t10.ta_ym = t15.ta_ym                                                -- 기준년월
       and t10.shmdn = t15.shmdn                                                -- 그룹MD번호
      left outer join
           sh2.shdmigd003                        t16                            -- IGD_월고객보유상품기본
        on t10.ta_ym = t16.ta_ym                                                -- 기준년월
       and t10.shmdn = t16.shmdn                                                -- 그룹MD번호
     where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
       and trim(t10.hm_cou_gds_apb_cd) is not null                              -- 자택법정GDS동코드
     group by
           nvl(t10.hm_cou_gds_apb_cd, ' ')                                      -- 자택법정GDS동코드
"""

insert_sql_for_tmp_2 = f"""
    insert into tmp_sh2.shdmsti003_tmp01                                        -- STI_월GIS법정동금융통계집계_TMP01
    (
           ta_ym                                                                -- 기준년월
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , aws_ld_dt                                                            -- aws적재일시
         , wl_cln_cn                                                            -- 전체고객수
         , mal_cln_cn                                                           -- 남성고객수
         , fme_cln_cn                                                           -- 여성고객수
         , ag10_cln_cn                                                          -- 10대고객수
         , ag20_cln_cn                                                          -- 20대고객수
         , ag30_cln_cn                                                          -- 30대고객수
         , ag40_cln_cn                                                          -- 40대고객수
         , ag50_cln_cn                                                          -- 50대고객수
         , ag60_cln_cn                                                          -- 60대고객수
         , ag70_ab_cln_cn                                                       -- 70대이상고객수
         , psn_etk_cln_cn	                                                  -- 개인사업자고객수
         , shb_cln_cn                                                           -- 신한은행고객수
         , shc_cln_cn                                                           -- 신한카드고객수
         , shi_cln_cn                                                           -- 신한금융투자고객수
         , shl_cln_cn                                                           -- 신한라이프고객수
         , shb_atv_cln_cn                                                       -- 신한은행활동고객수
         , shc_atv_cln_cn                                                       -- 신한카드활동고객수
         , shi_atv_cln_cn                                                       -- 신한금융투자활동고객수
         , shl_atv_cln_cn                                                       -- 신한라이프활동고객수
         , pmr_ga_cln_cn                                                        -- 프리미어등급고객수
         , ace_ga_cln_cn                                                        -- 에이스등급고객수
         , bst_ga_cln_cn                                                        -- 베스트등급고객수
         , clsi_ga_cln_cn                                                       -- 클래식등급고객수
         , to_ase_at                                                            -- 총자산금액
         , cs_ase_at                                                            -- 현금자산금액
         , shb_liq_al                                                           -- 신한은행유동성잔액
         , shb_sav_al                                                           -- 신한은행예금잔액
         , shb_issv_al                                                          -- 신한은행적금잔액
         , ivs_ase_at                                                           -- 투자자산금액
         , shb_trt_al                                                           -- 신한은행신탁잔액
         , shb_fud_al                                                           -- 신한은행펀드잔액
         , shi_to_ase_at                                                        -- 신한금융투자총자산금액
         , iu_ase_at                                                            -- 보험자산금액
         , pnz_ase_at                                                           -- 연금자산금액
         , shb_rtr_pnz_al                                                       -- 신한은행퇴직연금잔액
         , shb_pnz_trt_al                                                       -- 신한은행연금신탁잔액
         , shl_pnz_iu_al                                                        -- 신한라이프연금보험잔액
         , to_lbt_at                                                            -- 총부채금액
         , cre_ln_al                                                            -- 신용대출잔액
         , shb_cre_ln_al                                                        -- 신한은행신용대출잔액
         , shc_crd_lln_al                                                       -- 신한카드카드론대출잔액
         , shc_df_lln_al                                                        -- 신한카드대환론대출잔액
         , shl_cre_ln_al                                                        -- 신한라이프신용대출잔액
         , esa_ln_al                                                            -- 부동산대출잔액
         , shb_hsg_ll_ln_al                                                     -- 신한은행주택담보대출잔액
         , shb_leh_mny_ln_al                                                    -- 신한은행전세자금대출잔액
         , shb_et_esa_ln_al                                                     -- 신한은행기타부동산대출잔액
         , shl_esa_ll_ln_al                                                     -- 신한라이프부동산담보대출잔액
         , fnn_pd_ll_ln_al                                                      -- 금융상품담보대출잔액
         , shb_fnn_pd_ll_ln_al                                                  -- 신한은행금융상품담보대출잔액
         , shl_fnn_pd_ll_ln_al                                                  -- 신한라이프금융상품담보대출잔액
         , fnc_ln_al                                                            -- 오토금융대출잔액
         , shc_fna_ncr_ln_al                                                    -- 신한카드할부금융신차대출잔액
         , shc_fna_uca_ln_al                                                    -- 신한카드할부금융중고차대출잔액
         , shc_atl_ln_al                                                        -- 신한카드오토리스대출잔액
         , shc_ltm_rntc_ln_al                                                   -- 신한카드장기렌터카대출잔액
         , shb_car_ln_al                                                        -- 신한은행자동차대출잔액
         , et_ln_al                                                             -- 기타대출잔액
         , shb_eco_ln_al                                                        -- 신한은행기업대출잔액
         , shb_psn_etk_ln_al                                                    -- 신한은행개인사업자대출잔액
         , shb_et_ln_al                                                         -- 신한은행기타대출잔액
         , shl_et_ll_ln_al                                                      -- 신한라이프기타담보대출잔액
         , to_ina                                                               -- 총소득금액
         , shb_pay_bt_at                                                        -- 신한은행급여이체금액
         , shb_pnz_bt_at                                                        -- 신한은행연금이체금액
         , to_epn_at                                                            -- 총지출금액
         , shc_cre_cl_uea                                                       -- 신한카드신용신판이용금액
         , shc_chc_uea                                                          -- 신한카드체크카드이용금액
         , shc_utb_uea                                                          -- 신한카드공과금이용금액
         , shc_cmu_rain_uea                                                     -- 신한카드통신비이용금액
         , shc_irg_uea                                                          -- 신한카드보험료이용금액
         , shc_trf_uea                                                          -- 신한카드교통이용금액
         , shc_dot_uea                                                          -- 신한카드외식이용금액
         , shc_car_oln_uea                                                      -- 신한카드자동차주유이용금액
         , shc_cnvs_uea                                                         -- 신한카드편의점이용금액
         , shc_byu_hlt_uea                                                      -- 신한카드미용건강이용금액
         , shc_dpr_uea                                                          -- 신한카드백화점이용금액
         , shc_bkry_uea                                                         -- 신한카드제과이용금액
         , shc_hspt_phmc_uea                                                    -- 신한카드병원약국이용금액
         , gpm_irg_at                                                           -- 납입보험료금액
         , mrp_pd_pss_cln_cn                                                    -- 입출금상품보유고객수
         , sai_pd_pss_cln_cn                                                    -- 예적금상품보유고객수
         , ln_pd_pss_cln_cn                                                     -- 대출상품보유고객수
         , ivs_pd_pss_cln_cn                                                    -- 투자상품보유고객수
         , pnz_pd_pss_cln_cn                                                    -- 연금상품보유고객수
         , iu_pd_pss_cln_cn                                                     -- 보험상품보유고객수
         , crd_pd_pss_cln_cn                                                    -- 카드상품보유고객수
         , to_mct_ct                                                            -- 총가맹점건수
         , to_mct_saa                                                           -- 총가맹점매출금액
         , to_mct_ue_ct                                                         -- 총가맹점이용건수
         , shc_dot_mct_saa                                                      -- 신한카드외식가맹점매출금액
         , shc_car_oln_mct_saa                                                  -- 신한카드자동차주유가맹점매출금액
         , shc_cnvs_mct_saa                                                     -- 신한카드편의점가맹점매출금액
         , shc_byu_hlt_mct_saa                                                  -- 신한카드미용건강가맹점매출금액
         , shc_dpr_mct_saa                                                      -- 신한카드백화점가맹점매출금액
         , shc_bkry_mct_saa                                                     -- 신한카드제과가맹점매출금액
         , shc_hspt_phmc_mct_saa                                                -- 신한카드병원약국가맹점매출금액
    )
    select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
         , nvl(t10.mct_cou_gds_apb_cd, ' ')                as hm_cou_gds_apb_cd -- 자택법정GDS동코드(가맹점법정GDS동코드)
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , 0                                     as wl_cln_cn                   -- 전체고객수
         , 0                                     as mal_cln_cn                  -- 남성고객수
         , 0                                     as fme_cln_cn                  -- 여성고객수
         , 0                                     as ag10_cln_cn                 -- 10대고객수
         , 0                                     as ag20_cln_cn                 -- 20대고객수
         , 0                                     as ag30_cln_cn                 -- 30대고객수
         , 0                                     as ag40_cln_cn                 -- 40대고객수
         , 0                                     as ag50_cln_cn                 -- 50대고객수
         , 0                                     as ag60_cln_cn                 -- 60대고객수
         , 0                                     as ag70_ab_cln_cn              -- 70대이상고객수
         , 0                                     as psn_etk_cln_cn	          -- 개인사업자고객수
         , 0                                     as shb_cln_cn                  -- 신한은행고객수
         , 0                                     as shc_cln_cn                  -- 신한카드고객수
         , 0                                     as shi_cln_cn                  -- 신한금융투자고객수
         , 0                                     as shl_cln_cn                  -- 신한라이프고객수
         , 0                                     as shb_atv_cln_cn              -- 신한은행활동고객수
         , 0                                     as shc_atv_cln_cn              -- 신한카드활동고객수
         , 0                                     as shi_atv_cln_cn              -- 신한금융투자활동고객수
         , 0                                     as shl_atv_cln_cn              -- 신한라이프활동고객수
         , 0                                     as pmr_ga_cln_cn               -- 프리미어등급고객수
         , 0                                     as ace_ga_cln_cn               -- 에이스등급고객수
         , 0                                     as bst_ga_cln_cn               -- 베스트등급고객수
         , 0                                     as clsi_ga_cln_cn              -- 클래식등급고객수
         , 0                                     as to_ase_at                   -- 총자산금액
         , 0                                     as cs_ase_at                   -- 현금자산금액
         , 0                                     as shb_liq_al                  -- 신한은행유동성잔액
         , 0                                     as shb_sav_al                  -- 신한은행예금잔액
         , 0                                     as shb_issv_al                 -- 신한은행적금잔액
         , 0                                     as ivs_ase_at                  -- 투자자산금액
         , 0                                     as shb_trt_al                  -- 신한은행신탁잔액
         , 0                                     as shb_fud_al                  -- 신한은행펀드잔액
         , 0                                     as shi_to_ase_at               -- 신한금융투자총자산금액
         , 0                                     as iu_ase_at                   -- 보험자산금액
         , 0                                     as pnz_ase_at                  -- 연금자산금액
         , 0                                     as shb_rtr_pnz_al              -- 신한은행퇴직연금잔액
         , 0                                     as shb_pnz_trt_al              -- 신한은행연금신탁잔액
         , 0                                     as shl_pnz_iu_al               -- 신한라이프연금보험잔액
         , 0                                     as to_lbt_at                   -- 총부채금액
         , 0                                     as cre_ln_al                   -- 신용대출잔액
         , 0                                     as shb_cre_ln_al               -- 신한은행신용대출잔액
         , 0                                     as shc_crd_lln_al              -- 신한카드카드론대출잔액
         , 0                                     as shc_df_lln_al               -- 신한카드대환론대출잔액
         , 0                                     as shl_cre_ln_al               -- 신한라이프신용대출잔액
         , 0                                     as esa_ln_al                   -- 부동산대출잔액
         , 0                                     as shb_hsg_ll_ln_al            -- 신한은행주택담보대출잔액
         , 0                                     as shb_leh_mny_ln_al           -- 신한은행전세자금대출잔액
         , 0                                     as shb_et_esa_ln_al            -- 신한은행기타부동산대출잔액
         , 0                                     as shl_esa_ll_ln_al            -- 신한라이프부동산담보대출잔액
         , 0                                     as fnn_pd_ll_ln_al             -- 금융상품담보대출잔액
         , 0                                     as shb_fnn_pd_ll_ln_al         -- 신한은행금융상품담보대출잔액
         , 0                                     as shl_fnn_pd_ll_ln_al         -- 신한라이프금융상품담보대출잔액
         , 0                                     as fnc_ln_al                   -- 오토금융대출잔액
         , 0                                     as shc_fna_ncr_ln_al           -- 신한카드할부금융신차대출잔액
         , 0                                     as shc_fna_uca_ln_al           -- 신한카드할부금융중고차대출잔액
         , 0                                     as shc_atl_ln_al               -- 신한카드오토리스대출잔액
         , 0                                     as shc_ltm_rntc_ln_al          -- 신한카드장기렌터카대출잔액
         , 0                                     as shb_car_ln_al               -- 신한은행자동차대출잔액
         , 0                                     as et_ln_al                    -- 기타대출잔액
         , 0                                     as shb_eco_ln_al               -- 신한은행기업대출잔액
         , 0                                     as shb_psn_etk_ln_al           -- 신한은행개인사업자대출잔액
         , 0                                     as shb_et_ln_al                -- 신한은행기타대출잔액
         , 0                                     as shl_et_ll_ln_al             -- 신한라이프기타담보대출잔액
         , 0                                     as to_ina                      -- 총소득금액
         , 0                                     as shb_pay_bt_at               -- 신한은행급여이체금액
         , 0                                     as shb_pnz_bt_at               -- 신한은행연금이체금액
         , 0                                     as to_epn_at                   -- 총지출금액
         , 0                                     as shc_cre_cl_uea              -- 신한카드신용신판이용금액
         , 0                                     as shc_chc_uea                 -- 신한카드체크카드이용금액
         , 0                                     as shc_utb_uea                 -- 신한카드공과금이용금액
         , 0                                     as shc_cmu_rain_uea            -- 신한카드통신비이용금액
         , 0                                     as shc_irg_uea                 -- 신한카드보험료이용금액
         , 0                                     as shc_trf_uea                 -- 신한카드교통이용금액
         , 0                                     as shc_dot_uea                 -- 신한카드외식이용금액
         , 0                                     as shc_car_oln_uea             -- 신한카드자동차주유이용금액
         , 0                                     as shc_cnvs_uea                -- 신한카드편의점이용금액
         , 0                                     as shc_byu_hlt_uea             -- 신한카드미용건강이용금액
         , 0                                     as shc_dpr_uea                 -- 신한카드백화점이용금액
         , 0                                     as shc_bkry_uea                -- 신한카드제과이용금액
         , 0                                     as shc_hspt_phmc_uea           -- 신한카드병원약국이용금액
         , 0                                     as gpm_irg_at                  -- 납입보험료금액
         , 0                                     as mrp_pd_pss_cln_cn           -- 입출금상품보유고객수
         , 0                                     as sai_pd_pss_cln_cn           -- 예적금상품보유고객수
         , 0                                     as ln_pd_pss_cln_cn            -- 대출상품보유고객수
         , 0                                     as ivs_pd_pss_cln_cn           -- 투자상품보유고객수
         , 0                                     as pnz_pd_pss_cln_cn           -- 연금상품보유고객수
         , 0                                     as iu_pd_pss_cln_cn            -- 보험상품보유고객수
         , 0                                     as crd_pd_pss_cln_cn           -- 카드상품보유고객수
         -- 가맹점원장
         , count(distinct t10.mct_n)             as to_mct_ct                   -- 총가맹점건수
         , nvl(sum(t10.saa)  , 0)                as to_mct_saa                  -- 총가맹점매출금액
         , nvl(sum(t10.ue_ct), 0)                as to_mct_ue_ct                -- 총가맹점이용건수
         , nvl(sum(case when substring(t10.mct_ry_cd, 1, 1) = '3'               -- 가맹점업종코드
                        then t10.saa                                            -- 매출금액
                        else 0
                   end), 0)                      as shc_dot_mct_saa             -- 신한카드외식가맹점매출금액
         , nvl(sum(case when t10.mct_ry_cd in ('741000', '742000', '765000', '767000', '911000', '912000', '913000', '921000', '922000', '923000', '931000', '941000', '942000', '951000')
                        then t10.saa                                            -- 매출금액
                        else 0
                   end), 0)                      as shc_car_oln_mct_saa         -- 신한카드자동차주유가맹점매출금액
         , nvl(sum(case when t10.mct_ry_cd = '215000'                           -- 가맹점업종코드
                        then t10.saa                                            -- 매출금액
                        else 0
                   end), 0)                      as shc_cnvs_mct_saa            -- 신한카드편의점가맹점매출금액
         , nvl(sum(case when t10.mct_ry_cd in ('242000', '672000', '671000', '841000', '842000', '843000', '844000', '845000', '846000', '847000', '848000')
                        then t10.saa                                            -- 매출금액
                        else 0
                   end), 0)                      as shc_byu_hlt_mct_saa         -- 신한카드미용건강가맹점매출금액
         , nvl(sum(case when t10.mct_ry_cd = '211000'                           -- 가맹점업종코드
                        then t10.saa                                            -- 매출금액
                        else 0
                   end), 0)                      as shc_dpr_mct_saa             -- 신한카드백화점가맹점매출금액
         , nvl(sum(case when t10.mct_ry_cd in ('327000', '241000')              -- 가맹점업종코드
                        then t10.saa                                            -- 매출금액
                        else 0
                   end), 0)                      as shc_bkry_mct_saa            -- 신한카드제과가맹점매출금액
         , nvl(sum(case when t10.mct_ry_cd in ('811000', '812000', '813000', '814000', '815000', '816000', '821000', '822000', '823000', '824000', '831000')
                        then t10.saa                                            -- 매출금액
                        else 0
                   end), 0)                      as shc_hspt_phmc_mct_saa       -- 신한카드병원약국가맹점매출금액
      from sh1.shcmtrs003                        t10                            -- TRS_월개인사업자가맹점매출실적_카드
     where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
       and trim(t10.mct_cou_gds_apb_cd) is not null                             -- 가맹점법정GDS동코드
     group by
           nvl(t10.mct_cou_gds_apb_cd, ' ')                                     -- 가맹점법정GDS동코드
"""

insert_sql_for_tmp_3 = f"""
    insert into tmp_sh2.shdmsti003_tmp99                                        -- STI_월GIS법정동금융통계집계_TMP99
    (
           ta_ym                                                                -- 기준년월
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , aws_ld_dt                                                            -- aws적재일시
         , wl_cln_cn                                                            -- 전체고객수
         , mal_cln_cn                                                           -- 남성고객수
         , fme_cln_cn                                                           -- 여성고객수
         , ag10_cln_cn                                                          -- 10대고객수
         , ag20_cln_cn                                                          -- 20대고객수
         , ag30_cln_cn                                                          -- 30대고객수
         , ag40_cln_cn                                                          -- 40대고객수
         , ag50_cln_cn                                                          -- 50대고객수
         , ag60_cln_cn                                                          -- 60대고객수
         , ag70_ab_cln_cn                                                       -- 70대이상고객수
         , psn_etk_cln_cn	                                                  -- 개인사업자고객수
         , shb_cln_cn                                                           -- 신한은행고객수
         , shc_cln_cn                                                           -- 신한카드고객수
         , shi_cln_cn                                                           -- 신한금융투자고객수
         , shl_cln_cn                                                           -- 신한라이프고객수
         , shb_atv_cln_cn                                                       -- 신한은행활동고객수
         , shc_atv_cln_cn                                                       -- 신한카드활동고객수
         , shi_atv_cln_cn                                                       -- 신한금융투자활동고객수
         , shl_atv_cln_cn                                                       -- 신한라이프활동고객수
         , pmr_ga_cln_cn                                                        -- 프리미어등급고객수
         , ace_ga_cln_cn                                                        -- 에이스등급고객수
         , bst_ga_cln_cn                                                        -- 베스트등급고객수
         , clsi_ga_cln_cn                                                       -- 클래식등급고객수
         , to_ase_at                                                            -- 총자산금액
         , cs_ase_at                                                            -- 현금자산금액
         , shb_liq_al                                                           -- 신한은행유동성잔액
         , shb_sav_al                                                           -- 신한은행예금잔액
         , shb_issv_al                                                          -- 신한은행적금잔액
         , ivs_ase_at                                                           -- 투자자산금액
         , shb_trt_al                                                           -- 신한은행신탁잔액
         , shb_fud_al                                                           -- 신한은행펀드잔액
         , shi_to_ase_at                                                        -- 신한금융투자총자산금액
         , iu_ase_at                                                            -- 보험자산금액
         , pnz_ase_at                                                           -- 연금자산금액
         , shb_rtr_pnz_al                                                       -- 신한은행퇴직연금잔액
         , shb_pnz_trt_al                                                       -- 신한은행연금신탁잔액
         , shl_pnz_iu_al                                                        -- 신한라이프연금보험잔액
         , to_lbt_at                                                            -- 총부채금액
         , cre_ln_al                                                            -- 신용대출잔액
         , shb_cre_ln_al                                                        -- 신한은행신용대출잔액
         , shc_crd_lln_al                                                       -- 신한카드카드론대출잔액
         , shc_df_lln_al                                                        -- 신한카드대환론대출잔액
         , shl_cre_ln_al                                                        -- 신한라이프신용대출잔액
         , esa_ln_al                                                            -- 부동산대출잔액
         , shb_hsg_ll_ln_al                                                     -- 신한은행주택담보대출잔액
         , shb_leh_mny_ln_al                                                    -- 신한은행전세자금대출잔액
         , shb_et_esa_ln_al                                                     -- 신한은행기타부동산대출잔액
         , shl_esa_ll_ln_al                                                     -- 신한라이프부동산담보대출잔액
         , fnn_pd_ll_ln_al                                                      -- 금융상품담보대출잔액
         , shb_fnn_pd_ll_ln_al                                                  -- 신한은행금융상품담보대출잔액
         , shl_fnn_pd_ll_ln_al                                                  -- 신한라이프금융상품담보대출잔액
         , fnc_ln_al                                                            -- 오토금융대출잔액
         , shc_fna_ncr_ln_al                                                    -- 신한카드할부금융신차대출잔액
         , shc_fna_uca_ln_al                                                    -- 신한카드할부금융중고차대출잔액
         , shc_atl_ln_al                                                        -- 신한카드오토리스대출잔액
         , shc_ltm_rntc_ln_al                                                   -- 신한카드장기렌터카대출잔액
         , shb_car_ln_al                                                        -- 신한은행자동차대출잔액
         , et_ln_al                                                             -- 기타대출잔액
         , shb_eco_ln_al                                                        -- 신한은행기업대출잔액
         , shb_psn_etk_ln_al                                                    -- 신한은행개인사업자대출잔액
         , shb_et_ln_al                                                         -- 신한은행기타대출잔액
         , shl_et_ll_ln_al                                                      -- 신한라이프기타담보대출잔액
         , to_ina                                                               -- 총소득금액
         , shb_pay_bt_at                                                        -- 신한은행급여이체금액
         , shb_pnz_bt_at                                                        -- 신한은행연금이체금액
         , to_epn_at                                                            -- 총지출금액
         , shc_cre_cl_uea                                                       -- 신한카드신용신판이용금액
         , shc_chc_uea                                                          -- 신한카드체크카드이용금액
         , shc_utb_uea                                                          -- 신한카드공과금이용금액
         , shc_cmu_rain_uea                                                     -- 신한카드통신비이용금액
         , shc_irg_uea                                                          -- 신한카드보험료이용금액
         , shc_trf_uea                                                          -- 신한카드교통이용금액
         , shc_dot_uea                                                          -- 신한카드외식이용금액
         , shc_car_oln_uea                                                      -- 신한카드자동차주유이용금액
         , shc_cnvs_uea                                                         -- 신한카드편의점이용금액
         , shc_byu_hlt_uea                                                      -- 신한카드미용건강이용금액
         , shc_dpr_uea                                                          -- 신한카드백화점이용금액
         , shc_bkry_uea                                                         -- 신한카드제과이용금액
         , shc_hspt_phmc_uea                                                    -- 신한카드병원약국이용금액
         , gpm_irg_at                                                           -- 납입보험료금액
         , mrp_pd_pss_cln_cn                                                    -- 입출금상품보유고객수
         , sai_pd_pss_cln_cn                                                    -- 예적금상품보유고객수
         , ln_pd_pss_cln_cn                                                     -- 대출상품보유고객수
         , ivs_pd_pss_cln_cn                                                    -- 투자상품보유고객수
         , pnz_pd_pss_cln_cn                                                    -- 연금상품보유고객수
         , iu_pd_pss_cln_cn                                                     -- 보험상품보유고객수
         , crd_pd_pss_cln_cn                                                    -- 카드상품보유고객수
         , to_mct_ct                                                            -- 총가맹점건수
         , to_mct_saa                                                           -- 총가맹점매출금액
         , to_mct_ue_ct                                                         -- 총가맹점이용건수
         , shc_dot_mct_saa                                                      -- 신한카드외식가맹점매출금액
         , shc_car_oln_mct_saa                                                  -- 신한카드자동차주유가맹점매출금액
         , shc_cnvs_mct_saa                                                     -- 신한카드편의점가맹점매출금액
         , shc_byu_hlt_mct_saa                                                  -- 신한카드미용건강가맹점매출금액
         , shc_dpr_mct_saa                                                      -- 신한카드백화점가맹점매출금액
         , shc_bkry_mct_saa                                                     -- 신한카드제과가맹점매출금액
         , shc_hspt_phmc_mct_saa                                                -- 신한카드병원약국가맹점매출금액
    )
    select '{date_cd('P_TA_YM')}'                      as ta_ym                 -- 기준년월
         , nvl(t10.hm_cou_gds_apb_cd, ' ')             as hm_cou_gds_apb_cd     -- 자택법정GDS동코드
         , current_timestamp AT TIME ZONE 'Asia/Seoul' as aws_ld_dt             -- AWS적재일시
         , nvl(sum(t10.wl_cln_cn            ), 0)      as wl_cln_cn             -- 전체고객수
         , nvl(sum(t10.mal_cln_cn           ), 0)      as mal_cln_cn            -- 남성고객수
         , nvl(sum(t10.fme_cln_cn           ), 0)      as fme_cln_cn            -- 여성고객수
         , nvl(sum(t10.ag10_cln_cn          ), 0)      as ag10_cln_cn           -- 10대고객수
         , nvl(sum(t10.ag20_cln_cn          ), 0)      as ag20_cln_cn           -- 20대고객수
         , nvl(sum(t10.ag30_cln_cn          ), 0)      as ag30_cln_cn           -- 30대고객수
         , nvl(sum(t10.ag40_cln_cn          ), 0)      as ag40_cln_cn           -- 40대고객수
         , nvl(sum(t10.ag50_cln_cn          ), 0)      as ag50_cln_cn           -- 50대고객수
         , nvl(sum(t10.ag60_cln_cn          ), 0)      as ag60_cln_cn           -- 60대고객수
         , nvl(sum(t10.ag70_ab_cln_cn       ), 0)      as ag70_ab_cln_cn        -- 70대이상고객수
         , nvl(sum(t10.psn_etk_cln_cn       ), 0)      as psn_etk_cln_cn        -- 개인사업자고객수
         , nvl(sum(t10.shb_cln_cn           ), 0)      as shb_cln_cn            -- 신한은행고객수
         , nvl(sum(t10.shc_cln_cn           ), 0)      as shc_cln_cn            -- 신한카드고객수
         , nvl(sum(t10.shi_cln_cn           ), 0)      as shi_cln_cn            -- 신한금융투자고객수
         , nvl(sum(t10.shl_cln_cn           ), 0)      as shl_cln_cn            -- 신한라이프고객수
         , nvl(sum(t10.shb_atv_cln_cn       ), 0)      as shb_atv_cln_cn        -- 신한은행활동고객수
         , nvl(sum(t10.shc_atv_cln_cn       ), 0)      as shc_atv_cln_cn        -- 신한카드활동고객수
         , nvl(sum(t10.shi_atv_cln_cn       ), 0)      as shi_atv_cln_cn        -- 신한금융투자활동고객수
         , nvl(sum(t10.shl_atv_cln_cn       ), 0)      as shl_atv_cln_cn        -- 신한라이프활동고객수
         , nvl(sum(t10.pmr_ga_cln_cn        ), 0)      as pmr_ga_cln_cn         -- 프리미어등급고객수
         , nvl(sum(t10.ace_ga_cln_cn        ), 0)      as ace_ga_cln_cn         -- 에이스등급고객수
         , nvl(sum(t10.bst_ga_cln_cn        ), 0)      as bst_ga_cln_cn         -- 베스트등급고객수
         , nvl(sum(t10.clsi_ga_cln_cn       ), 0)      as clsi_ga_cln_cn        -- 클래식등급고객수
         , nvl(sum(t10.to_ase_at            ), 0)      as to_ase_at             -- 총자산금액
         , nvl(sum(t10.cs_ase_at            ), 0)      as cs_ase_at             -- 현금자산금액
         , nvl(sum(t10.shb_liq_al           ), 0)      as shb_liq_al            -- 신한은행유동성잔액
         , nvl(sum(t10.shb_sav_al           ), 0)      as shb_sav_al            -- 신한은행예금잔액
         , nvl(sum(t10.shb_issv_al          ), 0)      as shb_issv_al           -- 신한은행적금잔액
         , nvl(sum(t10.ivs_ase_at           ), 0)      as ivs_ase_at            -- 투자자산금액
         , nvl(sum(t10.shb_trt_al           ), 0)      as shb_trt_al            -- 신한은행신탁잔액
         , nvl(sum(t10.shb_fud_al           ), 0)      as shb_fud_al            -- 신한은행펀드잔액
         , nvl(sum(t10.shi_to_ase_at        ), 0)      as shi_to_ase_at         -- 신한금융투자총자산금액
         , nvl(sum(t10.iu_ase_at            ), 0)      as iu_ase_at             -- 보험자산금액
         , nvl(sum(t10.pnz_ase_at           ), 0)      as pnz_ase_at            -- 연금자산금액
         , nvl(sum(t10.shb_rtr_pnz_al       ), 0)      as shb_rtr_pnz_al        -- 신한은행퇴직연금잔액
         , nvl(sum(t10.shb_pnz_trt_al       ), 0)      as shb_pnz_trt_al        -- 신한은행연금신탁잔액
         , nvl(sum(t10.shl_pnz_iu_al        ), 0)      as shl_pnz_iu_al         -- 신한라이프연금보험잔액
         , nvl(sum(t10.to_lbt_at            ), 0)      as to_lbt_at             -- 총부채금액
         , nvl(sum(t10.cre_ln_al            ), 0)      as cre_ln_al             -- 신용대출잔액
         , nvl(sum(t10.shb_cre_ln_al        ), 0)      as shb_cre_ln_al         -- 신한은행신용대출잔액
         , nvl(sum(t10.shc_crd_lln_al       ), 0)      as shc_crd_lln_al        -- 신한카드카드론대출잔액
         , nvl(sum(t10.shc_df_lln_al        ), 0)      as shc_df_lln_al         -- 신한카드대환론대출잔액
         , nvl(sum(t10.shl_cre_ln_al        ), 0)      as shl_cre_ln_al         -- 신한라이프신용대출잔액
         , nvl(sum(t10.esa_ln_al            ), 0)      as esa_ln_al             -- 부동산대출잔액
         , nvl(sum(t10.shb_hsg_ll_ln_al     ), 0)      as shb_hsg_ll_ln_al      -- 신한은행주택담보대출잔액
         , nvl(sum(t10.shb_leh_mny_ln_al    ), 0)      as shb_leh_mny_ln_al     -- 신한은행전세자금대출잔액
         , nvl(sum(t10.shb_et_esa_ln_al     ), 0)      as shb_et_esa_ln_al      -- 신한은행기타부동산대출잔액
         , nvl(sum(t10.shl_esa_ll_ln_al     ), 0)      as shl_esa_ll_ln_al      -- 신한라이프부동산담보대출잔액
         , nvl(sum(t10.fnn_pd_ll_ln_al      ), 0)      as fnn_pd_ll_ln_al       -- 금융상품담보대출잔액
         , nvl(sum(t10.shb_fnn_pd_ll_ln_al  ), 0)      as shb_fnn_pd_ll_ln_al   -- 신한은행금융상품담보대출잔액
         , nvl(sum(t10.shl_fnn_pd_ll_ln_al  ), 0)      as shl_fnn_pd_ll_ln_al   -- 신한라이프금융상품담보대출잔액
         , nvl(sum(t10.fnc_ln_al            ), 0)      as fnc_ln_al             -- 오토금융대출잔액
         , nvl(sum(t10.shc_fna_ncr_ln_al    ), 0)      as shc_fna_ncr_ln_al     -- 신한카드할부금융신차대출잔액
         , nvl(sum(t10.shc_fna_uca_ln_al    ), 0)      as shc_fna_uca_ln_al     -- 신한카드할부금융중고차대출잔액
         , nvl(sum(t10.shc_atl_ln_al        ), 0)      as shc_atl_ln_al         -- 신한카드오토리스대출잔액
         , nvl(sum(t10.shc_ltm_rntc_ln_al   ), 0)      as shc_ltm_rntc_ln_al    -- 신한카드장기렌터카대출잔액
         , nvl(sum(t10.shb_car_ln_al        ), 0)      as shb_car_ln_al         -- 신한은행자동차대출잔액
         , nvl(sum(t10.et_ln_al             ), 0)      as et_ln_al              -- 기타대출잔액
         , nvl(sum(t10.shb_eco_ln_al        ), 0)      as shb_eco_ln_al         -- 신한은행기업대출잔액
         , nvl(sum(t10.shb_psn_etk_ln_al    ), 0)      as shb_psn_etk_ln_al     -- 신한은행개인사업자대출잔액
         , nvl(sum(t10.shb_et_ln_al         ), 0)      as shb_et_ln_al          -- 신한은행기타대출잔액
         , nvl(sum(t10.shl_et_ll_ln_al      ), 0)      as shl_et_ll_ln_al       -- 신한라이프기타담보대출잔액
         , nvl(sum(t10.to_ina               ), 0)      as to_ina                -- 총소득금액
         , nvl(sum(t10.shb_pay_bt_at        ), 0)      as shb_pay_bt_at         -- 신한은행급여이체금액
         , nvl(sum(t10.shb_pnz_bt_at        ), 0)      as shb_pnz_bt_at         -- 신한은행연금이체금액
         , nvl(sum(t10.to_epn_at            ), 0)      as to_epn_at             -- 총지출금액
         , nvl(sum(t10.shc_cre_cl_uea       ), 0)      as shc_cre_cl_uea        -- 신한카드신용신판이용금액
         , nvl(sum(t10.shc_chc_uea          ), 0)      as shc_chc_uea           -- 신한카드체크카드이용금액
         , nvl(sum(t10.shc_utb_uea          ), 0)      as shc_utb_uea           -- 신한카드공과금이용금액
         , nvl(sum(t10.shc_cmu_rain_uea     ), 0)      as shc_cmu_rain_uea      -- 신한카드통신비이용금액
         , nvl(sum(t10.shc_irg_uea          ), 0)      as shc_irg_uea           -- 신한카드보험료이용금액
         , nvl(sum(t10.shc_trf_uea          ), 0)      as shc_trf_uea           -- 신한카드교통이용금액
         , nvl(sum(t10.shc_dot_uea          ), 0)      as shc_dot_uea           -- 신한카드외식이용금액
         , nvl(sum(t10.shc_car_oln_uea      ), 0)      as shc_car_oln_uea       -- 신한카드자동차주유이용금액
         , nvl(sum(t10.shc_cnvs_uea         ), 0)      as shc_cnvs_uea          -- 신한카드편의점이용금액
         , nvl(sum(t10.shc_byu_hlt_uea      ), 0)      as shc_byu_hlt_uea       -- 신한카드미용건강이용금액
         , nvl(sum(t10.shc_dpr_uea          ), 0)      as shc_dpr_uea           -- 신한카드백화점이용금액
         , nvl(sum(t10.shc_bkry_uea         ), 0)      as shc_bkry_uea          -- 신한카드제과이용금액
         , nvl(sum(t10.shc_hspt_phmc_uea    ), 0)      as shc_hspt_phmc_uea     -- 신한카드병원약국이용금액
         , nvl(sum(t10.gpm_irg_at           ), 0)      as gpm_irg_at            -- 납입보험료금액
         , nvl(sum(t10.mrp_pd_pss_cln_cn    ), 0)      as mrp_pd_pss_cln_cn     -- 입출금상품보유고객수
         , nvl(sum(t10.sai_pd_pss_cln_cn    ), 0)      as sai_pd_pss_cln_cn     -- 예적금상품보유고객수
         , nvl(sum(t10.ln_pd_pss_cln_cn     ), 0)      as ln_pd_pss_cln_cn      -- 대출상품보유고객수
         , nvl(sum(t10.ivs_pd_pss_cln_cn    ), 0)      as ivs_pd_pss_cln_cn     -- 투자상품보유고객수
         , nvl(sum(t10.pnz_pd_pss_cln_cn    ), 0)      as pnz_pd_pss_cln_cn     -- 연금상품보유고객수
         , nvl(sum(t10.iu_pd_pss_cln_cn     ), 0)      as iu_pd_pss_cln_cn      -- 보험상품보유고객수
         , nvl(sum(t10.crd_pd_pss_cln_cn    ), 0)      as crd_pd_pss_cln_cn     -- 카드상품보유고객수
         , nvl(sum(t10.to_mct_ct            ), 0)      as to_mct_ct             -- 총가맹점건수
         , nvl(sum(t10.to_mct_saa           ), 0)      as to_mct_saa            -- 총가맹점매출금액
         , nvl(sum(t10.to_mct_ue_ct         ), 0)      as to_mct_ue_ct          -- 총가맹점이용건수
         , nvl(sum(t10.shc_dot_mct_saa      ), 0)      as shc_dot_mct_saa       -- 신한카드외식가맹점매출금액
         , nvl(sum(t10.shc_car_oln_mct_saa  ), 0)      as shc_car_oln_mct_saa   -- 신한카드자동차주유가맹점매출금액
         , nvl(sum(t10.shc_cnvs_mct_saa     ), 0)      as shc_cnvs_mct_saa      -- 신한카드편의점가맹점매출금액
         , nvl(sum(t10.shc_byu_hlt_mct_saa  ), 0)      as shc_byu_hlt_mct_saa   -- 신한카드미용건강가맹점매출금액
         , nvl(sum(t10.shc_dpr_mct_saa      ), 0)      as shc_dpr_mct_saa       -- 신한카드백화점가맹점매출금액
         , nvl(sum(t10.shc_bkry_mct_saa     ), 0)      as shc_bkry_mct_saa      -- 신한카드제과가맹점매출금액
         , nvl(sum(t10.shc_hspt_phmc_mct_saa), 0)      as shc_hspt_phmc_mct_saa -- 신한카드병원약국가맹점매출금액
      from tmp_sh2.shdmsti003_tmp01              t10                            -- STI_월GIS법정동금융통계집계_TMP01
     where t10.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
       and trim(t10.hm_cou_gds_apb_cd) is not null                              -- 자택법정GDS동코드
     group by
           nvl(t10.hm_cou_gds_apb_cd , ' ')                                     -- 자택법정GDS동코드
"""


"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1, insert_sql_for_tmp_2]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmsti003_tmp99', 'pk': ['ta_ym', 'hm_cou_gds_apb_cd']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmsti003                                                  -- STI_월GIS법정동금융통계집계
     where ta_ym = '{date_cd('P_TA_YM')}'                                       -- 기준년월
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shdmsti003                                                  -- STI_월GIS법정동금융통계집계
    (
           ta_ym                                                                -- 기준년월
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , aws_ld_dt                                                            -- aws적재일시
         , wl_cln_cn                                                            -- 전체고객수
         , mal_cln_cn                                                           -- 남성고객수
         , fme_cln_cn                                                           -- 여성고객수
         , ag10_cln_cn                                                          -- 10대고객수
         , ag20_cln_cn                                                          -- 20대고객수
         , ag30_cln_cn                                                          -- 30대고객수
         , ag40_cln_cn                                                          -- 40대고객수
         , ag50_cln_cn                                                          -- 50대고객수
         , ag60_cln_cn                                                          -- 60대고객수
         , ag70_ab_cln_cn                                                       -- 70대이상고객수
         , psn_etk_cln_cn	                                                  -- 개인사업자고객수
         , shb_cln_cn                                                           -- 신한은행고객수
         , shc_cln_cn                                                           -- 신한카드고객수
         , shi_cln_cn                                                           -- 신한금융투자고객수
         , shl_cln_cn                                                           -- 신한라이프고객수
         , shb_atv_cln_cn                                                       -- 신한은행활동고객수
         , shc_atv_cln_cn                                                       -- 신한카드활동고객수
         , shi_atv_cln_cn                                                       -- 신한금융투자활동고객수
         , shl_atv_cln_cn                                                       -- 신한라이프활동고객수
         , pmr_ga_cln_cn                                                        -- 프리미어등급고객수
         , ace_ga_cln_cn                                                        -- 에이스등급고객수
         , bst_ga_cln_cn                                                        -- 베스트등급고객수
         , clsi_ga_cln_cn                                                       -- 클래식등급고객수
         , to_ase_at                                                            -- 총자산금액
         , cs_ase_at                                                            -- 현금자산금액
         , shb_liq_al                                                           -- 신한은행유동성잔액
         , shb_sav_al                                                           -- 신한은행예금잔액
         , shb_issv_al                                                          -- 신한은행적금잔액
         , ivs_ase_at                                                           -- 투자자산금액
         , shb_trt_al                                                           -- 신한은행신탁잔액
         , shb_fud_al                                                           -- 신한은행펀드잔액
         , shi_to_ase_at                                                        -- 신한금융투자총자산금액
         , iu_ase_at                                                            -- 보험자산금액
         , pnz_ase_at                                                           -- 연금자산금액
         , shb_rtr_pnz_al                                                       -- 신한은행퇴직연금잔액
         , shb_pnz_trt_al                                                       -- 신한은행연금신탁잔액
         , shl_pnz_iu_al                                                        -- 신한라이프연금보험잔액
         , to_lbt_at                                                            -- 총부채금액
         , cre_ln_al                                                            -- 신용대출잔액
         , shb_cre_ln_al                                                        -- 신한은행신용대출잔액
         , shc_crd_lln_al                                                       -- 신한카드카드론대출잔액
         , shc_df_lln_al                                                        -- 신한카드대환론대출잔액
         , shl_cre_ln_al                                                        -- 신한라이프신용대출잔액
         , esa_ln_al                                                            -- 부동산대출잔액
         , shb_hsg_ll_ln_al                                                     -- 신한은행주택담보대출잔액
         , shb_leh_mny_ln_al                                                    -- 신한은행전세자금대출잔액
         , shb_et_esa_ln_al                                                     -- 신한은행기타부동산대출잔액
         , shl_esa_ll_ln_al                                                     -- 신한라이프부동산담보대출잔액
         , fnn_pd_ll_ln_al                                                      -- 금융상품담보대출잔액
         , shb_fnn_pd_ll_ln_al                                                  -- 신한은행금융상품담보대출잔액
         , shl_fnn_pd_ll_ln_al                                                  -- 신한라이프금융상품담보대출잔액
         , fnc_ln_al                                                            -- 오토금융대출잔액
         , shc_fna_ncr_ln_al                                                    -- 신한카드할부금융신차대출잔액
         , shc_fna_uca_ln_al                                                    -- 신한카드할부금융중고차대출잔액
         , shc_atl_ln_al                                                        -- 신한카드오토리스대출잔액
         , shc_ltm_rntc_ln_al                                                   -- 신한카드장기렌터카대출잔액
         , shb_car_ln_al                                                        -- 신한은행자동차대출잔액
         , et_ln_al                                                             -- 기타대출잔액
         , shb_eco_ln_al                                                        -- 신한은행기업대출잔액
         , shb_psn_etk_ln_al                                                    -- 신한은행개인사업자대출잔액
         , shb_et_ln_al                                                         -- 신한은행기타대출잔액
         , shl_et_ll_ln_al                                                      -- 신한라이프기타담보대출잔액
         , to_ina                                                               -- 총소득금액
         , shb_pay_bt_at                                                        -- 신한은행급여이체금액
         , shb_pnz_bt_at                                                        -- 신한은행연금이체금액
         , to_epn_at                                                            -- 총지출금액
         , shc_cre_cl_uea                                                       -- 신한카드신용신판이용금액
         , shc_chc_uea                                                          -- 신한카드체크카드이용금액
         , shc_utb_uea                                                          -- 신한카드공과금이용금액
         , shc_cmu_rain_uea                                                     -- 신한카드통신비이용금액
         , shc_irg_uea                                                          -- 신한카드보험료이용금액
         , shc_trf_uea                                                          -- 신한카드교통이용금액
         , shc_dot_uea                                                          -- 신한카드외식이용금액
         , shc_car_oln_uea                                                      -- 신한카드자동차주유이용금액
         , shc_cnvs_uea                                                         -- 신한카드편의점이용금액
         , shc_byu_hlt_uea                                                      -- 신한카드미용건강이용금액
         , shc_dpr_uea                                                          -- 신한카드백화점이용금액
         , shc_bkry_uea                                                         -- 신한카드제과이용금액
         , shc_hspt_phmc_uea                                                    -- 신한카드병원약국이용금액
         , gpm_irg_at                                                           -- 납입보험료금액
         , mrp_pd_pss_cln_cn                                                    -- 입출금상품보유고객수
         , sai_pd_pss_cln_cn                                                    -- 예적금상품보유고객수
         , ln_pd_pss_cln_cn                                                     -- 대출상품보유고객수
         , ivs_pd_pss_cln_cn                                                    -- 투자상품보유고객수
         , pnz_pd_pss_cln_cn                                                    -- 연금상품보유고객수
         , iu_pd_pss_cln_cn                                                     -- 보험상품보유고객수
         , crd_pd_pss_cln_cn                                                    -- 카드상품보유고객수
         , to_mct_ct                                                            -- 총가맹점건수
         , to_mct_saa                                                           -- 총가맹점매출금액
         , to_mct_ue_ct                                                         -- 총가맹점이용건수
         , shc_dot_mct_saa                                                      -- 신한카드외식가맹점매출금액
         , shc_car_oln_mct_saa                                                  -- 신한카드자동차주유가맹점매출금액
         , shc_cnvs_mct_saa                                                     -- 신한카드편의점가맹점매출금액
         , shc_byu_hlt_mct_saa                                                  -- 신한카드미용건강가맹점매출금액
         , shc_dpr_mct_saa                                                      -- 신한카드백화점가맹점매출금액
         , shc_bkry_mct_saa                                                     -- 신한카드제과가맹점매출금액
         , shc_hspt_phmc_mct_saa                                                -- 신한카드병원약국가맹점매출금액
    )
    select ta_ym                                                                -- 기준년월
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , wl_cln_cn                                                            -- 전체고객수
         , mal_cln_cn                                                           -- 남성고객수
         , fme_cln_cn                                                           -- 여성고객수
         , ag10_cln_cn                                                          -- 10대고객수
         , ag20_cln_cn                                                          -- 20대고객수
         , ag30_cln_cn                                                          -- 30대고객수
         , ag40_cln_cn                                                          -- 40대고객수
         , ag50_cln_cn                                                          -- 50대고객수
         , ag60_cln_cn                                                          -- 60대고객수
         , ag70_ab_cln_cn                                                       -- 70대이상고객수
         , psn_etk_cln_cn	                                                  -- 개인사업자고객수
         , shb_cln_cn                                                           -- 신한은행고객수
         , shc_cln_cn                                                           -- 신한카드고객수
         , shi_cln_cn                                                           -- 신한금융투자고객수
         , shl_cln_cn                                                           -- 신한라이프고객수
         , shb_atv_cln_cn                                                       -- 신한은행활동고객수
         , shc_atv_cln_cn                                                       -- 신한카드활동고객수
         , shi_atv_cln_cn                                                       -- 신한금융투자활동고객수
         , shl_atv_cln_cn                                                       -- 신한라이프활동고객수
         , pmr_ga_cln_cn                                                        -- 프리미어등급고객수
         , ace_ga_cln_cn                                                        -- 에이스등급고객수
         , bst_ga_cln_cn                                                        -- 베스트등급고객수
         , clsi_ga_cln_cn                                                       -- 클래식등급고객수
         , to_ase_at                                                            -- 총자산금액
         , cs_ase_at                                                            -- 현금자산금액
         , shb_liq_al                                                           -- 신한은행유동성잔액
         , shb_sav_al                                                           -- 신한은행예금잔액
         , shb_issv_al                                                          -- 신한은행적금잔액
         , ivs_ase_at                                                           -- 투자자산금액
         , shb_trt_al                                                           -- 신한은행신탁잔액
         , shb_fud_al                                                           -- 신한은행펀드잔액
         , shi_to_ase_at                                                        -- 신한금융투자총자산금액
         , iu_ase_at                                                            -- 보험자산금액
         , pnz_ase_at                                                           -- 연금자산금액
         , shb_rtr_pnz_al                                                       -- 신한은행퇴직연금잔액
         , shb_pnz_trt_al                                                       -- 신한은행연금신탁잔액
         , shl_pnz_iu_al                                                        -- 신한라이프연금보험잔액
         , to_lbt_at                                                            -- 총부채금액
         , cre_ln_al                                                            -- 신용대출잔액
         , shb_cre_ln_al                                                        -- 신한은행신용대출잔액
         , shc_crd_lln_al                                                       -- 신한카드카드론대출잔액
         , shc_df_lln_al                                                        -- 신한카드대환론대출잔액
         , shl_cre_ln_al                                                        -- 신한라이프신용대출잔액
         , esa_ln_al                                                            -- 부동산대출잔액
         , shb_hsg_ll_ln_al                                                     -- 신한은행주택담보대출잔액
         , shb_leh_mny_ln_al                                                    -- 신한은행전세자금대출잔액
         , shb_et_esa_ln_al                                                     -- 신한은행기타부동산대출잔액
         , shl_esa_ll_ln_al                                                     -- 신한라이프부동산담보대출잔액
         , fnn_pd_ll_ln_al                                                      -- 금융상품담보대출잔액
         , shb_fnn_pd_ll_ln_al                                                  -- 신한은행금융상품담보대출잔액
         , shl_fnn_pd_ll_ln_al                                                  -- 신한라이프금융상품담보대출잔액
         , fnc_ln_al                                                            -- 오토금융대출잔액
         , shc_fna_ncr_ln_al                                                    -- 신한카드할부금융신차대출잔액
         , shc_fna_uca_ln_al                                                    -- 신한카드할부금융중고차대출잔액
         , shc_atl_ln_al                                                        -- 신한카드오토리스대출잔액
         , shc_ltm_rntc_ln_al                                                   -- 신한카드장기렌터카대출잔액
         , shb_car_ln_al                                                        -- 신한은행자동차대출잔액
         , et_ln_al                                                             -- 기타대출잔액
         , shb_eco_ln_al                                                        -- 신한은행기업대출잔액
         , shb_psn_etk_ln_al                                                    -- 신한은행개인사업자대출잔액
         , shb_et_ln_al                                                         -- 신한은행기타대출잔액
         , shl_et_ll_ln_al                                                      -- 신한라이프기타담보대출잔액
         , to_ina                                                               -- 총소득금액
         , shb_pay_bt_at                                                        -- 신한은행급여이체금액
         , shb_pnz_bt_at                                                        -- 신한은행연금이체금액
         , to_epn_at                                                            -- 총지출금액
         , shc_cre_cl_uea                                                       -- 신한카드신용신판이용금액
         , shc_chc_uea                                                          -- 신한카드체크카드이용금액
         , shc_utb_uea                                                          -- 신한카드공과금이용금액
         , shc_cmu_rain_uea                                                     -- 신한카드통신비이용금액
         , shc_irg_uea                                                          -- 신한카드보험료이용금액
         , shc_trf_uea                                                          -- 신한카드교통이용금액
         , shc_dot_uea                                                          -- 신한카드외식이용금액
         , shc_car_oln_uea                                                      -- 신한카드자동차주유이용금액
         , shc_cnvs_uea                                                         -- 신한카드편의점이용금액
         , shc_byu_hlt_uea                                                      -- 신한카드미용건강이용금액
         , shc_dpr_uea                                                          -- 신한카드백화점이용금액
         , shc_bkry_uea                                                         -- 신한카드제과이용금액
         , shc_hspt_phmc_uea                                                    -- 신한카드병원약국이용금액
         , gpm_irg_at                                                           -- 납입보험료금액
         , mrp_pd_pss_cln_cn                                                    -- 입출금상품보유고객수
         , sai_pd_pss_cln_cn                                                    -- 예적금상품보유고객수
         , ln_pd_pss_cln_cn                                                     -- 대출상품보유고객수
         , ivs_pd_pss_cln_cn                                                    -- 투자상품보유고객수
         , pnz_pd_pss_cln_cn                                                    -- 연금상품보유고객수
         , iu_pd_pss_cln_cn                                                     -- 보험상품보유고객수
         , crd_pd_pss_cln_cn                                                    -- 카드상품보유고객수
         , to_mct_ct                                                            -- 총가맹점건수
         , to_mct_saa                                                           -- 총가맹점매출금액
         , to_mct_ue_ct                                                         -- 총가맹점이용건수
         , shc_dot_mct_saa                                                      -- 신한카드외식가맹점매출금액
         , shc_car_oln_mct_saa                                                  -- 신한카드자동차주유가맹점매출금액
         , shc_cnvs_mct_saa                                                     -- 신한카드편의점가맹점매출금액
         , shc_byu_hlt_mct_saa                                                  -- 신한카드미용건강가맹점매출금액
         , shc_dpr_mct_saa                                                      -- 신한카드백화점가맹점매출금액
         , shc_bkry_mct_saa                                                     -- 신한카드제과가맹점매출금액
         , shc_hspt_phmc_mct_saa                                                -- 신한카드병원약국가맹점매출금액
      from tmp_sh2.shdmsti003_tmp99                                             -- STI_월GIS법정동금융통계집계_TMP99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_99 = RedshiftQueryOperator(
        task_id='003_tmp_load_task_99',
        execute_query=insert_sql_for_tmp_3,
    )

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='004_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='005_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='006_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_99 >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end