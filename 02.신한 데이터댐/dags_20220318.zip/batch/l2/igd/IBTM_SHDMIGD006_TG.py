# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "노재홍"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["노재홍"]
__version__    = "1.0"
__maintainer__ = "노재홍"
__email__      = ""
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 한글 테이블명
  - TMP_SH1 테이블명
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMIGD006_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L2통합) IGD_월고객거래실적 배치프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shdmigd006_tmp99']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""

############################################################################################
# TO_DO
############################################################################################
# 속도 느리면 tmp01 ~ 04 로 처리후 group by 처리
# 라이프의 납입보험료를 카드로 낼경우 금액이 오버 될수있다
# 납입보험료금액에서 제휴보험유지계약CMIP금액(afl_iu_mtn_are_cmip)은 제외가 맞는지 확인
############################################################################################

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmigd006_tmp99                                        -- IGD_월고객거래실적_TMP99
    (
           ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , aws_ld_dt                                                            -- AWS적재일시
         , to_ase_at                                                            -- 총자산금액
         , cs_ase_at                                                            -- 현금자산금액
         , ivs_ase_at                                                           -- 투자자산금액
         , iu_ase_at                                                            -- 보험자산금액
         , pnz_ase_at                                                           -- 연금자산금액
         , to_lbt_at                                                            -- 총부채금액
         , cre_ln_al                                                            -- 신용대출잔액
         , esa_ln_al                                                            -- 부동산대출잔액
         , fnn_pd_ll_ln_al                                                      -- 금융상품담보대출잔액
         , fnc_ln_al                                                            -- 오토금융대출잔액
         , et_ln_al                                                             -- 기타대출잔액
         , to_ina                                                               -- 총소득금액
         , to_epn_at                                                            -- 총지출금액
         , cre_cl_uea                                                           -- 신용신판이용금액
         , chc_uea                                                              -- 체크카드이용금액
         , gpm_irg_at                                                           -- 납입보험료금액
    )
    select '{date_cd('P_TA_YM')}'                           as ta_ym            -- 기준년월
         , t10.shmdn                                                            -- 그룹md번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'      as aws_ld_dt        -- AWS적재일시
         -- 총자산금액 = 현금자산금액 + 투자자산금액 + 보험자산금액 + 연금자산금액
         , nvl(sum(cs_ase_at      ), 0)
         + nvl(sum(ivs_ase_at     ), 0)
         + nvl(sum(iu_ase_at      ), 0)
         + nvl(sum(pnz_ase_at     ), 0)                     as to_ase_at        -- 총자산금액
         , nvl(sum(cs_ase_at      ), 0)                     as cs_ase_at        -- 현금자산금액
         , nvl(sum(ivs_ase_at     ), 0)                     as ivs_ase_at       -- 투자자산금액
         , nvl(sum(iu_ase_at      ), 0)                     as iu_ase_at        -- 보험자산금액
         , nvl(sum(pnz_ase_at     ), 0)                     as pnz_ase_at       -- 연금자산금액
         -- 총부채금액 = 신용대출잔액 + 부동산대출잔액 + 금융상품담보대출잔액 + 오토금융대출잔액 + 기타대출잔액
         , nvl(sum(cre_ln_al      ), 0)
         + nvl(sum(esa_ln_al      ), 0)
         + nvl(sum(fnn_pd_ll_ln_al), 0)
         + nvl(sum(fnc_ln_al      ), 0)
         + nvl(sum(et_ln_al       ), 0)                     as to_lbt_at        -- 총부채금액
         , nvl(sum(cre_ln_al      ), 0)                     as cre_ln_al        -- 신용대출잔액
         , nvl(sum(esa_ln_al      ), 0)                     as esa_ln_al        -- 부동산대출잔액
         , nvl(sum(fnn_pd_ll_ln_al), 0)                     as fnn_pd_ll_ln_al  -- 금융상품담보대출잔액
         , nvl(sum(fnc_ln_al      ), 0)                     as fnc_ln_al        -- 오토금융대출잔액
         , nvl(sum(et_ln_al       ), 0)                     as et_ln_al         -- 기타대출잔액
         , nvl(sum(to_ina         ), 0)                     as to_ina           -- 총소득금액
         , nvl(sum(to_epn_at      ), 0)                     as to_epn_at        -- 총지출금액
         , nvl(sum(cre_cl_uea     ), 0)                     as cre_cl_uea       -- 신용신판이용금액
         , nvl(sum(chc_uea        ), 0)                     as chc_uea          -- 체크카드이용금액
         , nvl(sum(gpm_irg_at     ), 0)                     as gpm_irg_at       -- 납입보험료금액
      from
           (
               select t20.shmdn                                                 -- 그룹md번호
                    , nvl(t20.liq_al , 0)
                    + nvl(t20.sav_al , 0)
                    + nvl(t20.issv_al, 0)                   as cs_ase_at        -- 현금자산금액(유동성잔액+예금잔액+적금잔액)
                    , nvl(t20.trt_al , 0)
                    + nvl(t20.fud_al , 0)                   as ivs_ase_at       -- 투자자산금액(신탁잔액+펀드잔액)
                    , 0                                     as iu_ase_at        -- 보험자산금액
                    , nvl(t20.rtr_pnz_al , 0)
                    + nvl(t20.pnz_trt_al , 0)               as pnz_ase_at       -- 연금자산금액(퇴직연금잔액+연금신탁잔액)
                    , nvl(t20.cre_ln_al  , 0)               as cre_ln_al        -- 신용대출잔액(신용대출잔액)
                    , nvl(t20.hsg_ll_ln_al , 0)
                    + nvl(t20.leh_mny_ln_al , 0)
                    + nvl(t20.et_esa_ln_al , 0)             as esa_ln_al        -- 부동산대출잔액(주택담보대출잔액+전세자금대출잔액+기타부동산대출잔액)
                    , nvl(t20.fnn_pd_ll_ln_al , 0)          as fnn_pd_ll_ln_al  -- 금융상품담보대출잔액
                    , nvl(t20.car_ln_al , 0)                as fnc_ln_al        -- 오토금융대출잔액(자동차대출잔액)
                    , nvl(t20.eco_ln_al , 0)
                    + nvl(t20.psn_etk_ln_al , 0)
                    + nvl(t20.et_ln_al , 0)                 as et_ln_al         -- 기타대출잔액(기업대출잔액+개인사업자대출잔액+기타대출잔액)
                    , nvl(t20.to_ina , 0)                   as to_ina           -- 총소득금액
                    , 0                                     as to_epn_at        -- 총지출금액
                    , 0                                     as cre_cl_uea       -- 신용신판이용금액
                    , 0                                     as chc_uea          -- 체크카드이용금액
                    , 0                                     as gpm_irg_at       -- 납입보험료금액
                 from sh2.shdmigd007             t20                            -- IGD_월고객거래실적_은행
                where t20.ta_ym  = '{date_cd('P_TA_YM')}'                       -- 기준년월
                union all
               select t20.shmdn                                                 -- 그룹md번호
                    , 0                                     as cs_ase_at        -- 현금자산금액
                    , 0                                     as ivs_ase_at       -- 투자자산금액
                    , 0                                     as iu_ase_at        -- 보험자산금액
                    , 0                                     as pnz_ase_at       -- 연금자산금액
                    , nvl(t20.crd_lln_al , 0)
                    + nvl(t20.dfl_ln_al  , 0)               as cre_ln_al        -- 신용대출잔액(카드론대출잔액+대환론대출잔액)
                    , 0                                     as esa_ln_al        -- 부동산대출잔액
                    , 0                                     as fnn_pd_ll_ln_al  -- 금융상품담보대출잔액
                    , nvl(t20.fnc_ln_al  , 0)               as fnc_ln_al        -- 오토금융대출잔액
                    , 0                                     as et_ln_al         -- 기타대출잔액
                    , 0                                     as to_ina           -- 총소득금액
                    , nvl(t20.cre_cl_uea , 0)
                    + nvl(t20.chc_uea  , 0)                 as to_epn_at        -- 총지출금액(신용신판이용금액+체크카드이용금액)
                    , nvl(t20.cre_cl_uea , 0)               as cre_cl_uea       -- 신용신판이용금액
                    , nvl(t20.chc_uea  , 0)                 as chc_uea          -- 체크카드이용금액
                    , nvl(t20.irg_uea  , 0)                 as gpm_irg_at       -- 납입보험료금액(보험료이용금액)
                 from sh2.shdmigd008             t20                            -- IGD_월고객거래실적_카드
                where t20.ta_ym  = '{date_cd('P_TA_YM')}'                       -- 기준년월
                union all
               select t20.shmdn                                                 -- 그룹md번호
                    , 0                                     as cs_ase_at        -- 현금자산금액
                    , nvl(t20.to_ase_at)                    as ivs_ase_at       -- 투자자산금액(총자산금액)
                    , 0                                     as iu_ase_at        -- 보험자산금액
                    , 0                                     as pnz_ase_at       -- 연금자산금액
                    , 0                                     as cre_ln_al        -- 신용대출잔액
                    , 0                                     as esa_ln_al        -- 부동산대출잔액
                    , 0                                     as fnn_pd_ll_ln_al  -- 금융상품담보대출잔액
                    , 0                                     as fnc_ln_al        -- 오토금융대출잔액
                    , 0                                     as et_ln_al         -- 기타대출잔액
                    , 0                                     as to_ina           -- 총소득금액
                    , 0                                     as to_epn_at        -- 총지출금액
                    , 0                                     as cre_cl_uea       -- 신용신판이용금액
                    , 0                                     as chc_uea          -- 체크카드이용금액
                    , 0                                     as gpm_irg_at       -- 납입보험료금액
                 from sh2.shdmigd009             t20                            -- IGD_월고객거래실적_금투
                where t20.ta_ym  = '{date_cd('P_TA_YM')}'                       -- 기준년월
                union all
               select t20.shmdn                                                 -- 그룹md번호
                    , 0                                     as cs_ase_at        -- 현금자산금액
                    , 0                                     as ivs_ase_at       -- 투자자산금액
                    , nvl(t20.iu_ase_at)                    as iu_ase_at        -- 보험자산금액
                    , nvl(t20.pnz_iu_al)                    as pnz_ase_at       -- 연금자산금액(연금보험잔액)
                    , nvl(t20.cre_ln_al)                    as cre_ln_al        -- 신용대출잔액(신용대출잔액)
                    , nvl(t20.esa_ll_ln_al)                 as esa_ln_al        -- 부동산대출잔액(부동산담보대출잔액)
                    , nvl(t20.iu_are_ln_al)                 as fnn_pd_ll_ln_al  -- 금융상품담보대출잔액(보험계약대출잔액)
                    , 0                                     as fnc_ln_al        -- 오토금융대출잔액
                    , nvl(t20.et_ll_ln_al)                  as et_ln_al         -- 기타대출잔액(기타담보대출잔액)
                    , 0                                     as to_ina           -- 총소득금액
                    , 0                                     as to_epn_at        -- 총지출금액
                    , 0                                     as cre_cl_uea       -- 신용신판이용금액
                    , 0                                     as chc_uea          -- 체크카드이용금액
                    -- 건강보험유지계약CMIP금액+상해보험유지계약CMIP금액+양로보험유지계약CMIP금액
                    -- 어린이보험유지계약CMIP금액+연금저축교육보험유지계약CMIP금액+종신보험유지계약CMIP금액
                    -- 종합보험유지계약CMIP금액+변액보험유지계약CMIP금액+기타보험유지계약CMIP금액
                    , nvl(t20.hlt_iu_mtn_are_cmip)         + nvl(t20.ijr_iu_mtn_are_cmip)
                    + nvl(t20.crag_iu_mtn_are_cmip)        + nvl(t20.chld_iu_mtn_are_cmip)
                    + nvl(t20.pnz_svg_edu_iu_mtn_are_cmip) + nvl(t20.wli_mtn_are_cmip)
                    + nvl(t20.ovl_iu_mtn_are_cmip)         + nvl(t20.vli_mtn_are_cmip)
                    + nvl(t20.et_iu_mtn_are_cmip)           as gpm_irg_at       -- 납입보험료금액
                 from sh2.shdmigd010             t20                            -- IGD_월고객거래실적_라이프
                where t20.ta_ym  = '{date_cd('P_TA_YM')}'                       -- 기준년월
           )                                     t10
     group by
           t10.shmdn                                                            -- 그룹md번호
"""


"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmigd006_tmp99', 'pk': ['ta_ym', 'shmdn']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmigd006                                                  -- IGD_월고객거래실적
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""

insert_sql_1 = f"""
    insert into sh2.shdmigd006                                                  -- IGD_월고객거래실적
    (
           ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , aws_ld_dt                                                            -- AWS적재일시
         , to_ase_at                                                            -- 총자산금액
         , cs_ase_at                                                            -- 현금자산금액
         , ivs_ase_at                                                           -- 투자자산금액
         , iu_ase_at                                                            -- 보험자산금액
         , pnz_ase_at                                                           -- 연금자산금액
         , to_lbt_at                                                            -- 총부채금액
         , cre_ln_al                                                            -- 신용대출잔액
         , esa_ln_al                                                            -- 부동산대출잔액
         , fnn_pd_ll_ln_al                                                      -- 금융상품담보대출잔액
         , fnc_ln_al                                                            -- 오토금융대출잔액
         , et_ln_al                                                             -- 기타대출잔액
         , to_ina                                                               -- 총소득금액
         , to_epn_at                                                            -- 총지출금액
         , cre_cl_uea                                                           -- 신용신판이용금액
         , chc_uea                                                              -- 체크카드이용금액
         , gpm_irg_at                                                           -- 납입보험료금액
    )
    select ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , to_ase_at                                                            -- 총자산금액
         , cs_ase_at                                                            -- 현금자산금액
         , ivs_ase_at                                                           -- 투자자산금액
         , iu_ase_at                                                            -- 보험자산금액
         , pnz_ase_at                                                           -- 연금자산금액
         , to_lbt_at                                                            -- 총부채금액
         , cre_ln_al                                                            -- 신용대출잔액
         , esa_ln_al                                                            -- 부동산대출잔액
         , fnn_pd_ll_ln_al                                                      -- 금융상품담보대출잔액
         , fnc_ln_al                                                            -- 오토금융대출잔액
         , et_ln_al                                                             -- 기타대출잔액
         , to_ina                                                               -- 총소득금액
         , to_epn_at                                                            -- 총지출금액
         , cre_cl_uea                                                           -- 신용신판이용금액
         , chc_uea                                                              -- 체크카드이용금액
         , gpm_irg_at                                                           -- 납입보험료금액
      from tmp_sh2.shdmigd006_tmp99                                             -- IGD_월고객거래실적_TMP99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end