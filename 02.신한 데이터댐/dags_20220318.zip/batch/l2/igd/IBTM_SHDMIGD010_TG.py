# -*- coding: utf-8 -*-

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *


__author__     = "이일주"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["이일주"]
__version__    = "1.0"
__maintainer__ = "이일주"
__email__      = "LEE1122334@xgm.co.kr"
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID  : IBTM_SHDMIGD010_TG
  - 한글 테이블명: IGD_월고객거래실적_라이프
  - tmp_sh2 테이블명: tmp_sh2.shdmigd010_tmp99
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMIGD010_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = 'IGD_월고객거래실적_라이프'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

##날짜변수 사용관련 
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) tmp_sh2 테이블명 (TRUNCATE 대상)
"""
tmp_sh2_table = ['shdmigd010_tmp99','shdmigd010_tmp01','shdmigd010_tmp02']

"""
(@) tmp_sh2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmigd010_tmp01
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , iu_ase_at                              -- 보험자산금액
         , pnz_iu_al                              -- 연금보험잔액
         , iu_are_ln_al                           -- 보험계약대출잔액
         , hlt_iu_mtn_are_ct                      -- 건강보험유지계약건수
         , hlt_iu_mtn_are_cmip                    -- 건강보험유지계약CMIP금액
         , hlt_iu_ivl_are_ct                      -- 건강보험실효계약건수
         , hlt_iu_ivl_are_cmip                    -- 건강보험실효계약CMIP금액
         , hlt_iu_insm_bil_ct                     -- 건강보험보험금청구건수
         , hlt_iu_insm_bla                        -- 건강보험보험금청구금액
         , hlt_iu_et_alpy_ct                      -- 건강보험기타제지급건수
         , hlt_iu_et_alpy_at                      -- 건강보험기타제지급금액
         , hlt_iu_are_ln_ct                       -- 건강보험계약대출건수
         , hlt_iu_are_lna                         -- 건강보험계약대출금액
         , hlt_iu_are_ln_al                       -- 건강보험계약대출잔액
         , ijr_iu_mtn_are_ct                      -- 상해보험유지계약건수
         , ijr_iu_mtn_are_cmip                    -- 상해보험유지계약CMIP금액
         , ijr_iu_ivl_are_ct                      -- 상해보험실효계약건수
         , ijr_iu_ivl_are_cmip                    -- 상해보험실효계약CMIP금액
         , ijr_iu_insm_bil_ct                     -- 상해보험보험금청구건수
         , ijr_iu_insm_bla                        -- 상해보험보험금청구금액
         , ijr_iu_et_alpy_ct                      -- 상해보험기타제지급건수
         , ijr_iu_et_alpy_at                      -- 상해보험기타제지급금액
         , ijr_iu_are_ln_ct                       -- 상해보험계약대출건수
         , ijr_iu_are_lna                         -- 상해보험계약대출금액
         , ijr_iu_are_ln_al                       -- 상해보험계약대출잔액
         , crag_iu_mtn_are_ct                     -- 양로보험유지계약건수
         , crag_iu_mtn_are_cmip                   -- 양로보험유지계약CMIP금액
         , crag_iu_ivl_are_ct                     -- 양로보험실효계약건수
         , crag_iu_ivl_are_cmip                   -- 양로보험실효계약CMIP금액
         , crag_iu_insm_bil_ct                    -- 양로보험보험금청구건수
         , crag_iu_insm_bla                       -- 양로보험보험금청구금액
         , crag_iu_et_alpy_ct                     -- 양로보험기타제지급건수
         , crag_iu_et_alpy_at                     -- 양로보험기타제지급금액
         , crag_iu_are_ln_ct                      -- 양로보험계약대출건수
         , crag_iu_are_lna                        -- 양로보험계약대출금액
         , crag_iu_are_ln_al                      -- 양로보험계약대출잔액
         , chld_iu_mtn_are_ct                     -- 어린이보험유지계약건수
         , chld_iu_mtn_are_cmip                   -- 어린이보험유지계약CMIP금액
         , chld_iu_ivl_are_ct                     -- 어린이보험실효계약건수
         , chld_iu_ivl_are_cmip                   -- 어린이보험실효계약CMIP금액
         , chld_iu_insm_bil_ct                    -- 어린이보험보험금청구건수
         , chld_iu_insm_bla                       -- 어린이보험보험금청구금액
         , chld_iu_et_alpy_ct                     -- 어린이보험기타제지급건수
         , chld_iu_et_alpy_at                     -- 어린이보험기타제지급금액
         , chld_iu_are_ln_ct                      -- 어린이보험계약대출건수
         , chld_iu_are_lna                        -- 어린이보험계약대출금액
         , chld_iu_are_ln_al                      -- 어린이보험계약대출잔액
         , pnz_svg_edu_iu_mtn_are_ct              -- 연금저축교육보험유지계약건수
         , pnz_svg_edu_iu_mtn_are_cmip            -- 연금저축교육보험유지계약CMIP금액
         , pnz_svg_edu_iu_ivl_are_ct              -- 연금저축교육보험실효계약건수
         , pnz_svg_edu_iu_ivl_are_cmip            -- 연금저축교육보험실효계약CMIP금액
         , pnz_svg_edu_iu_insm_bil_ct             -- 연금저축교육보험보험금청구건수
         , pnz_svg_edu_iu_insm_bla                -- 연금저축교육보험보험금청구금액
         , pnz_svg_edu_iu_pnz_ct                  -- 연금저축교육보험연금건수
         , pnz_svg_edu_iu_pnz_at                  -- 연금저축교육보험연금금액
         , pnz_svg_edu_iu_et_alpy_ct              -- 연금저축교육보험기타제지급건수
         , pnz_svg_edu_iu_et_alpy_at              -- 연금저축교육보험기타제지급금액
         , pnz_svg_edu_iu_are_ln_ct               -- 연금저축교육보험계약대출건수
         , pnz_svg_edu_iu_are_lna                 -- 연금저축교육보험계약대출금액
         , pnz_svg_edu_iu_are_ln_al               -- 연금저축교육보험계약대출잔액
         , wli_mtn_are_ct                         -- 종신보험유지계약건수
         , wli_mtn_are_cmip                       -- 종신보험유지계약CMIP금액
         , wli_ivl_are_ct                         -- 종신보험실효계약건수
         , wli_ivl_are_cmip                       -- 종신보험실효계약CMIP금액
         , wli_insm_bil_ct                        -- 종신보험보험금청구건수
         , wli_insm_bla                           -- 종신보험보험금청구금액
         , wli_et_alpy_ct                         -- 종신보험기타제지급건수
         , wli_et_alpy_at                         -- 종신보험기타제지급금액
         , wli_are_ln_ct                          -- 종신보험계약대출건수
         , wli_are_lna                            -- 종신보험계약대출금액
         , wli_are_ln_al                          -- 종신보험계약대출잔액
         , ovl_iu_mtn_are_ct                      -- 종합보험유지계약건수
         , ovl_iu_mtn_are_cmip                    -- 종합보험유지계약CMIP금액
         , ovl_iu_ivl_are_ct                      -- 종합보험실효계약건수
         , ovl_iu_ivl_are_cmip                    -- 종합보험실효계약CMIP금액
         , ovl_iu_insm_bil_ct                     -- 종합보험보험금청구건수
         , ovl_iu_insm_bla                        -- 종합보험보험금청구금액
         , ovl_iu_et_alpy_ct                      -- 종합보험기타제지급건수
         , ovl_iu_et_alpy_at                      -- 종합보험기타제지급금액
         , ovl_iu_are_ln_ct                       -- 종합보험계약대출건수
         , ovl_iu_are_lna                         -- 종합보험계약대출금액
         , ovl_iu_are_ln_al                       -- 종합보험계약대출잔액
         , vli_mtn_are_ct                         -- 변액보험유지계약건수
         , vli_mtn_are_cmip                       -- 변액보험유지계약CMIP금액
         , vli_ivl_are_ct                         -- 변액보험실효계약건수
         , vli_ivl_are_cmip                       -- 변액보험실효계약CMIP금액
         , vli_insm_bil_ct                        -- 변액보험보험금청구건수
         , vli_insm_bla                           -- 변액보험보험금청구금액
         , vli_et_alpy_ct                         -- 변액보험기타제지급건수
         , vli_et_alpy_at                         -- 변액보험기타제지급금액
         , vli_are_ln_ct                          -- 변액보험계약대출건수
         , vli_are_lna                            -- 변액보험계약대출금액
         , vli_are_ln_al                          -- 변액보험계약대출잔액
         , et_iu_mtn_are_ct                       -- 기타보험유지계약건수
         , et_iu_mtn_are_cmip                     -- 기타보험유지계약CMIP금액
         , et_iu_ivl_are_ct                       -- 기타보험실효계약건수
         , et_iu_ivl_are_cmip                     -- 기타보험실효계약CMIP금액
         , et_iu_insm_bil_ct                      -- 기타보험보험금청구건수
         , et_iu_insm_bla                         -- 기타보험보험금청구금액
         , et_iu_et_alpy_ct                       -- 기타보험기타제지급건수
         , et_iu_et_alpy_at                       -- 기타보험기타제지급금액
         , et_iu_are_ln_ct                        -- 기타보험계약대출건수
         , et_iu_are_lna                          -- 기타보험계약대출금액
         , et_iu_are_ln_al                        -- 기타보험계약대출잔액
         , afl_iu_mtn_are_ct                      -- 제휴보험유지계약건수
         , afl_iu_mtn_are_cmip                    -- 제휴보험유지계약CMIP금액
         , afl_iu_ivl_are_ct                      -- 제휴보험실효계약건수
         , afl_iu_ivl_are_cmip                    -- 제휴보험실효계약CMIP금액
         , afl_iu_insm_bil_ct                     -- 제휴보험보험금청구건수
         , afl_iu_insm_bla                        -- 제휴보험보험금청구금액
         , afl_iu_et_alpy_ct                      -- 제휴보험기타제지급건수
         , afl_iu_et_alpy_at                      -- 제휴보험기타제지급금액
         , afl_iu_are_ln_ct                       -- 제휴보험계약대출건수
         , afl_iu_are_lna                         -- 제휴보험계약대출금액
         , afl_iu_are_ln_al                       -- 제휴보험계약대출잔액
         )
    select t10.str_ym                                 as ta_ym
         , t10.coor_cs_no                             as shmdn                      -- 그룹md번호
         , nvl(sum(case when t10.ins_sbsn_good_lrcl_cd not in ('09')
                        then t10.wc_apai_cmlt_inp_fe
                        else 0
                    end)
               ,0)                                    as iu_ase_at                  -- 보험자산금액
         , nvl(sum(case when t10.ins_sbsn_good_lrcl_cd in ('09')
                         and t15.min_ann_rem_am > 0
                        then t15.min_ann_rem_am
                        when t10.ins_sbsn_good_lrcl_cd in ('09')
                         and t15.min_ann_rem_am =0
                        then t10.wc_apai_cmlt_inp_fe
                        else 0
                    end)
               ,0)                                    as pnz_iu_al                  -- 연금보험잔액
         , nvl(sum(t14.inon_lrem_am),0)               as iu_are_ln_al               -- 보험계약대출잔액
    --01[건강보험]
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then 1
                        else 0
                    end)
               ,0)                                    as hlt_iu_mtn_are_ct          -- 건강보험유지계약건수
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then cmip
                        else 0
                    end)
               ,0)                                    as hlt_iu_mtn_are_cmip        -- 건강보험유지계약CMIP금액
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then 1
                        else 0
                    end)
               ,0)                                    as hlt_iu_ivl_are_ct          -- 건강보험실효계약건수
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then cmip
                        else 0
                    end)
               ,0)                                    as hlt_iu_ivl_are_cmip        -- 건강보험실효계약CMIP금액
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then 1
                        else 0
                    end)
               ,0)                                    as hlt_iu_insm_bil_ct         -- 건강보험보험금청구건수
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as hlt_iu_insm_bla            -- 건강보험보험금청구금액
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then 1
                        else 0
                    end)
               ,0)                                    as hlt_iu_et_alpy_ct          -- 건강보험기타제지급건수
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as hlt_iu_et_alpy_at          -- 건강보험기타제지급금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then t14.cnt
                        else 0
                    end)
               ,0)                                    as hlt_iu_are_ln_ct           -- 건강보험계약대출건수
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then t14.pllo_am
                        else 0
                    end)
               ,0)                                    as hlt_iu_are_lna             -- 건강보험계약대출금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '01'
                        then t14.inon_lrem_am
                        else 0
                    end)
               ,0)                                    as hlt_iu_are_ln_al           -- 건강보험계약대출잔액
    --05[상해보험]
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then 1
                        else 0
                    end)
               ,0)                                    as ijr_iu_mtn_are_ct          -- 상해보험유지계약건수
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then cmip
                        else 0
                    end)
               ,0)                                    as ijr_iu_mtn_are_cmip        -- 상해보험유지계약CMIP금액
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then 1
                        else 0
                    end)
               ,0)                                    as ijr_iu_ivl_are_ct          -- 상해보험실효계약건수
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then cmip
                        else 0
                    end)
               ,0)                                    as ijr_iu_ivl_are_cmip        -- 상해보험실효계약CMIP금액
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then 1
                        else 0
                    end)
               ,0)                                    as ijr_iu_insm_bil_ct         -- 상해보험보험금청구건수
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as ijr_iu_insm_bla            -- 상해보험보험금청구금액
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then 1
                        else 0
                    end)
               ,0)                                    as ijr_iu_et_alpy_ct          -- 상해보험기타제지급건수
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as ijr_iu_et_alpy_at          -- 상해보험기타제지급금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then t14.cnt
                        else 0
                    end)
               ,0)                                    as ijr_iu_are_ln_ct           -- 상해보험계약대출건수
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then t14.pllo_am
                        else 0
                    end)
               ,0)                                    as ijr_iu_are_lna             -- 상해보험계약대출금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '05'
                        then t14.inon_lrem_am
                        else 0
                    end)
               ,0)                                    as ijr_iu_are_ln_al           -- 상해보험계약대출잔액
    --07[양로보험]
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then 1
                        else 0
                    end)
               ,0)                                    as crag_iu_mtn_are_ct         -- 양로보험유지계약건수
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then cmip
                        else 0
                    end)
               ,0)                                    as crag_iu_mtn_are_cmip       -- 양로보험유지계약CMIP금액
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then 1
                        else 0
                    end)
               ,0)                                    as crag_iu_ivl_are_ct         -- 양로보험실효계약건수
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then cmip
                        else 0
                    end)
               ,0)                                    as crag_iu_ivl_are_cmip       -- 양로보험실효계약CMIP금액
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then 1
                        else 0
                    end)
               ,0)                                    as crag_iu_insm_bil_ct        -- 양로보험보험금청구건수
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as crag_iu_insm_bla          -- 양로보험보험금청구금액
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then 1
                        else 0
                    end)
               ,0)                                    as crag_iu_et_alpy_ct         -- 양로보험기타제지급건수
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as crag_iu_et_alpy_at         -- 양로보험기타제지급금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then t14.cnt
                        else 0
                    end)
               ,0)                                    as crag_iu_are_ln_ct          -- 양로보험계약대출건수
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then t14.pllo_am
                        else 0
                    end)
               ,0)                                    as crag_iu_are_lna            -- 양로보험계약대출금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '07'
                        then t14.inon_lrem_am
                        else 0
                    end)
               ,0)                                    as crag_iu_are_ln_al          -- 양로보험계약대출잔액
    --08[어린이보험]
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then 1
                        else 0
                    end)
               ,0)                                    as chld_iu_mtn_are_ct         -- 어린이보험유지계약건수
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then cmip
                        else 0
                    end)
               ,0)                                    as chld_iu_mtn_are_cmip       -- 어린이보험유지계약CMIP금액
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then 1
                        else 0
                    end)
               ,0)                                    as chld_iu_ivl_are_ct         -- 어린이보험실효계약건수
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then cmip
                        else 0
                    end)
               ,0)                                    as chld_iu_ivl_are_cmip       -- 어린이보험실효계약CMIP금액
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then 1
                        else 0
                    end)
               ,0)                                    as chld_iu_insm_bil_ct        -- 어린이보험보험금청구건수
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as chld_iu_insm_bla           -- 어린이보험보험금청구금액
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then 1
                        else 0
                    end)
               ,0)                                    as chld_iu_et_alpy_ct         -- 어린이보험기타제지급건수
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as chld_iu_et_alpy_at         -- 어린이보험기타제지급금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then t14.cnt
                        else 0
                    end)
               ,0)                                    as chld_iu_are_ln_ct          -- 어린이보험계약대출건수
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then t14.pllo_am
                        else 0
                    end)
               ,0)                                    as chld_iu_are_lna            -- 어린이보험계약대출금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '08'
                        then t14.inon_lrem_am
                        else 0
                    end)
               ,0)                                    as chld_iu_are_ln_al          -- 어린이보험계약대출잔액
    --02,09,10[연금저축교육]
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then 1
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_mtn_are_ct  -- 연금저축교육보험유지계약건수
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then cmip
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_mtn_are_cmip -- 연금저축교육보험유지계약CMIP금액
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then 1
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_ivl_are_ct  -- 연금저축교육보험실효계약건수
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then cmip
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_ivl_are_cmip -- 연금저축교육보험실효계약CMIP금액
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then 1
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_insm_bil_ct -- 연금저축교육보험보험금청구건수
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_insm_bla    -- 연금저축교육보험보험금청구금액
         , nvl(sum(case when t12.fur_rs_cd = 'AG'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then 1
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_pnz_ct      -- 연금저축교육보험연금건수
         , nvl(sum(case when t12.fur_rs_cd = 'AG'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_pnz_at      -- 연금저축교육보험연금금액
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then 1
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_et_alpy_ct  -- 연금저축교육보험기타제지급건수
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_et_alpy_at  -- 연금저축교육보험기타제지급금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then t14.cnt
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_are_ln_ct   -- 연금저축교육보험계약대출건수
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then t14.pllo_am
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_are_lna     -- 연금저축교육보험계약대출금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd in ('09','10','02')
                        then t14.inon_lrem_am
                        else 0
                    end)
               ,0)                                    as pnz_svg_edu_iu_are_ln_al   -- 연금저축교육보험계약대출잔액
    --12[종신보험]
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then 1
                        else 0
                    end)
               ,0)                                    as wli_iu_mtn_are_ct          -- 종신보험유지계약건수
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then cmip
                        else 0
                    end)
               ,0)                                    as wli_iu_mtn_are_cmip        -- 종신보험유지계약CMIP금액
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then 1
                        else 0
                    end)
               ,0)                                    as wli_iu_ivl_are_ct          -- 종신보험실효계약건수
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then cmip
                        else 0
                    end)
               ,0)                                    as wli_iu_ivl_are_cmip        -- 종신보험실효계약CMIP금액
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then 1
                        else 0
                    end)
               ,0)                                    as wli_iu_insm_bil_ct         -- 종신보험보험금청구건수
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as wli_iu_insm_bla            -- 종신보험보험금청구금액
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then 1
                        else 0
                    end)
               ,0)                                    as wli_iu_et_alpy_ct          -- 종신보험기타제지급건수
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as wli_iu_et_alpy_at          -- 종신보험기타제지급금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then t14.cnt
                        else 0
                    end)
               ,0)                                    as wli_iu_are_ln_ct           -- 종신보험계약대출건수
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then t14.pllo_am
                        else 0
                    end)
               ,0)                                    as wli_iu_are_lna             -- 종신보험계약대출금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '12'
                        then t14.inon_lrem_am
                        else 0
                    end)
               ,0)                                    as wli_iu_are_ln_al           -- 종신보험계약대출잔액
    --13[종합보험]
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then 1
                        else 0
                    end)
               ,0)                                    as ovl_iu_mtn_are_ct          -- 종합보험유지계약건수
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then cmip
                        else 0
                    end)
               ,0)                                    as ovl_iu_mtn_are_cmip        -- 종합보험유지계약CMIP금액
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then 1
                        else 0
                    end)
               ,0)                                    as ovl_iu_ivl_are_ct          -- 종합보험실효계약건수
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then cmip
                        else 0
                    end)
               ,0)                                    as ovl_iu_ivl_are_cmip        -- 종합보험실효계약CMIP금액
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then 1
                        else 0
                    end)
               ,0)                                    as ovl_iu_insm_bil_ct         -- 종합보험보험금청구건수
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as ovl_iu_insm_bla            -- 종합보험보험금청구금액
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then 1
                        else 0
                    end)
               ,0)                                    as ovl_iu_et_alpy_ct          -- 종합보험기타제지급건수
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as ovl_iu_et_alpy_at          -- 종합보험기타제지급금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then t14.cnt
                        else 0
                    end)
               ,0)                                    as ovl_iu_are_ln_ct           -- 종합보험계약대출건수
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then t14.pllo_am
                        else 0
                    end)
               ,0)                                    as ovl_iu_are_lna             -- 종합보험계약대출금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '13'
                        then t14.inon_lrem_am
                        else 0
                    end)
               ,0)                                    as ovl_iu_are_ln_al           -- 종합보험계약대출잔액
    --06[변액보험]
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd = '06'
                        then 1
                        else 0
                    end)
               ,0)                                    as vli_iu_mtn_are_ct          -- 변액보험유지계약건수
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd = '06'
                        then cmip
                        else 0
                    end)
               ,0)                                    as vli_iu_mtn_are_cmip        -- 변액보험유지계약CMIP금액
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd = '06'
                        then 1
                        else 0
                    end)
               ,0)                                    as vli_iu_ivl_are_ct          -- 변액보험실효계약건수
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd = '06'
                        then cmip
                        else 0
                    end)
               ,0)                                    as vli_iu_ivl_are_cmip        -- 변액보험실효계약CMIP금액
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd = '06'
                        then 1
                        else 0
                    end)
               ,0)                                    as vli_iu_insm_bil_ct         -- 변액보험보험금청구건수
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd = '06'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as vli_iu_insm_bla            -- 변액보험보험금청구금액
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd = '06'
                        then 1
                        else 0
                    end)
               ,0)                                    as vli_iu_et_alpy_ct          -- 변액보험기타제지급건수
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd = '06'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as vli_iu_et_alpy_at          -- 변액보험기타제지급금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd = '06'
                        then t14.cnt
                        else 0
                    end)
               ,0)                                    as vli_iu_are_ln_ct           -- 변액보험계약대출건수
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd = '06'
                        then t14.pllo_am
                        else 0
                    end)
               ,0)                                    as vli_iu_are_lna             -- 변액보험계약대출금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd = '06'
                        then t14.inon_lrem_am
                        else 0
                    end)
               ,0)                                    as vli_iu_are_ln_al           -- 변액보험계약대출잔액
    --not in ('01','02','05','06','07','08','09','10','11','12','13')[기타보험]
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then 1
                        else 0
                    end)
               ,0)                                    as et_iu_mtn_are_ct           -- 기타보험유지계약건수
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then cmip
                        else 0
                    end)
               ,0)                                    as et_iu_mtn_are_cmip         -- 기타보험유지계약CMIP금액
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then 1
                        else 0
                    end)
               ,0)                                    as et_iu_ivl_are_ct           -- 기타보험실효계약건수
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then cmip
                        else 0
                    end)
               ,0)                                    as et_iu_ivl_are_cmip         -- 기타보험실효계약CMIP금액
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then 1
                        else 0
                    end)
               ,0)                                    as et_iu_insm_bil_ct          -- 기타보험보험금청구건수
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as et_iu_insm_bla             -- 기타보험보험금청구금액
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then 1
                        else 0
                    end)
               ,0)                                    as et_iu_et_alpy_ct           -- 기타보험기타제지급건수
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as et_iu_et_alpy_at           -- 기타보험기타제지급금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then t14.cnt
                        else 0
                    end)
               ,0)                                    as et_iu_are_ln_ct            -- 기타보험계약대출건수
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then t14.pllo_am
                        else 0
                    end)
               ,0)                                    as et_iu_are_lna              -- 기타보험계약대출금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd not in ('01','02','05','07','08','09','10','11','12','13')
                        then t14.inon_lrem_am
                        else 0
                    end)
               ,0)                                    as et_iu_are_ln_al            -- 기타보험계약대출잔액
    --11[제휴보험]
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then 1
                        else 0
                    end)
               ,0)                                    as afl_iu_mtn_are_ct          -- 제휴보험유지계약건수
         , nvl(sum(case when t10.ctst_cd = 'A'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then cmip
                        else 0
                    end)
               ,0)                                    as afl_iu_mtn_are_cmip        -- 제휴보험유지계약CMIP금액
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then 1
                        else 0
                    end)
               ,0)                                    as afl_iu_ivl_are_ct          -- 제휴보험실효계약건수
         , nvl(sum(case when t10.ctst_cd = 'C'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then cmip
                        else 0
                    end)
               ,0)                                    as afl_iu_ivl_are_cmip        -- 제휴보험실효계약CMIP금액
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then 1
                        else 0
                    end)
               ,0)                                    as afl_iu_insm_bil_ct         -- 제휴보험보험금청구건수
         , nvl(sum(case when t12.fur_rs_cd = 'BA'
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as afl_iu_insm_bla            -- 제휴보험보험금청구금액
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then 1
                        else 0
                    end)
               ,0)                                    as afl_iu_et_alpy_ct          -- 제휴보험기타제지급건수
         , nvl(sum(case when t12.fur_rs_cd in ('AA','AB','AC','AD','AF','AJ','AK','AL','AM','AS','ZB')
                         and t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then t12.fur_am
                        else 0
                    end)
               ,0)                                    as afl_iu_et_alpy_at          -- 제휴보험기타제지급금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then t14.cnt
                        else 0
                    end)
               ,0)                                    as afl_iu_are_ln_ct           -- 제휴보험계약대출건수
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then t14.pllo_am
                        else 0
                    end)
               ,0)                                    as afl_iu_are_lna             -- 제휴보험계약대출금액
         , nvl(sum(case when t10.ins_sbsn_good_smcl_cd <> '06'
                         and t10.ins_sbsn_good_lrcl_cd = '11'
                        then t14.inon_lrem_am
                        else 0
                    end)
               ,0)                                    as afl_iu_are_ln_al           -- 제휴보험계약대출잔액
      from shl.dm_mthl_con           t10                                            -- dm_월별계약
     inner join
           shl.dm_mthl_con_anx_info  t11                                            -- dm_월별계약부가정보
        on t10.str_ym  = t11.str_ym
       and t10.inon_no = t11.inon_no
      left outer join
          (select to_char(tra_ymd,'yyyymm')           as tra_ym
                , inon_no
                , fur_rs_cd
                , max(fur_am)                         as fur_am
             from shl.dm_py_det                                                     -- 지급상세
            where fur_can_sc_cd = '00'                                              -- 정상
              and to_char(tra_ymd,'yyyymm') = '{date_cd('P_TA_YM')}'
            group by to_char(tra_ymd,'yyyymm')
                   , inon_no
                   , fur_rs_cd
           )                         t12
        on t10.str_ym  = t12.tra_ym
       and t10.inon_no = t12.inon_no
      left outer join
          (select str_ym
                , inon_no
                , 1                                    as cnt
                , pllo_am
                , inon_lrem_am
             from shl.dm_pllo
            where str_ym = '{date_cd('P_TA_YM')}'
              and inon_lon_kd_cd = '1'                                              -- 일반대출
           )                         t14
        on t10.str_ym  = t14.str_ym
       and t10.inon_no = t14.inon_no
      left outer join
           (select to_char(ann_occ_ymd,'yyyymm')       as ann_occ_ym
                 , inon_no
                 , min(ann_rem_am)                     as min_ann_rem_am
              from shl.tr_annpy                                                     -- tr_연금지급
             where to_char(ann_occ_ymd,'yyyymm') = '{date_cd('P_TA_YM')}'
             group by to_char(ann_occ_ymd,'yyyymm')
                    , inon_no
            ) t15
        on t10.str_ym  = t15.ann_occ_ym
       and t10.inon_no = t15.inon_no
     where t10.str_ym  = '{date_cd('P_TA_YM')}'
       and t10.indv_asct_sc_cd = '01'                                               -- 개인
     group by t10.str_ym
            , t10.coor_cs_no                                                        -- 계약자고객번호
"""

insert_sql_for_tmp_2 = f"""
    insert into tmp_sh2.shdmigd010_tmp02
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , cre_ln_ct                              -- 신용대출건수
         , cre_lna                                -- 신용대출금액
         , cre_ln_al                              -- 신용대출잔액
         , esa_ll_ln_ct                           -- 부동산담보대출건수
         , esa_ll_lna                             -- 부동산담보대출금액
         , esa_ll_ln_al                           -- 부동산담보대출잔액
         , et_ll_ln_ct                            -- 기타담보대출건수
         , et_ll_lna                              -- 기타담보대출금액
         , et_ll_ln_al                            -- 기타담보대출잔액
         )
    select clos_ym                                    as ta_ym
         , cs_no                                      as shmdn                      -- 그룹md번호
         , nvl(sum(case when lnco_sc_cd = '10'
                        then 1
                        else 0
                    end)
               ,0)                                    as cre_ln_ct                  -- 신용대출건수
         , nvl(sum(case when lnco_sc_cd = '10'
                        then lon_am
                        else 0
                    end)
               ,0)                                    as cre_lna                    -- 신용대출금액
         , nvl(sum(case when lnco_sc_cd = '10'
                        then lrem_am
                        else 0
                    end)
               ,0)                                    as cre_ln_al                  -- 신용대출잔액
         , nvl(sum(case when lnco_sc_cd = '20'
                        then 1
                        else 0
                    end)
               ,0)                                    as esa_ll_ln_ct               -- 부동산담보대출건수
         , nvl(sum(case when lnco_sc_cd = '20'
                        then lon_am
                        else 0
                    end)
               ,0)                                    as esa_ll_lna                 -- 부동산담보대출금액
         , nvl(sum(case when lnco_sc_cd = '20'
                        then lrem_am
                        else 0
                    end)
               ,0)                                    as esa_ll_ln_al               -- 부동산담보대출잔액
         , nvl(sum(case when lnco_sc_cd not in ('10','20')
                        then 1
                        else 0
                    end)
               ,0)                                    as et_ll_ln_ct                -- 기타담보대출건수
         , nvl(sum(case when lnco_sc_cd not in ('10','20')
                        then lon_am
                        else 0
                    end)
               ,0)                                    as et_ll_lna                  -- 기타담보대출금액
         , nvl(sum(case when lnco_sc_cd not in ('10','20')
                        then lrem_am
                        else 0
                    end)
               ,0)                                    as et_ll_ln_al                -- 기타담보대출잔액
      from shl.fn_mmln                                                              -- fn_대출월마감
     where clos_ym       = '{date_cd('P_TA_YM')}'
       and lnco_sc_cd    = '10' --개인
     group by clos_ym
            , cs_no
"""
insert_sql_for_tmp_3 = f"""
    insert into tmp_sh2.shdmigd010_tmp99
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , iu_ase_at                              -- 보험자산금액
         , pnz_iu_al                              -- 연금보험잔액
         , iu_are_ln_al                           -- 보험계약대출잔액
         , hlt_iu_mtn_are_ct                      -- 건강보험유지계약건수
         , hlt_iu_mtn_are_cmip                    -- 건강보험유지계약CMIP금액
         , hlt_iu_ivl_are_ct                      -- 건강보험실효계약건수
         , hlt_iu_ivl_are_cmip                    -- 건강보험실효계약CMIP금액
         , hlt_iu_insm_bil_ct                     -- 건강보험보험금청구건수
         , hlt_iu_insm_bla                        -- 건강보험보험금청구금액
         , hlt_iu_et_alpy_ct                      -- 건강보험기타제지급건수
         , hlt_iu_et_alpy_at                      -- 건강보험기타제지급금액
         , hlt_iu_are_ln_ct                       -- 건강보험계약대출건수
         , hlt_iu_are_lna                         -- 건강보험계약대출금액
         , hlt_iu_are_ln_al                       -- 건강보험계약대출잔액
         , ijr_iu_mtn_are_ct                      -- 상해보험유지계약건수
         , ijr_iu_mtn_are_cmip                    -- 상해보험유지계약CMIP금액
         , ijr_iu_ivl_are_ct                      -- 상해보험실효계약건수
         , ijr_iu_ivl_are_cmip                    -- 상해보험실효계약CMIP금액
         , ijr_iu_insm_bil_ct                     -- 상해보험보험금청구건수
         , ijr_iu_insm_bla                        -- 상해보험보험금청구금액
         , ijr_iu_et_alpy_ct                      -- 상해보험기타제지급건수
         , ijr_iu_et_alpy_at                      -- 상해보험기타제지급금액
         , ijr_iu_are_ln_ct                       -- 상해보험계약대출건수
         , ijr_iu_are_lna                         -- 상해보험계약대출금액
         , ijr_iu_are_ln_al                       -- 상해보험계약대출잔액
         , crag_iu_mtn_are_ct                     -- 양로보험유지계약건수
         , crag_iu_mtn_are_cmip                   -- 양로보험유지계약CMIP금액
         , crag_iu_ivl_are_ct                     -- 양로보험실효계약건수
         , crag_iu_ivl_are_cmip                   -- 양로보험실효계약CMIP금액
         , crag_iu_insm_bil_ct                    -- 양로보험보험금청구건수
         , crag_iu_insm_bla                       -- 양로보험보험금청구금액
         , crag_iu_et_alpy_ct                     -- 양로보험기타제지급건수
         , crag_iu_et_alpy_at                     -- 양로보험기타제지급금액
         , crag_iu_are_ln_ct                      -- 양로보험계약대출건수
         , crag_iu_are_lna                        -- 양로보험계약대출금액
         , crag_iu_are_ln_al                      -- 양로보험계약대출잔액
         , chld_iu_mtn_are_ct                     -- 어린이보험유지계약건수
         , chld_iu_mtn_are_cmip                   -- 어린이보험유지계약CMIP금액
         , chld_iu_ivl_are_ct                     -- 어린이보험실효계약건수
         , chld_iu_ivl_are_cmip                   -- 어린이보험실효계약CMIP금액
         , chld_iu_insm_bil_ct                    -- 어린이보험보험금청구건수
         , chld_iu_insm_bla                       -- 어린이보험보험금청구금액
         , chld_iu_et_alpy_ct                     -- 어린이보험기타제지급건수
         , chld_iu_et_alpy_at                     -- 어린이보험기타제지급금액
         , chld_iu_are_ln_ct                      -- 어린이보험계약대출건수
         , chld_iu_are_lna                        -- 어린이보험계약대출금액
         , chld_iu_are_ln_al                      -- 어린이보험계약대출잔액
         , pnz_svg_edu_iu_mtn_are_ct              -- 연금저축교육보험유지계약건수
         , pnz_svg_edu_iu_mtn_are_cmip            -- 연금저축교육보험유지계약CMIP금액
         , pnz_svg_edu_iu_ivl_are_ct              -- 연금저축교육보험실효계약건수
         , pnz_svg_edu_iu_ivl_are_cmip            -- 연금저축교육보험실효계약CMIP금액
         , pnz_svg_edu_iu_insm_bil_ct             -- 연금저축교육보험보험금청구건수
         , pnz_svg_edu_iu_insm_bla                -- 연금저축교육보험보험금청구금액
         , pnz_svg_edu_iu_pnz_ct                  -- 연금저축교육보험연금건수
         , pnz_svg_edu_iu_pnz_at                  -- 연금저축교육보험연금금액
         , pnz_svg_edu_iu_et_alpy_ct              -- 연금저축교육보험기타제지급건수
         , pnz_svg_edu_iu_et_alpy_at              -- 연금저축교육보험기타제지급금액
         , pnz_svg_edu_iu_are_ln_ct               -- 연금저축교육보험계약대출건수
         , pnz_svg_edu_iu_are_lna                 -- 연금저축교육보험계약대출금액
         , pnz_svg_edu_iu_are_ln_al               -- 연금저축교육보험계약대출잔액
         , wli_mtn_are_ct                         -- 종신보험유지계약건수
         , wli_mtn_are_cmip                       -- 종신보험유지계약CMIP금액
         , wli_ivl_are_ct                         -- 종신보험실효계약건수
         , wli_ivl_are_cmip                       -- 종신보험실효계약CMIP금액
         , wli_insm_bil_ct                        -- 종신보험보험금청구건수
         , wli_insm_bla                           -- 종신보험보험금청구금액
         , wli_et_alpy_ct                         -- 종신보험기타제지급건수
         , wli_et_alpy_at                         -- 종신보험기타제지급금액
         , wli_are_ln_ct                          -- 종신보험계약대출건수
         , wli_are_lna                            -- 종신보험계약대출금액
         , wli_are_ln_al                          -- 종신보험계약대출잔액
         , ovl_iu_mtn_are_ct                      -- 종합보험유지계약건수
         , ovl_iu_mtn_are_cmip                    -- 종합보험유지계약CMIP금액
         , ovl_iu_ivl_are_ct                      -- 종합보험실효계약건수
         , ovl_iu_ivl_are_cmip                    -- 종합보험실효계약CMIP금액
         , ovl_iu_insm_bil_ct                     -- 종합보험보험금청구건수
         , ovl_iu_insm_bla                        -- 종합보험보험금청구금액
         , ovl_iu_et_alpy_ct                      -- 종합보험기타제지급건수
         , ovl_iu_et_alpy_at                      -- 종합보험기타제지급금액
         , ovl_iu_are_ln_ct                       -- 종합보험계약대출건수
         , ovl_iu_are_lna                         -- 종합보험계약대출금액
         , ovl_iu_are_ln_al                       -- 종합보험계약대출잔액
         , vli_mtn_are_ct                         -- 변액보험유지계약건수
         , vli_mtn_are_cmip                       -- 변액보험유지계약CMIP금액
         , vli_ivl_are_ct                         -- 변액보험실효계약건수
         , vli_ivl_are_cmip                       -- 변액보험실효계약CMIP금액
         , vli_insm_bil_ct                        -- 변액보험보험금청구건수
         , vli_insm_bla                           -- 변액보험보험금청구금액
         , vli_et_alpy_ct                         -- 변액보험기타제지급건수
         , vli_et_alpy_at                         -- 변액보험기타제지급금액
         , vli_are_ln_ct                          -- 변액보험계약대출건수
         , vli_are_lna                            -- 변액보험계약대출금액
         , vli_are_ln_al                          -- 변액보험계약대출잔액
         , et_iu_mtn_are_ct                       -- 기타보험유지계약건수
         , et_iu_mtn_are_cmip                     -- 기타보험유지계약CMIP금액
         , et_iu_ivl_are_ct                       -- 기타보험실효계약건수
         , et_iu_ivl_are_cmip                     -- 기타보험실효계약CMIP금액
         , et_iu_insm_bil_ct                      -- 기타보험보험금청구건수
         , et_iu_insm_bla                         -- 기타보험보험금청구금액
         , et_iu_et_alpy_ct                       -- 기타보험기타제지급건수
         , et_iu_et_alpy_at                       -- 기타보험기타제지급금액
         , et_iu_are_ln_ct                        -- 기타보험계약대출건수
         , et_iu_are_lna                          -- 기타보험계약대출금액
         , et_iu_are_ln_al                        -- 기타보험계약대출잔액
         , afl_iu_mtn_are_ct                      -- 제휴보험유지계약건수
         , afl_iu_mtn_are_cmip                    -- 제휴보험유지계약CMIP금액
         , afl_iu_ivl_are_ct                      -- 제휴보험실효계약건수
         , afl_iu_ivl_are_cmip                    -- 제휴보험실효계약CMIP금액
         , afl_iu_insm_bil_ct                     -- 제휴보험보험금청구건수
         , afl_iu_insm_bla                        -- 제휴보험보험금청구금액
         , afl_iu_et_alpy_ct                      -- 제휴보험기타제지급건수
         , afl_iu_et_alpy_at                      -- 제휴보험기타제지급금액
         , afl_iu_are_ln_ct                       -- 제휴보험계약대출건수
         , afl_iu_are_lna                         -- 제휴보험계약대출금액
         , afl_iu_are_ln_al                       -- 제휴보험계약대출잔액
         , cre_ln_ct                              -- 신용대출건수
         , cre_lna                                -- 신용대출금액
         , cre_ln_al                              -- 신용대출잔액
         , esa_ll_ln_ct                           -- 부동산담보대출건수
         , esa_ll_lna                             -- 부동산담보대출금액
         , esa_ll_ln_al                           -- 부동산담보대출잔액
         , et_ll_ln_ct                            -- 기타담보대출건수
         , et_ll_lna                              -- 기타담보대출금액
         , et_ll_ln_al                            -- 기타담보대출잔액
         )
   select  ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'  as aws_ld_dt            -- aws적재일시
         , sum(iu_ase_at)                        as iu_ase_at                   -- 보험자산금액
         , sum(pnz_iu_al)                        as pnz_iu_al                   -- 연금보험잔액
         , sum(iu_are_ln_al)                     as iu_are_ln_al                -- 보험계약대출잔액
         , sum(hlt_iu_mtn_are_ct)                as hlt_iu_mtn_are_ct           -- 건강보험유지계약건수
         , sum(hlt_iu_mtn_are_cmip)              as hlt_iu_mtn_are_cmip         -- 건강보험유지계약CMIP금액
         , sum(hlt_iu_ivl_are_ct)                as hlt_iu_ivl_are_ct           -- 건강보험실효계약건수
         , sum(hlt_iu_ivl_are_cmip)              as hlt_iu_ivl_are_cmip         -- 건강보험실효계약CMIP금액
         , sum(hlt_iu_insm_bil_ct)               as hlt_iu_insm_bil_ct          -- 건강보험보험금청구건수
         , sum(hlt_iu_insm_bla)                  as hlt_iu_insm_bla             -- 건강보험보험금청구금액
         , sum(hlt_iu_et_alpy_ct)                as hlt_iu_et_alpy_ct           -- 건강보험기타제지급건수
         , sum(hlt_iu_et_alpy_at)                as hlt_iu_et_alpy_at           -- 건강보험기타제지급금액
         , sum(hlt_iu_are_ln_ct)                 as hlt_iu_are_ln_ct            -- 건강보험계약대출건수
         , sum(hlt_iu_are_lna)                   as hlt_iu_are_lna              -- 건강보험계약대출금액
         , sum(hlt_iu_are_ln_al)                 as hlt_iu_are_ln_al            -- 건강보험계약대출잔액
         , sum(ijr_iu_mtn_are_ct)                as ijr_iu_mtn_are_ct           -- 상해보험유지계약건수
         , sum(ijr_iu_mtn_are_cmip)              as ijr_iu_mtn_are_cmip         -- 상해보험유지계약CMIP금액
         , sum(ijr_iu_ivl_are_ct)                as ijr_iu_ivl_are_ct           -- 상해보험실효계약건수
         , sum(ijr_iu_ivl_are_cmip)              as ijr_iu_ivl_are_cmip         -- 상해보험실효계약CMIP금액
         , sum(ijr_iu_insm_bil_ct)               as ijr_iu_insm_bil_ct          -- 상해보험보험금청구건수
         , sum(ijr_iu_insm_bla)                  as ijr_iu_insm_bla             -- 상해보험보험금청구금액
         , sum(ijr_iu_et_alpy_ct)                as ijr_iu_et_alpy_ct           -- 상해보험기타제지급건수
         , sum(ijr_iu_et_alpy_at)                as ijr_iu_et_alpy_at           -- 상해보험기타제지급금액
         , sum(ijr_iu_are_ln_ct)                 as ijr_iu_are_ln_ct            -- 상해보험계약대출건수
         , sum(ijr_iu_are_lna)                   as ijr_iu_are_lna              -- 상해보험계약대출금액
         , sum(ijr_iu_are_ln_al)                 as ijr_iu_are_ln_al            -- 상해보험계약대출잔액
         , sum(crag_iu_mtn_are_ct)               as crag_iu_mtn_are_ct          -- 양로보험유지계약건수
         , sum(crag_iu_mtn_are_cmip)             as crag_iu_mtn_are_cmip        -- 양로보험유지계약CMIP금액
         , sum(crag_iu_ivl_are_ct)               as crag_iu_ivl_are_ct          -- 양로보험실효계약건수
         , sum(crag_iu_ivl_are_cmip)             as crag_iu_ivl_are_cmip        -- 양로보험실효계약CMIP금액
         , sum(crag_iu_insm_bil_ct)              as crag_iu_insm_bil_ct         -- 양로보험보험금청구건수
         , sum(crag_iu_insm_bla)                 as crag_iu_insm_bla            -- 양로보험보험금청구금액
         , sum(crag_iu_et_alpy_ct)               as crag_iu_et_alpy_ct          -- 양로보험기타제지급건수
         , sum(crag_iu_et_alpy_at)               as crag_iu_et_alpy_at          -- 양로보험기타제지급금액
         , sum(crag_iu_are_ln_ct)                as crag_iu_are_ln_ct           -- 양로보험계약대출건수
         , sum(crag_iu_are_lna)                  as crag_iu_are_lna             -- 양로보험계약대출금액
         , sum(crag_iu_are_ln_al)                as crag_iu_are_ln_al           -- 양로보험계약대출잔액
         , sum(chld_iu_mtn_are_ct)               as chld_iu_mtn_are_ct          -- 어린이보험유지계약건수
         , sum(chld_iu_mtn_are_cmip)             as chld_iu_mtn_are_cmip        -- 어린이보험유지계약CMIP금액
         , sum(chld_iu_ivl_are_ct)               as chld_iu_ivl_are_ct          -- 어린이보험실효계약건수
         , sum(chld_iu_ivl_are_cmip)             as chld_iu_ivl_are_cmip        -- 어린이보험실효계약CMIP금액
         , sum(chld_iu_insm_bil_ct)              as chld_iu_insm_bil_ct         -- 어린이보험보험금청구건수
         , sum(chld_iu_insm_bla)                 as chld_iu_insm_bla            -- 어린이보험보험금청구금액
         , sum(chld_iu_et_alpy_ct)               as chld_iu_et_alpy_ct          -- 어린이보험기타제지급건수
         , sum(chld_iu_et_alpy_at)               as chld_iu_et_alpy_at          -- 어린이보험기타제지급금액
         , sum(chld_iu_are_ln_ct)                as chld_iu_are_ln_ct           -- 어린이보험계약대출건수
         , sum(chld_iu_are_lna)                  as chld_iu_are_lna             -- 어린이보험계약대출금액
         , sum(chld_iu_are_ln_al)                as chld_iu_are_ln_al           -- 어린이보험계약대출잔액
         , sum(pnz_svg_edu_iu_mtn_are_ct)        as pnz_svg_edu_iu_mtn_are_ct   -- 연금저축교육보험유지계약건수
         , sum(pnz_svg_edu_iu_mtn_are_cmip)      as pnz_svg_edu_iu_mtn_are_cmip -- 연금저축교육보험유지계약CMIP금액
         , sum(pnz_svg_edu_iu_ivl_are_ct)        as pnz_svg_edu_iu_ivl_are_ct   -- 연금저축교육보험실효계약건수
         , sum(pnz_svg_edu_iu_ivl_are_cmip)      as pnz_svg_edu_iu_ivl_are_cmip -- 연금저축교육보험실효계약CMIP금액
         , sum(pnz_svg_edu_iu_insm_bil_ct)       as pnz_svg_edu_iu_insm_bil_ct  -- 연금저축교육보험보험금청구건수
         , sum(pnz_svg_edu_iu_insm_bla)          as pnz_svg_edu_iu_insm_bla     -- 연금저축교육보험보험금청구금액
         , sum(pnz_svg_edu_iu_pnz_ct)            as pnz_svg_edu_iu_pnz_ct       -- 연금저축교육보험연금건수
         , sum(pnz_svg_edu_iu_pnz_at)            as pnz_svg_edu_iu_pnz_at       -- 연금저축교육보험연금금액
         , sum(pnz_svg_edu_iu_et_alpy_ct)        as pnz_svg_edu_iu_et_alpy_ct   -- 연금저축교육보험기타제지급건수
         , sum(pnz_svg_edu_iu_et_alpy_at)        as pnz_svg_edu_iu_et_alpy_at   -- 연금저축교육보험기타제지급금액
         , sum(pnz_svg_edu_iu_are_ln_ct)         as pnz_svg_edu_iu_are_ln_ct    -- 연금저축교육보험계약대출건수
         , sum(pnz_svg_edu_iu_are_lna)           as pnz_svg_edu_iu_are_lna      -- 연금저축교육보험계약대출금액
         , sum(pnz_svg_edu_iu_are_ln_al)         as pnz_svg_edu_iu_are_ln_al    -- 연금저축교육보험계약대출잔액
         , sum(wli_mtn_are_ct)                   as wli_mtn_are_ct              -- 종신보험유지계약건수
         , sum(wli_mtn_are_cmip)                 as wli_mtn_are_cmip            -- 종신보험유지계약CMIP금액
         , sum(wli_ivl_are_ct)                   as wli_ivl_are_ct              -- 종신보험실효계약건수
         , sum(wli_ivl_are_cmip)                 as wli_ivl_are_cmip            -- 종신보험실효계약CMIP금액
         , sum(wli_insm_bil_ct)                  as wli_insm_bil_ct             -- 종신보험보험금청구건수
         , sum(wli_insm_bla)                     as wli_insm_bla                -- 종신보험보험금청구금액
         , sum(wli_et_alpy_ct)                   as wli_et_alpy_ct              -- 종신보험기타제지급건수
         , sum(wli_et_alpy_at)                   as wli_et_alpy_at              -- 종신보험기타제지급금액
         , sum(wli_are_ln_ct)                    as wli_are_ln_ct               -- 종신보험계약대출건수
         , sum(wli_are_lna)                      as wli_are_lna                 -- 종신보험계약대출금액
         , sum(wli_are_ln_al)                    as wli_are_ln_al               -- 종신보험계약대출잔액
         , sum(ovl_iu_mtn_are_ct)                as ovl_iu_mtn_are_ct           -- 종합보험유지계약건수
         , sum(ovl_iu_mtn_are_cmip)              as ovl_iu_mtn_are_cmip         -- 종합보험유지계약CMIP금액
         , sum(ovl_iu_ivl_are_ct)                as ovl_iu_ivl_are_ct           -- 종합보험실효계약건수
         , sum(ovl_iu_ivl_are_cmip)              as ovl_iu_ivl_are_cmip         -- 종합보험실효계약CMIP금액
         , sum(ovl_iu_insm_bil_ct)               as ovl_iu_insm_bil_ct          -- 종합보험보험금청구건수
         , sum(ovl_iu_insm_bla)                  as ovl_iu_insm_bla             -- 종합보험보험금청구금액
         , sum(ovl_iu_et_alpy_ct)                as ovl_iu_et_alpy_ct           -- 종합보험기타제지급건수
         , sum(ovl_iu_et_alpy_at)                as ovl_iu_et_alpy_at           -- 종합보험기타제지급금액
         , sum(ovl_iu_are_ln_ct)                 as ovl_iu_are_ln_ct            -- 종합보험계약대출건수
         , sum(ovl_iu_are_lna)                   as ovl_iu_are_lna              -- 종합보험계약대출금액
         , sum(ovl_iu_are_ln_al)                 as ovl_iu_are_ln_al            -- 종합보험계약대출잔액
         , sum(vli_mtn_are_ct)                   as vli_mtn_are_ct              -- 변액보험유지계약건수
         , sum(vli_mtn_are_cmip)                 as vli_mtn_are_cmip            -- 변액보험유지계약CMIP금액
         , sum(vli_ivl_are_ct)                   as vli_ivl_are_ct              -- 변액보험실효계약건수
         , sum(vli_ivl_are_cmip)                 as vli_ivl_are_cmip            -- 변액보험실효계약CMIP금액
         , sum(vli_insm_bil_ct)                  as vli_insm_bil_ct             -- 변액보험보험금청구건수
         , sum(vli_insm_bla)                     as vli_insm_bla                -- 변액보험보험금청구금액
         , sum(vli_et_alpy_ct)                   as vli_et_alpy_ct              -- 변액보험기타제지급건수
         , sum(vli_et_alpy_at)                   as vli_et_alpy_at              -- 변액보험기타제지급금액
         , sum(vli_are_ln_ct)                    as vli_are_ln_ct               -- 변액보험계약대출건수
         , sum(vli_are_lna)                      as vli_are_lna                 -- 변액보험계약대출금액
         , sum(vli_are_ln_al)                    as vli_are_ln_al               -- 변액보험계약대출잔액
         , sum(et_iu_mtn_are_ct)                 as et_iu_mtn_are_ct            -- 기타보험유지계약건수
         , sum(et_iu_mtn_are_cmip)               as et_iu_mtn_are_cmip          -- 기타보험유지계약CMIP금액
         , sum(et_iu_ivl_are_ct)                 as et_iu_ivl_are_ct            -- 기타보험실효계약건수
         , sum(et_iu_ivl_are_cmip)               as et_iu_ivl_are_cmip          -- 기타보험실효계약CMIP금액
         , sum(et_iu_insm_bil_ct)                as et_iu_insm_bil_ct           -- 기타보험보험금청구건수
         , sum(et_iu_insm_bla)                   as et_iu_insm_bla              -- 기타보험보험금청구금액
         , sum(et_iu_et_alpy_ct)                 as et_iu_et_alpy_ct            -- 기타보험기타제지급건수
         , sum(et_iu_et_alpy_at)                 as et_iu_et_alpy_at            -- 기타보험기타제지급금액
         , sum(et_iu_are_ln_ct)                  as et_iu_are_ln_ct             -- 기타보험계약대출건수
         , sum(et_iu_are_lna)                    as et_iu_are_lna               -- 기타보험계약대출금액
         , sum(et_iu_are_ln_al)                  as et_iu_are_ln_al             -- 기타보험계약대출잔액
         , sum(afl_iu_mtn_are_ct)                as afl_iu_mtn_are_ct           -- 제휴보험유지계약건수
         , sum(afl_iu_mtn_are_cmip)              as afl_iu_mtn_are_cmip         -- 제휴보험유지계약CMIP금액
         , sum(afl_iu_ivl_are_ct)                as afl_iu_ivl_are_ct           -- 제휴보험실효계약건수
         , sum(afl_iu_ivl_are_cmip)              as afl_iu_ivl_are_cmip         -- 제휴보험실효계약CMIP금액
         , sum(afl_iu_insm_bil_ct)               as afl_iu_insm_bil_ct          -- 제휴보험보험금청구건수
         , sum(afl_iu_insm_bla)                  as afl_iu_insm_bla             -- 제휴보험보험금청구금액
         , sum(afl_iu_et_alpy_ct)                as afl_iu_et_alpy_ct           -- 제휴보험기타제지급건수
         , sum(afl_iu_et_alpy_at)                as afl_iu_et_alpy_at           -- 제휴보험기타제지급금액
         , sum(afl_iu_are_ln_ct)                 as afl_iu_are_ln_ct            -- 제휴보험계약대출건수
         , sum(afl_iu_are_lna)                   as afl_iu_are_lna              -- 제휴보험계약대출금액
         , sum(afl_iu_are_ln_al)                 as afl_iu_are_ln_al            -- 제휴보험계약대출잔액
         , sum(cre_ln_ct)                        as cre_ln_ct                   -- 신용대출건수
         , sum(cre_lna)                          as cre_lna                     -- 신용대출금액
         , sum(cre_ln_al)                        as cre_ln_al                   -- 신용대출잔액
         , sum(esa_ll_ln_ct)                     as esa_ll_ln_ct                -- 부동산담보대출건수
         , sum(esa_ll_lna)                       as esa_ll_lna                  -- 부동산담보대출금액
         , sum(esa_ll_ln_al)                     as esa_ll_ln_al                -- 부동산담보대출잔액
         , sum(et_ll_ln_ct)                      as et_ll_ln_ct                 -- 기타담보대출건수
         , sum(et_ll_lna)                        as et_ll_lna                   -- 기타담보대출금액
         , sum(et_ll_ln_al)                      as et_ll_ln_al                 -- 기타담보대출잔액
  from (select ta_ym                                                            -- 기준년월
             , shmdn                                                            -- 그룹MD번호
             , iu_ase_at                                                        -- 보험자산금액
             , pnz_iu_al                                                        -- 연금보험잔액
             , iu_are_ln_al                                                     -- 보험계약대출잔액
             , hlt_iu_mtn_are_ct                                                -- 건강보험유지계약건수
             , hlt_iu_mtn_are_cmip                                              -- 건강보험유지계약CMIP금액
             , hlt_iu_ivl_are_ct                                                -- 건강보험실효계약건수
             , hlt_iu_ivl_are_cmip                                              -- 건강보험실효계약CMIP금액
             , hlt_iu_insm_bil_ct                                               -- 건강보험보험금청구건수
             , hlt_iu_insm_bla                                                  -- 건강보험보험금청구금액
             , hlt_iu_et_alpy_ct                                                -- 건강보험기타제지급건수
             , hlt_iu_et_alpy_at                                                -- 건강보험기타제지급금액
             , hlt_iu_are_ln_ct                                                 -- 건강보험계약대출건수
             , hlt_iu_are_lna                                                   -- 건강보험계약대출금액
             , hlt_iu_are_ln_al                                                 -- 건강보험계약대출잔액
             , ijr_iu_mtn_are_ct                                                -- 상해보험유지계약건수
             , ijr_iu_mtn_are_cmip                                              -- 상해보험유지계약CMIP금액
             , ijr_iu_ivl_are_ct                                                -- 상해보험실효계약건수
             , ijr_iu_ivl_are_cmip                                              -- 상해보험실효계약CMIP금액
             , ijr_iu_insm_bil_ct                                               -- 상해보험보험금청구건수
             , ijr_iu_insm_bla                                                  -- 상해보험보험금청구금액
             , ijr_iu_et_alpy_ct                                                -- 상해보험기타제지급건수
             , ijr_iu_et_alpy_at                                                -- 상해보험기타제지급금액
             , ijr_iu_are_ln_ct                                                 -- 상해보험계약대출건수
             , ijr_iu_are_lna                                                   -- 상해보험계약대출금액
             , ijr_iu_are_ln_al                                                 -- 상해보험계약대출잔액
             , crag_iu_mtn_are_ct                                               -- 양로보험유지계약건수
             , crag_iu_mtn_are_cmip                                             -- 양로보험유지계약CMIP금액
             , crag_iu_ivl_are_ct                                               -- 양로보험실효계약건수
             , crag_iu_ivl_are_cmip                                             -- 양로보험실효계약CMIP금액
             , crag_iu_insm_bil_ct                                              -- 양로보험보험금청구건수
             , crag_iu_insm_bla                                                 -- 양로보험보험금청구금액
             , crag_iu_et_alpy_ct                                               -- 양로보험기타제지급건수
             , crag_iu_et_alpy_at                                               -- 양로보험기타제지급금액
             , crag_iu_are_ln_ct                                                -- 양로보험계약대출건수
             , crag_iu_are_lna                                                  -- 양로보험계약대출금액
             , crag_iu_are_ln_al                                                -- 양로보험계약대출잔액
             , chld_iu_mtn_are_ct                                               -- 어린이보험유지계약건수
             , chld_iu_mtn_are_cmip                                             -- 어린이보험유지계약CMIP금액
             , chld_iu_ivl_are_ct                                               -- 어린이보험실효계약건수
             , chld_iu_ivl_are_cmip                                             -- 어린이보험실효계약CMIP금액
             , chld_iu_insm_bil_ct                                              -- 어린이보험보험금청구건수
             , chld_iu_insm_bla                                                 -- 어린이보험보험금청구금액
             , chld_iu_et_alpy_ct                                               -- 어린이보험기타제지급건수
             , chld_iu_et_alpy_at                                               -- 어린이보험기타제지급금액
             , chld_iu_are_ln_ct                                                -- 어린이보험계약대출건수
             , chld_iu_are_lna                                                  -- 어린이보험계약대출금액
             , chld_iu_are_ln_al                                                -- 어린이보험계약대출잔액
             , pnz_svg_edu_iu_mtn_are_ct                                        -- 연금저축교육보험유지계약건수
             , pnz_svg_edu_iu_mtn_are_cmip                                      -- 연금저축교육보험유지계약CMIP금액
             , pnz_svg_edu_iu_ivl_are_ct                                        -- 연금저축교육보험실효계약건수
             , pnz_svg_edu_iu_ivl_are_cmip                                      -- 연금저축교육보험실효계약CMIP금액
             , pnz_svg_edu_iu_insm_bil_ct                                       -- 연금저축교육보험보험금청구건수
             , pnz_svg_edu_iu_insm_bla                                          -- 연금저축교육보험보험금청구금액
             , pnz_svg_edu_iu_pnz_ct                                            -- 연금저축교육보험연금건수
             , pnz_svg_edu_iu_pnz_at                                            -- 연금저축교육보험연금금액
             , pnz_svg_edu_iu_et_alpy_ct                                        -- 연금저축교육보험기타제지급건수
             , pnz_svg_edu_iu_et_alpy_at                                        -- 연금저축교육보험기타제지급금액
             , pnz_svg_edu_iu_are_ln_ct                                         -- 연금저축교육보험계약대출건수
             , pnz_svg_edu_iu_are_lna                                           -- 연금저축교육보험계약대출금액
             , pnz_svg_edu_iu_are_ln_al                                         -- 연금저축교육보험계약대출잔액
             , wli_mtn_are_ct                                                   -- 종신보험유지계약건수
             , wli_mtn_are_cmip                                                 -- 종신보험유지계약CMIP금액
             , wli_ivl_are_ct                                                   -- 종신보험실효계약건수
             , wli_ivl_are_cmip                                                 -- 종신보험실효계약CMIP금액
             , wli_insm_bil_ct                                                  -- 종신보험보험금청구건수
             , wli_insm_bla                                                     -- 종신보험보험금청구금액
             , wli_et_alpy_ct                                                   -- 종신보험기타제지급건수
             , wli_et_alpy_at                                                   -- 종신보험기타제지급금액
             , wli_are_ln_ct                                                    -- 종신보험계약대출건수
             , wli_are_lna                                                      -- 종신보험계약대출금액
             , wli_are_ln_al                                                    -- 종신보험계약대출잔액
             , ovl_iu_mtn_are_ct                                                -- 종합보험유지계약건수
             , ovl_iu_mtn_are_cmip                                              -- 종합보험유지계약CMIP금액
             , ovl_iu_ivl_are_ct                                                -- 종합보험실효계약건수
             , ovl_iu_ivl_are_cmip                                              -- 종합보험실효계약CMIP금액
             , ovl_iu_insm_bil_ct                                               -- 종합보험보험금청구건수
             , ovl_iu_insm_bla                                                  -- 종합보험보험금청구금액
             , ovl_iu_et_alpy_ct                                                -- 종합보험기타제지급건수
             , ovl_iu_et_alpy_at                                                -- 종합보험기타제지급금액
             , ovl_iu_are_ln_ct                                                 -- 종합보험계약대출건수
             , ovl_iu_are_lna                                                   -- 종합보험계약대출금액
             , ovl_iu_are_ln_al                                                 -- 종합보험계약대출잔액
             , vli_mtn_are_ct                                                   -- 변액보험유지계약건수
             , vli_mtn_are_cmip                                                 -- 변액보험유지계약CMIP금액
             , vli_ivl_are_ct                                                   -- 변액보험실효계약건수
             , vli_ivl_are_cmip                                                 -- 변액보험실효계약CMIP금액
             , vli_insm_bil_ct                                                  -- 변액보험보험금청구건수
             , vli_insm_bla                                                     -- 변액보험보험금청구금액
             , vli_et_alpy_ct                                                   -- 변액보험기타제지급건수
             , vli_et_alpy_at                                                   -- 변액보험기타제지급금액
             , vli_are_ln_ct                                                    -- 변액보험계약대출건수
             , vli_are_lna                                                      -- 변액보험계약대출금액
             , vli_are_ln_al                                                    -- 변액보험계약대출잔액
             , et_iu_mtn_are_ct                                                 -- 기타보험유지계약건수
             , et_iu_mtn_are_cmip                                               -- 기타보험유지계약CMIP금액
             , et_iu_ivl_are_ct                                                 -- 기타보험실효계약건수
             , et_iu_ivl_are_cmip                                               -- 기타보험실효계약CMIP금액
             , et_iu_insm_bil_ct                                                -- 기타보험보험금청구건수
             , et_iu_insm_bla                                                   -- 기타보험보험금청구금액
             , et_iu_et_alpy_ct                                                 -- 기타보험기타제지급건수
             , et_iu_et_alpy_at                                                 -- 기타보험기타제지급금액
             , et_iu_are_ln_ct                                                  -- 기타보험계약대출건수
             , et_iu_are_lna                                                    -- 기타보험계약대출금액
             , et_iu_are_ln_al                                                  -- 기타보험계약대출잔액
             , afl_iu_mtn_are_ct                                                -- 제휴보험유지계약건수
             , afl_iu_mtn_are_cmip                                              -- 제휴보험유지계약CMIP금액
             , afl_iu_ivl_are_ct                                                -- 제휴보험실효계약건수
             , afl_iu_ivl_are_cmip                                              -- 제휴보험실효계약CMIP금액
             , afl_iu_insm_bil_ct                                               -- 제휴보험보험금청구건수
             , afl_iu_insm_bla                                                  -- 제휴보험보험금청구금액
             , afl_iu_et_alpy_ct                                                -- 제휴보험기타제지급건수
             , afl_iu_et_alpy_at                                                -- 제휴보험기타제지급금액
             , afl_iu_are_ln_ct                                                 -- 제휴보험계약대출건수
             , afl_iu_are_lna                                                   -- 제휴보험계약대출금액
             , afl_iu_are_ln_al                                                 -- 제휴보험계약대출잔액
             , 0                                 as cre_ln_ct                  -- 신용대출건수
             , 0                                 as cre_lna                    -- 신용대출금액
             , 0                                 as cre_ln_al                  -- 신용대출잔액
             , 0                                 as esa_ll_ln_ct               -- 부동산담보대출건수
             , 0                                 as esa_ll_lna                 -- 부동산담보대출금액
             , 0                                 as esa_ll_ln_al               -- 부동산담보대출잔액
             , 0                                 as et_ll_ln_ct                -- 기타담보대출건수
             , 0                                 as et_ll_lna                  -- 기타담보대출금액
             , 0                                 as et_ll_ln_al                -- 기타담보대출잔액
          from tmp_sh2.shdmigd010_tmp01
         union all
        select ta_ym                                                            -- 기준년월
             , shmdn                                                            -- 그룹MD번호
             , 0                                 as iu_ase_at                   -- 보험자산금액
             , 0                                 as pnz_iu_al                   -- 연금보험잔액
             , 0                                 as iu_are_ln_al                -- 보험계약대출잔액
             , 0                                 as hlt_iu_mtn_are_ct           -- 건강보험유지계약건수
             , 0                                 as hlt_iu_mtn_are_cmip         -- 건강보험유지계약CMIP금액
             , 0                                 as hlt_iu_ivl_are_ct           -- 건강보험실효계약건수
             , 0                                 as hlt_iu_ivl_are_cmip         -- 건강보험실효계약CMIP금액
             , 0                                 as hlt_iu_insm_bil_ct          -- 건강보험보험금청구건수
             , 0                                 as hlt_iu_insm_bla             -- 건강보험보험금청구금액
             , 0                                 as hlt_iu_et_alpy_ct           -- 건강보험기타제지급건수
             , 0                                 as hlt_iu_et_alpy_at           -- 건강보험기타제지급금액
             , 0                                 as hlt_iu_are_ln_ct            -- 건강보험계약대출건수
             , 0                                 as hlt_iu_are_lna              -- 건강보험계약대출금액
             , 0                                 as hlt_iu_are_ln_al            -- 건강보험계약대출잔액
             , 0                                 as ijr_iu_mtn_are_ct           -- 상해보험유지계약건수
             , 0                                 as ijr_iu_mtn_are_cmip         -- 상해보험유지계약CMIP금액
             , 0                                 as ijr_iu_ivl_are_ct           -- 상해보험실효계약건수
             , 0                                 as ijr_iu_ivl_are_cmip         -- 상해보험실효계약CMIP금액
             , 0                                 as ijr_iu_insm_bil_ct          -- 상해보험보험금청구건수
             , 0                                 as ijr_iu_insm_bla             -- 상해보험보험금청구금액
             , 0                                 as ijr_iu_et_alpy_ct           -- 상해보험기타제지급건수
             , 0                                 as ijr_iu_et_alpy_at           -- 상해보험기타제지급금액
             , 0                                 as ijr_iu_are_ln_ct            -- 상해보험계약대출건수
             , 0                                 as ijr_iu_are_lna              -- 상해보험계약대출금액
             , 0                                 as ijr_iu_are_ln_al            -- 상해보험계약대출잔액
             , 0                                 as crag_iu_mtn_are_ct          -- 양로보험유지계약건수
             , 0                                 as crag_iu_mtn_are_cmip        -- 양로보험유지계약CMIP금액
             , 0                                 as crag_iu_ivl_are_ct          -- 양로보험실효계약건수
             , 0                                 as crag_iu_ivl_are_cmip        -- 양로보험실효계약CMIP금액
             , 0                                 as crag_iu_insm_bil_ct         -- 양로보험보험금청구건수
             , 0                                 as crag_iu_insm_bla            -- 양로보험보험금청구금액
             , 0                                 as crag_iu_et_alpy_ct          -- 양로보험기타제지급건수
             , 0                                 as crag_iu_et_alpy_at          -- 양로보험기타제지급금액
             , 0                                 as crag_iu_are_ln_ct           -- 양로보험계약대출건수
             , 0                                 as crag_iu_are_lna             -- 양로보험계약대출금액
             , 0                                 as crag_iu_are_ln_al           -- 양로보험계약대출잔액
             , 0                                 as chld_iu_mtn_are_ct          -- 어린이보험유지계약건수
             , 0                                 as chld_iu_mtn_are_cmip        -- 어린이보험유지계약CMIP금액
             , 0                                 as chld_iu_ivl_are_ct          -- 어린이보험실효계약건수
             , 0                                 as chld_iu_ivl_are_cmip        -- 어린이보험실효계약CMIP금액
             , 0                                 as chld_iu_insm_bil_ct         -- 어린이보험보험금청구건수
             , 0                                 as chld_iu_insm_bla            -- 어린이보험보험금청구금액
             , 0                                 as chld_iu_et_alpy_ct          -- 어린이보험기타제지급건수
             , 0                                 as chld_iu_et_alpy_at          -- 어린이보험기타제지급금액
             , 0                                 as chld_iu_are_ln_ct           -- 어린이보험계약대출건수
             , 0                                 as chld_iu_are_lna             -- 어린이보험계약대출금액
             , 0                                 as chld_iu_are_ln_al           -- 어린이보험계약대출잔액
             , 0                                 as pnz_svg_edu_iu_mtn_are_ct   -- 연금저축교육보험유지계약건수
             , 0                                 as pnz_svg_edu_iu_mtn_are_cmip -- 연금저축교육보험유지계약CMIP금액
             , 0                                 as pnz_svg_edu_iu_ivl_are_ct   -- 연금저축교육보험실효계약건수
             , 0                                 as pnz_svg_edu_iu_ivl_are_cmip -- 연금저축교육보험실효계약CMIP금액
             , 0                                 as pnz_svg_edu_iu_insm_bil_ct  -- 연금저축교육보험보험금청구건수
             , 0                                 as pnz_svg_edu_iu_insm_bla     -- 연금저축교육보험보험금청구금액
             , 0                                 as pnz_svg_edu_iu_pnz_ct       -- 연금저축교육보험연금건수
             , 0                                 as pnz_svg_edu_iu_pnz_at       -- 연금저축교육보험연금금액
             , 0                                 as pnz_svg_edu_iu_et_alpy_ct   -- 연금저축교육보험기타제지급건수
             , 0                                 as pnz_svg_edu_iu_et_alpy_at   -- 연금저축교육보험기타제지급금액
             , 0                                 as pnz_svg_edu_iu_are_ln_ct    -- 연금저축교육보험계약대출건수
             , 0                                 as pnz_svg_edu_iu_are_lna      -- 연금저축교육보험계약대출금액
             , 0                                 as pnz_svg_edu_iu_are_ln_al    -- 연금저축교육보험계약대출잔액
             , 0                                 as wli_mtn_are_ct              -- 종신보험유지계약건수
             , 0                                 as wli_mtn_are_cmip            -- 종신보험유지계약CMIP금액
             , 0                                 as wli_ivl_are_ct              -- 종신보험실효계약건수
             , 0                                 as wli_ivl_are_cmip            -- 종신보험실효계약CMIP금액
             , 0                                 as wli_insm_bil_ct             -- 종신보험보험금청구건수
             , 0                                 as wli_insm_bla                -- 종신보험보험금청구금액
             , 0                                 as wli_et_alpy_ct              -- 종신보험기타제지급건수
             , 0                                 as wli_et_alpy_at              -- 종신보험기타제지급금액
             , 0                                 as wli_are_ln_ct               -- 종신보험계약대출건수
             , 0                                 as wli_are_lna                 -- 종신보험계약대출금액
             , 0                                 as wli_are_ln_al               -- 종신보험계약대출잔액
             , 0                                 as ovl_iu_mtn_are_ct           -- 종합보험유지계약건수
             , 0                                 as ovl_iu_mtn_are_cmip         -- 종합보험유지계약CMIP금액
             , 0                                 as ovl_iu_ivl_are_ct           -- 종합보험실효계약건수
             , 0                                 as ovl_iu_ivl_are_cmip         -- 종합보험실효계약CMIP금액
             , 0                                 as ovl_iu_insm_bil_ct          -- 종합보험보험금청구건수
             , 0                                 as ovl_iu_insm_bla             -- 종합보험보험금청구금액
             , 0                                 as ovl_iu_et_alpy_ct           -- 종합보험기타제지급건수
             , 0                                 as ovl_iu_et_alpy_at           -- 종합보험기타제지급금액
             , 0                                 as ovl_iu_are_ln_ct            -- 종합보험계약대출건수
             , 0                                 as ovl_iu_are_lna              -- 종합보험계약대출금액
             , 0                                 as ovl_iu_are_ln_al            -- 종합보험계약대출잔액
             , 0                                 as vli_mtn_are_ct              -- 변액보험유지계약건수
             , 0                                 as vli_mtn_are_cmip            -- 변액보험유지계약CMIP금액
             , 0                                 as vli_ivl_are_ct              -- 변액보험실효계약건수
             , 0                                 as vli_ivl_are_cmip            -- 변액보험실효계약CMIP금액
             , 0                                 as vli_insm_bil_ct             -- 변액보험보험금청구건수
             , 0                                 as vli_insm_bla                -- 변액보험보험금청구금액
             , 0                                 as vli_et_alpy_ct              -- 변액보험기타제지급건수
             , 0                                 as vli_et_alpy_at              -- 변액보험기타제지급금액
             , 0                                 as vli_are_ln_ct               -- 변액보험계약대출건수
             , 0                                 as vli_are_lna                 -- 변액보험계약대출금액
             , 0                                 as vli_are_ln_al               -- 변액보험계약대출잔액
             , 0                                 as et_iu_mtn_are_ct            -- 기타보험유지계약건수
             , 0                                 as et_iu_mtn_are_cmip          -- 기타보험유지계약CMIP금액
             , 0                                 as et_iu_ivl_are_ct            -- 기타보험실효계약건수
             , 0                                 as et_iu_ivl_are_cmip          -- 기타보험실효계약CMIP금액
             , 0                                 as et_iu_insm_bil_ct           -- 기타보험보험금청구건수
             , 0                                 as et_iu_insm_bla              -- 기타보험보험금청구금액
             , 0                                 as et_iu_et_alpy_ct            -- 기타보험기타제지급건수
             , 0                                 as et_iu_et_alpy_at            -- 기타보험기타제지급금액
             , 0                                 as et_iu_are_ln_ct             -- 기타보험계약대출건수
             , 0                                 as et_iu_are_lna               -- 기타보험계약대출금액
             , 0                                 as et_iu_are_ln_al             -- 기타보험계약대출잔액
             , 0                                 as afl_iu_mtn_are_ct           -- 제휴보험유지계약건수
             , 0                                 as afl_iu_mtn_are_cmip         -- 제휴보험유지계약CMIP금액
             , 0                                 as afl_iu_ivl_are_ct           -- 제휴보험실효계약건수
             , 0                                 as afl_iu_ivl_are_cmip         -- 제휴보험실효계약CMIP금액
             , 0                                 as afl_iu_insm_bil_ct          -- 제휴보험보험금청구건수
             , 0                                 as afl_iu_insm_bla             -- 제휴보험보험금청구금액
             , 0                                 as afl_iu_et_alpy_ct           -- 제휴보험기타제지급건수
             , 0                                 as afl_iu_et_alpy_at           -- 제휴보험기타제지급금액
             , 0                                 as afl_iu_are_ln_ct            -- 제휴보험계약대출건수
             , 0                                 as afl_iu_are_lna              -- 제휴보험계약대출금액
             , 0                                 as afl_iu_are_ln_al            -- 제휴보험계약대출잔액
             , cre_ln_ct                                                        -- 신용대출건수
             , cre_lna                                                          -- 신용대출금액
             , cre_ln_al                                                        -- 신용대출잔액
             , esa_ll_ln_ct                                                     -- 부동산담보대출건수
             , esa_ll_lna                                                       -- 부동산담보대출금액
             , esa_ll_ln_al                                                     -- 부동산담보대출잔액
             , et_ll_ln_ct                                                      -- 기타담보대출건수
             , et_ll_lna                                                        -- 기타담보대출금액
             , et_ll_ln_al                                                      -- 기타담보대출잔액
          from tmp_sh2.shdmigd010_tmp02
       ) t10
   group by ta_ym                                  -- 기준년월
          , shmdn                                  -- 그룹MD번호
"""

"""
(@) tmp_sh2 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""                     
insert_sql_for_tmp = [insert_sql_for_tmp_1,insert_sql_for_tmp_2]

""" 
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmigd010_tmp99', 'pk': ['ta_ym', 'shmdn']}
}

"""
(@) SH2 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmigd010
    where ta_ym = '{date_cd('P_TA_YM')}'
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shdmigd010
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , iu_ase_at                              -- 보험자산금액
         , pnz_iu_al                              -- 연금보험잔액
         , iu_are_ln_al                           -- 보험계약대출잔액
         , hlt_iu_mtn_are_ct                      -- 건강보험유지계약건수
         , hlt_iu_mtn_are_cmip                    -- 건강보험유지계약CMIP금액
         , hlt_iu_ivl_are_ct                      -- 건강보험실효계약건수
         , hlt_iu_ivl_are_cmip                    -- 건강보험실효계약CMIP금액
         , hlt_iu_insm_bil_ct                     -- 건강보험보험금청구건수
         , hlt_iu_insm_bla                        -- 건강보험보험금청구금액
         , hlt_iu_et_alpy_ct                      -- 건강보험기타제지급건수
         , hlt_iu_et_alpy_at                      -- 건강보험기타제지급금액
         , hlt_iu_are_ln_ct                       -- 건강보험계약대출건수
         , hlt_iu_are_lna                         -- 건강보험계약대출금액
         , hlt_iu_are_ln_al                       -- 건강보험계약대출잔액
         , ijr_iu_mtn_are_ct                      -- 상해보험유지계약건수
         , ijr_iu_mtn_are_cmip                    -- 상해보험유지계약CMIP금액
         , ijr_iu_ivl_are_ct                      -- 상해보험실효계약건수
         , ijr_iu_ivl_are_cmip                    -- 상해보험실효계약CMIP금액
         , ijr_iu_insm_bil_ct                     -- 상해보험보험금청구건수
         , ijr_iu_insm_bla                        -- 상해보험보험금청구금액
         , ijr_iu_et_alpy_ct                      -- 상해보험기타제지급건수
         , ijr_iu_et_alpy_at                      -- 상해보험기타제지급금액
         , ijr_iu_are_ln_ct                       -- 상해보험계약대출건수
         , ijr_iu_are_lna                         -- 상해보험계약대출금액
         , ijr_iu_are_ln_al                       -- 상해보험계약대출잔액
         , crag_iu_mtn_are_ct                     -- 양로보험유지계약건수
         , crag_iu_mtn_are_cmip                   -- 양로보험유지계약CMIP금액
         , crag_iu_ivl_are_ct                     -- 양로보험실효계약건수
         , crag_iu_ivl_are_cmip                   -- 양로보험실효계약CMIP금액
         , crag_iu_insm_bil_ct                    -- 양로보험보험금청구건수
         , crag_iu_insm_bla                       -- 양로보험보험금청구금액
         , crag_iu_et_alpy_ct                     -- 양로보험기타제지급건수
         , crag_iu_et_alpy_at                     -- 양로보험기타제지급금액
         , crag_iu_are_ln_ct                      -- 양로보험계약대출건수
         , crag_iu_are_lna                        -- 양로보험계약대출금액
         , crag_iu_are_ln_al                      -- 양로보험계약대출잔액
         , chld_iu_mtn_are_ct                     -- 어린이보험유지계약건수
         , chld_iu_mtn_are_cmip                   -- 어린이보험유지계약CMIP금액
         , chld_iu_ivl_are_ct                     -- 어린이보험실효계약건수
         , chld_iu_ivl_are_cmip                   -- 어린이보험실효계약CMIP금액
         , chld_iu_insm_bil_ct                    -- 어린이보험보험금청구건수
         , chld_iu_insm_bla                       -- 어린이보험보험금청구금액
         , chld_iu_et_alpy_ct                     -- 어린이보험기타제지급건수
         , chld_iu_et_alpy_at                     -- 어린이보험기타제지급금액
         , chld_iu_are_ln_ct                      -- 어린이보험계약대출건수
         , chld_iu_are_lna                        -- 어린이보험계약대출금액
         , chld_iu_are_ln_al                      -- 어린이보험계약대출잔액
         , pnz_svg_edu_iu_mtn_are_ct              -- 연금저축교육보험유지계약건수
         , pnz_svg_edu_iu_mtn_are_cmip            -- 연금저축교육보험유지계약CMIP금액
         , pnz_svg_edu_iu_ivl_are_ct              -- 연금저축교육보험실효계약건수
         , pnz_svg_edu_iu_ivl_are_cmip            -- 연금저축교육보험실효계약CMIP금액
         , pnz_svg_edu_iu_insm_bil_ct             -- 연금저축교육보험보험금청구건수
         , pnz_svg_edu_iu_insm_bla                -- 연금저축교육보험보험금청구금액
         , pnz_svg_edu_iu_pnz_ct                  -- 연금저축교육보험연금건수
         , pnz_svg_edu_iu_pnz_at                  -- 연금저축교육보험연금금액
         , pnz_svg_edu_iu_et_alpy_ct              -- 연금저축교육보험기타제지급건수
         , pnz_svg_edu_iu_et_alpy_at              -- 연금저축교육보험기타제지급금액
         , pnz_svg_edu_iu_are_ln_ct               -- 연금저축교육보험계약대출건수
         , pnz_svg_edu_iu_are_lna                 -- 연금저축교육보험계약대출금액
         , pnz_svg_edu_iu_are_ln_al               -- 연금저축교육보험계약대출잔액
         , wli_mtn_are_ct                         -- 종신보험유지계약건수
         , wli_mtn_are_cmip                       -- 종신보험유지계약CMIP금액
         , wli_ivl_are_ct                         -- 종신보험실효계약건수
         , wli_ivl_are_cmip                       -- 종신보험실효계약CMIP금액
         , wli_insm_bil_ct                        -- 종신보험보험금청구건수
         , wli_insm_bla                           -- 종신보험보험금청구금액
         , wli_et_alpy_ct                         -- 종신보험기타제지급건수
         , wli_et_alpy_at                         -- 종신보험기타제지급금액
         , wli_are_ln_ct                          -- 종신보험계약대출건수
         , wli_are_lna                            -- 종신보험계약대출금액
         , wli_are_ln_al                          -- 종신보험계약대출잔액
         , ovl_iu_mtn_are_ct                      -- 종합보험유지계약건수
         , ovl_iu_mtn_are_cmip                    -- 종합보험유지계약CMIP금액
         , ovl_iu_ivl_are_ct                      -- 종합보험실효계약건수
         , ovl_iu_ivl_are_cmip                    -- 종합보험실효계약CMIP금액
         , ovl_iu_insm_bil_ct                     -- 종합보험보험금청구건수
         , ovl_iu_insm_bla                        -- 종합보험보험금청구금액
         , ovl_iu_et_alpy_ct                      -- 종합보험기타제지급건수
         , ovl_iu_et_alpy_at                      -- 종합보험기타제지급금액
         , ovl_iu_are_ln_ct                       -- 종합보험계약대출건수
         , ovl_iu_are_lna                         -- 종합보험계약대출금액
         , ovl_iu_are_ln_al                       -- 종합보험계약대출잔액
         , vli_mtn_are_ct                         -- 변액보험유지계약건수
         , vli_mtn_are_cmip                       -- 변액보험유지계약CMIP금액
         , vli_ivl_are_ct                         -- 변액보험실효계약건수
         , vli_ivl_are_cmip                       -- 변액보험실효계약CMIP금액
         , vli_insm_bil_ct                        -- 변액보험보험금청구건수
         , vli_insm_bla                           -- 변액보험보험금청구금액
         , vli_et_alpy_ct                         -- 변액보험기타제지급건수
         , vli_et_alpy_at                         -- 변액보험기타제지급금액
         , vli_are_ln_ct                          -- 변액보험계약대출건수
         , vli_are_lna                            -- 변액보험계약대출금액
         , vli_are_ln_al                          -- 변액보험계약대출잔액
         , et_iu_mtn_are_ct                       -- 기타보험유지계약건수
         , et_iu_mtn_are_cmip                     -- 기타보험유지계약CMIP금액
         , et_iu_ivl_are_ct                       -- 기타보험실효계약건수
         , et_iu_ivl_are_cmip                     -- 기타보험실효계약CMIP금액
         , et_iu_insm_bil_ct                      -- 기타보험보험금청구건수
         , et_iu_insm_bla                         -- 기타보험보험금청구금액
         , et_iu_et_alpy_ct                       -- 기타보험기타제지급건수
         , et_iu_et_alpy_at                       -- 기타보험기타제지급금액
         , et_iu_are_ln_ct                        -- 기타보험계약대출건수
         , et_iu_are_lna                          -- 기타보험계약대출금액
         , et_iu_are_ln_al                        -- 기타보험계약대출잔액
         , afl_iu_mtn_are_ct                      -- 제휴보험유지계약건수
         , afl_iu_mtn_are_cmip                    -- 제휴보험유지계약CMIP금액
         , afl_iu_ivl_are_ct                      -- 제휴보험실효계약건수
         , afl_iu_ivl_are_cmip                    -- 제휴보험실효계약CMIP금액
         , afl_iu_insm_bil_ct                     -- 제휴보험보험금청구건수
         , afl_iu_insm_bla                        -- 제휴보험보험금청구금액
         , afl_iu_et_alpy_ct                      -- 제휴보험기타제지급건수
         , afl_iu_et_alpy_at                      -- 제휴보험기타제지급금액
         , afl_iu_are_ln_ct                       -- 제휴보험계약대출건수
         , afl_iu_are_lna                         -- 제휴보험계약대출금액
         , afl_iu_are_ln_al                       -- 제휴보험계약대출잔액
         , cre_ln_ct                              -- 신용대출건수
         , cre_lna                                -- 신용대출금액
         , cre_ln_al                              -- 신용대출잔액
         , esa_ll_ln_ct                           -- 부동산담보대출건수
         , esa_ll_lna                             -- 부동산담보대출금액
         , esa_ll_ln_al                           -- 부동산담보대출잔액
         , et_ll_ln_ct                            -- 기타담보대출건수
         , et_ll_lna                              -- 기타담보대출금액
         , et_ll_ln_al                            -- 기타담보대출잔액
         )
    select ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , iu_ase_at                              -- 보험자산금액
         , pnz_iu_al                              -- 연금보험잔액
         , iu_are_ln_al                           -- 보험계약대출잔액
         , hlt_iu_mtn_are_ct                      -- 건강보험유지계약건수
         , hlt_iu_mtn_are_cmip                    -- 건강보험유지계약CMIP금액
         , hlt_iu_ivl_are_ct                      -- 건강보험실효계약건수
         , hlt_iu_ivl_are_cmip                    -- 건강보험실효계약CMIP금액
         , hlt_iu_insm_bil_ct                     -- 건강보험보험금청구건수
         , hlt_iu_insm_bla                        -- 건강보험보험금청구금액
         , hlt_iu_et_alpy_ct                      -- 건강보험기타제지급건수
         , hlt_iu_et_alpy_at                      -- 건강보험기타제지급금액
         , hlt_iu_are_ln_ct                       -- 건강보험계약대출건수
         , hlt_iu_are_lna                         -- 건강보험계약대출금액
         , hlt_iu_are_ln_al                       -- 건강보험계약대출잔액
         , ijr_iu_mtn_are_ct                      -- 상해보험유지계약건수
         , ijr_iu_mtn_are_cmip                    -- 상해보험유지계약CMIP금액
         , ijr_iu_ivl_are_ct                      -- 상해보험실효계약건수
         , ijr_iu_ivl_are_cmip                    -- 상해보험실효계약CMIP금액
         , ijr_iu_insm_bil_ct                     -- 상해보험보험금청구건수
         , ijr_iu_insm_bla                        -- 상해보험보험금청구금액
         , ijr_iu_et_alpy_ct                      -- 상해보험기타제지급건수
         , ijr_iu_et_alpy_at                      -- 상해보험기타제지급금액
         , ijr_iu_are_ln_ct                       -- 상해보험계약대출건수
         , ijr_iu_are_lna                         -- 상해보험계약대출금액
         , ijr_iu_are_ln_al                       -- 상해보험계약대출잔액
         , crag_iu_mtn_are_ct                     -- 양로보험유지계약건수
         , crag_iu_mtn_are_cmip                   -- 양로보험유지계약CMIP금액
         , crag_iu_ivl_are_ct                     -- 양로보험실효계약건수
         , crag_iu_ivl_are_cmip                   -- 양로보험실효계약CMIP금액
         , crag_iu_insm_bil_ct                    -- 양로보험보험금청구건수
         , crag_iu_insm_bla                       -- 양로보험보험금청구금액
         , crag_iu_et_alpy_ct                     -- 양로보험기타제지급건수
         , crag_iu_et_alpy_at                     -- 양로보험기타제지급금액
         , crag_iu_are_ln_ct                      -- 양로보험계약대출건수
         , crag_iu_are_lna                        -- 양로보험계약대출금액
         , crag_iu_are_ln_al                      -- 양로보험계약대출잔액
         , chld_iu_mtn_are_ct                     -- 어린이보험유지계약건수
         , chld_iu_mtn_are_cmip                   -- 어린이보험유지계약CMIP금액
         , chld_iu_ivl_are_ct                     -- 어린이보험실효계약건수
         , chld_iu_ivl_are_cmip                   -- 어린이보험실효계약CMIP금액
         , chld_iu_insm_bil_ct                    -- 어린이보험보험금청구건수
         , chld_iu_insm_bla                       -- 어린이보험보험금청구금액
         , chld_iu_et_alpy_ct                     -- 어린이보험기타제지급건수
         , chld_iu_et_alpy_at                     -- 어린이보험기타제지급금액
         , chld_iu_are_ln_ct                      -- 어린이보험계약대출건수
         , chld_iu_are_lna                        -- 어린이보험계약대출금액
         , chld_iu_are_ln_al                      -- 어린이보험계약대출잔액
         , pnz_svg_edu_iu_mtn_are_ct              -- 연금저축교육보험유지계약건수
         , pnz_svg_edu_iu_mtn_are_cmip            -- 연금저축교육보험유지계약CMIP금액
         , pnz_svg_edu_iu_ivl_are_ct              -- 연금저축교육보험실효계약건수
         , pnz_svg_edu_iu_ivl_are_cmip            -- 연금저축교육보험실효계약CMIP금액
         , pnz_svg_edu_iu_insm_bil_ct             -- 연금저축교육보험보험금청구건수
         , pnz_svg_edu_iu_insm_bla                -- 연금저축교육보험보험금청구금액
         , pnz_svg_edu_iu_pnz_ct                  -- 연금저축교육보험연금건수
         , pnz_svg_edu_iu_pnz_at                  -- 연금저축교육보험연금금액
         , pnz_svg_edu_iu_et_alpy_ct              -- 연금저축교육보험기타제지급건수
         , pnz_svg_edu_iu_et_alpy_at              -- 연금저축교육보험기타제지급금액
         , pnz_svg_edu_iu_are_ln_ct               -- 연금저축교육보험계약대출건수
         , pnz_svg_edu_iu_are_lna                 -- 연금저축교육보험계약대출금액
         , pnz_svg_edu_iu_are_ln_al               -- 연금저축교육보험계약대출잔액
         , wli_mtn_are_ct                         -- 종신보험유지계약건수
         , wli_mtn_are_cmip                       -- 종신보험유지계약CMIP금액
         , wli_ivl_are_ct                         -- 종신보험실효계약건수
         , wli_ivl_are_cmip                       -- 종신보험실효계약CMIP금액
         , wli_insm_bil_ct                        -- 종신보험보험금청구건수
         , wli_insm_bla                           -- 종신보험보험금청구금액
         , wli_et_alpy_ct                         -- 종신보험기타제지급건수
         , wli_et_alpy_at                         -- 종신보험기타제지급금액
         , wli_are_ln_ct                          -- 종신보험계약대출건수
         , wli_are_lna                            -- 종신보험계약대출금액
         , wli_are_ln_al                          -- 종신보험계약대출잔액
         , ovl_iu_mtn_are_ct                      -- 종합보험유지계약건수
         , ovl_iu_mtn_are_cmip                    -- 종합보험유지계약CMIP금액
         , ovl_iu_ivl_are_ct                      -- 종합보험실효계약건수
         , ovl_iu_ivl_are_cmip                    -- 종합보험실효계약CMIP금액
         , ovl_iu_insm_bil_ct                     -- 종합보험보험금청구건수
         , ovl_iu_insm_bla                        -- 종합보험보험금청구금액
         , ovl_iu_et_alpy_ct                      -- 종합보험기타제지급건수
         , ovl_iu_et_alpy_at                      -- 종합보험기타제지급금액
         , ovl_iu_are_ln_ct                       -- 종합보험계약대출건수
         , ovl_iu_are_lna                         -- 종합보험계약대출금액
         , ovl_iu_are_ln_al                       -- 종합보험계약대출잔액
         , vli_mtn_are_ct                         -- 변액보험유지계약건수
         , vli_mtn_are_cmip                       -- 변액보험유지계약CMIP금액
         , vli_ivl_are_ct                         -- 변액보험실효계약건수
         , vli_ivl_are_cmip                       -- 변액보험실효계약CMIP금액
         , vli_insm_bil_ct                        -- 변액보험보험금청구건수
         , vli_insm_bla                           -- 변액보험보험금청구금액
         , vli_et_alpy_ct                         -- 변액보험기타제지급건수
         , vli_et_alpy_at                         -- 변액보험기타제지급금액
         , vli_are_ln_ct                          -- 변액보험계약대출건수
         , vli_are_lna                            -- 변액보험계약대출금액
         , vli_are_ln_al                          -- 변액보험계약대출잔액
         , et_iu_mtn_are_ct                       -- 기타보험유지계약건수
         , et_iu_mtn_are_cmip                     -- 기타보험유지계약CMIP금액
         , et_iu_ivl_are_ct                       -- 기타보험실효계약건수
         , et_iu_ivl_are_cmip                     -- 기타보험실효계약CMIP금액
         , et_iu_insm_bil_ct                      -- 기타보험보험금청구건수
         , et_iu_insm_bla                         -- 기타보험보험금청구금액
         , et_iu_et_alpy_ct                       -- 기타보험기타제지급건수
         , et_iu_et_alpy_at                       -- 기타보험기타제지급금액
         , et_iu_are_ln_ct                        -- 기타보험계약대출건수
         , et_iu_are_lna                          -- 기타보험계약대출금액
         , et_iu_are_ln_al                        -- 기타보험계약대출잔액
         , afl_iu_mtn_are_ct                      -- 제휴보험유지계약건수
         , afl_iu_mtn_are_cmip                    -- 제휴보험유지계약CMIP금액
         , afl_iu_ivl_are_ct                      -- 제휴보험실효계약건수
         , afl_iu_ivl_are_cmip                    -- 제휴보험실효계약CMIP금액
         , afl_iu_insm_bil_ct                     -- 제휴보험보험금청구건수
         , afl_iu_insm_bla                        -- 제휴보험보험금청구금액
         , afl_iu_et_alpy_ct                      -- 제휴보험기타제지급건수
         , afl_iu_et_alpy_at                      -- 제휴보험기타제지급금액
         , afl_iu_are_ln_ct                       -- 제휴보험계약대출건수
         , afl_iu_are_lna                         -- 제휴보험계약대출금액
         , afl_iu_are_ln_al                       -- 제휴보험계약대출잔액
         , cre_ln_ct                              -- 신용대출건수
         , cre_lna                                -- 신용대출금액
         , cre_ln_al                              -- 신용대출잔액
         , esa_ll_ln_ct                           -- 부동산담보대출건수
         , esa_ll_lna                             -- 부동산담보대출금액
         , esa_ll_ln_al                           -- 부동산담보대출잔액
         , et_ll_ln_ct                            -- 기타담보대출건수
         , et_ll_lna                              -- 기타담보대출금액
         , et_ll_ln_al                            -- 기타담보대출잔액
      from tmp_sh2.shdmigd010_tmp99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]
### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh2_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_2 = RedshiftQueryOperator(
        task_id='003_tmp_load_task_3',
        execute_query=insert_sql_for_tmp_3,
    )
    
    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    tmp_pk_valid_task = RedshiftPkValidOperator(
        task_id='004_tmp_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='005_sh2_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='006_sh2_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_2 >> tmp_load_task_end >> tmp_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end
