# -*- coding: utf-8 -*-

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *

__author__     = "이일주"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["이일주"]
__version__    = "1.0"
__maintainer__ = "이일주"
__email__      = "LEE1122334@xgm.co.kr"
__status__     = "Production"

"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID  : IBTM_SHDMIGD009_TG
  - 한글 테이블명: IGD_월고객거래실적_금투
  - tmp_sh2 테이블명: tmp_sh2.shdmigd009_tmp99
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMIGD009_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = 'IGD_월고객거래실적_금투'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

##날짜변수 사용관련 
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) tmp_sh2 테이블명 (TRUNCATE 대상)
"""
tmp_sh2_table = ['shdmigd009_tmp99']

"""
(@) tmp_sh2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmigd009_tmp99
         (
           ta_ym                            -- 기준년월
         , shmdn                            -- 그룹MD번호
         , to_ase_at                        -- 총자산금액
         , pot_scu_ase_at                   -- 지분증권자산금액
         , eb_scu_ase_at                    -- 채무증권자산금액
         , eni_scu_ase_at                   -- 수익증권자산금액
         , ivs_are_scu_ase_at               -- 투자계약증권자산금액
         , drb_cmb_scu_ase_at               -- 파생결합증권자산금액
         , scu_msd_scu_ase_at               -- 증권예탁증권자산금액
         , mrp_ts_ct                        -- 입출금거래건수
         , sar_ts_ct                        -- 입출고거래건수
         , rcp_ct                           -- 입금건수
         , siw_ct                           -- 입고건수
         , aow_ct                           -- 출금건수
         , tow_ct                           -- 출고건수
         , mrp_ts_at                        -- 입출금거래금액
         , sar_ts_at                        -- 입출고거래금액
         , rca                              -- 입금금액
         , siw_at                           -- 입고금액
         , aow_at                           -- 출금금액
         , tow_at                           -- 출고금액
         , scu_ts_ct                        -- 증권거래건수
         , m3_scu_ts_ct                     -- 3개월증권거래건수
         , m6_scu_ts_ct                     -- 6개월증권거래건수
         , m12_scu_ts_ct                    -- 12개월증권거래건수
         )
    -- 월고객거래금투
    select substring(proc_ymd,1,6)          as ta_ym                 -- 기준년월
         , grp_md_no                        as shmdn                 -- 그룹MD번호
         , sum(endbal_evlt_amt)             as to_ase_at             -- 총자산금액
         , sum(shar_secr_evlt_amt)          as pot_scu_ase_at        -- 지분증권자산금액
         , sum(libt_secr_evlt_amt)          as eb_scu_ase_at         -- 채무증권자산금액
         , sum(bncert_evlt_amt)             as eni_scu_ase_at        -- 수익증권자산금액
         , sum(invt_cntc_secr_evlt_amt)     as ivs_are_scu_ase_at    -- 투자계약증권자산금액
         , sum(drv_join_secr_evlt_amt)      as drb_cmb_scu_ase_at    -- 파생결합증권자산금액
         , sum(secr_dpst_secr_evlt_amt)     as scu_msd_scu_ase_at    -- 증권예탁증권자산금액
         , 0                                as mrp_ts_ct             -- 입출금거래건수
         , 0                                as sar_ts_ct             -- 입출고거래건수
         , 0                                as rcp_ct                -- 입금건수
         , 0                                as siw_ct                -- 입고건수
         , 0                                as aow_ct                -- 출금건수
         , 0                                as tow_ct                -- 출고건수
         , 0                                as mrp_ts_at             -- 입출금거래금액
         , 0                                as sar_ts_at             -- 입출고거래금액
         , 0                                as rca                   -- 입금금액
         , 0                                as siw_at                -- 입고금액
         , 0                                as aow_at                -- 출금금액
         , 0                                as tow_at                -- 출고금액
         , 0                                as scu_ts_ct             -- 증권거래건수
         , 0                                as m3_scu_ts_ct          -- 3개월증권거래건수
         , 0                                as m6_scu_ts_ct          -- 6개월증권거래건수
         , 0                                as m12_scu_ts_ct         -- 12개월증권거래건수
      from shi.jdc201s00           -- /*그룹데이터댐_계좌자산현황*/
     where proc_ymd = {execution_kst}
     group by substring(proc_ymd,1,6)
            , grp_md_no
     union all
    select substring(base_ymd,1,6)          as ta_ym                 -- 기준년월
         , grp_md_no                        as shmdn                 -- 그룹MD번호
         , 0                                as to_ase_at             -- 총자산금액
         , 0                                as pot_scu_ase_at        -- 지분증권자산금액
         , 0                                as eb_scu_ase_at         -- 채무증권자산금액
         , 0                                as eni_scu_ase_at        -- 수익증권자산금액
         , 0                                as ivs_are_scu_ase_at    -- 투자계약증권자산금액
         , 0                                as drb_cmb_scu_ase_at    -- 파생결합증권자산금액
         , 0                                as scu_msd_scu_ase_at    -- 증권예탁증권자산금액
         , count(case when ioms_tp_code in (1,2)
                      then grp_md_no
                  end)                      as mrp_ts_ct             -- 입출금거래건수
         , count(case when ioms_tp_code in (4,5)
                      then grp_md_no
                  end)                      as sar_ts_ct             -- 입출고거래건수
         , count(case when ioms_tp_code in (1)
                      then grp_md_no
                  end)                      as rcp_ct                -- 입금건수
         , count(case when ioms_tp_code in (4)
                      then grp_md_no
                  end)                      as siw_ct                -- 입고건수
         , count(case when ioms_tp_code in (2)
                      then grp_md_no
                  end)                      as aow_ct                -- 출금건수
         , count(case when ioms_tp_code in (5)
                      then grp_md_no
                  end)                      as tow_ct                -- 출고건수
         , sum(case when ioms_tp_code in (1,2)
                    then sum_amt
                end)                        as mrp_ts_at             -- 입출금거래금액
         , sum(case when ioms_tp_code in (4,5)
                    then sum_amt
                end)                        as sar_ts_at             -- 입출고거래금액
         , sum(case when ioms_tp_code in (1)
                    then sum_amt
                end)                        as rca                   -- 입금금액
         , sum(case when ioms_tp_code in (4)
                    then sum_amt
                end)                        as siw_at                -- 입고금액
         , sum(case when ioms_tp_code in (2)
                    then sum_amt
                end)                        as aow_at                -- 출금금액
         , sum(case when ioms_tp_code in (5)
                    then sum_amt
                end)                        as tow_at                -- 출고금액
         , 0                                as scu_ts_ct             -- 증권거래건수
         , 0                                as m3_scu_ts_ct          -- 3개월증권거래건수
         , 0                                as m6_scu_ts_ct          -- 6개월증권거래건수
         , 0                                as m12_scu_ts_ct         -- 12개월증권거래건수
      from shi.raa218s01
     where base_ymd = {execution_kst}
     group by substring(base_ymd,1,6)
            , grp_md_no
     union all
    select substring(base_ymd,1,6)          as ta_ym                 -- 기준년월
         , grp_md_no                        as shmdn                 -- 그룹MD번호
         , 0                                as to_ase_at             -- 총자산금액
         , 0                                as pot_scu_ase_at        -- 지분증권자산금액
         , 0                                as eb_scu_ase_at         -- 채무증권자산금액
         , 0                                as eni_scu_ase_at        -- 수익증권자산금액
         , 0                                as ivs_are_scu_ase_at    -- 투자계약증권자산금액
         , 0                                as drb_cmb_scu_ase_at    -- 파생결합증권자산금액
         , 0                                as scu_msd_scu_ase_at    -- 증권예탁증권자산금액
         , 0                                as mrp_ts_ct             -- 입출금거래건수
         , 0                                as sar_ts_ct             -- 입출고거래건수
         , 0                                as rcp_ct                -- 입금건수
         , 0                                as siw_ct                -- 입고건수
         , 0                                as aow_ct                -- 출금건수
         , 0                                as tow_ct                -- 출고건수
         , 0                                as mrp_ts_at             -- 입출금거래금액
         , 0                                as sar_ts_at             -- 입출고거래금액
         , 0                                as rca                   -- 입금금액
         , 0                                as siw_at                -- 입고금액
         , 0                                as aow_at                -- 출금금액
         , 0                                as tow_at                -- 출고금액
         , sum(m1_secr_deal_numt)           as scu_ts_ct             -- 증권거래건수
         , sum(m3_secr_deal_numt)           as m3_scu_ts_ct          -- 3개월증권거래건수
         , sum(m6_secr_deal_numt)           as m6_scu_ts_ct          -- 6개월증권거래건수
         , sum(y1_secr_deal_numt)           as m12_scu_ts_ct         -- 12개월증권거래건수
      from shi.jdc203s00 /*그룹데이터댐_계좌거래현황*/
     where base_ymd = {execution_kst}
     group by substring(base_ymd,1,6)
            , grp_md_no
"""

"""
(@) tmp_sh2 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""                     
insert_sql_for_tmp = [insert_sql_for_tmp_1]

""" 
(@) TMP_SH2 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmigd009_tmp99', 'pk': ['ta_ym', 'shmdn']}
}

"""
(@) SH2 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmigd009
    where ta_ym = '{date_cd('P_TA_YM')}'
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shdmigd009
         (
           ta_ym                            -- 기준년월
         , shmdn                            -- 그룹MD번호
         , aws_ld_dt                        -- AWS적재일시
         , to_ase_at                        -- 총자산금액
         , pot_scu_ase_at                   -- 지분증권자산금액
         , eb_scu_ase_at                    -- 채무증권자산금액
         , eni_scu_ase_at                   -- 수익증권자산금액
         , ivs_are_scu_ase_at               -- 투자계약증권자산금액
         , drb_cmb_scu_ase_at               -- 파생결합증권자산금액
         , scu_msd_scu_ase_at               -- 증권예탁증권자산금액
         , mrp_ts_ct                        -- 입출금거래건수
         , sar_ts_ct                        -- 입출고거래건수
         , rcp_ct                           -- 입금건수
         , siw_ct                           -- 입고건수
         , aow_ct                           -- 출금건수
         , tow_ct                           -- 출고건수
         , mrp_ts_at                        -- 입출금거래금액
         , sar_ts_at                        -- 입출고거래금액
         , rca                              -- 입금금액
         , siw_at                           -- 입고금액
         , aow_at                           -- 출금금액
         , tow_at                           -- 출고금액
         , scu_ts_ct                        -- 증권거래건수
         , m3_scu_ts_ct                     -- 3개월증권거래건수
         , m6_scu_ts_ct                     -- 6개월증권거래건수
         , m12_scu_ts_ct                    -- 12개월증권거래건수
         )
    select ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'  as aws_ld_dt            -- aws적재일시
         , max(nvl(to_ase_at,0))                        as to_ase_at            -- 총자산금액
         , max(nvl(pot_scu_ase_at,0))                   as pot_scu_ase_at       -- 지분증권자산금액
         , max(nvl(eb_scu_ase_at,0))                    as eb_scu_ase_at        -- 채무증권자산금액
         , max(nvl(eni_scu_ase_at,0))                   as eni_scu_ase_at       -- 수익증권자산금액
         , max(nvl(ivs_are_scu_ase_at,0))               as ivs_are_scu_ase_at   -- 투자계약증권자산금액
         , max(nvl(drb_cmb_scu_ase_at,0))               as drb_cmb_scu_ase_at   -- 파생결합증권자산금액
         , max(nvl(scu_msd_scu_ase_at,0))               as scu_msd_scu_ase_at   -- 증권예탁증권자산금액
         , max(nvl(mrp_ts_ct,0))                        as mrp_ts_ct            -- 입출금거래건수
         , max(nvl(sar_ts_ct,0))                        as sar_ts_ct            -- 입출고거래건수
         , max(nvl(rcp_ct,0))                           as rcp_ct               -- 입금건수
         , max(nvl(siw_ct,0))                           as siw_ct               -- 입고건수
         , max(nvl(aow_ct,0))                           as aow_ct               -- 출금건수
         , max(nvl(tow_ct,0))                           as tow_ct               -- 출고건수
         , max(nvl(mrp_ts_at,0))                        as mrp_ts_at            -- 입출금거래금액
         , max(nvl(sar_ts_at,0))                        as sar_ts_at            -- 입출고거래금액
         , max(nvl(rca,0))                              as rca                  -- 입금금액
         , max(nvl(siw_at,0))                           as siw_at               -- 입고금액
         , max(nvl(aow_at,0))                           as aow_at               -- 출금금액
         , max(nvl(tow_at,0))                           as tow_at               -- 출고금액
         , max(nvl(scu_ts_ct,0))                        as scu_ts_ct            -- 증권거래건수
         , max(nvl(m3_scu_ts_ct,0))                     as m3_scu_ts_ct         -- 3개월증권거래건수
         , max(nvl(m6_scu_ts_ct,0))                     as m6_scu_ts_ct         -- 6개월증권거래건수
         , max(nvl(m12_scu_ts_ct,0))                    as m12_scu_ts_ct        -- 12개월증권거래건수
      from tmp_sh2.shdmigd009_tmp99
     group by ta_ym
            , shmdn
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh2 = [insert_sql_1]
### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh2_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]
    
    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    tmp_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_tmp_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh2_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh2_load_task_' + str(insert_sql_for_sh2.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh2]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> tmp_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end
