# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "이종호"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["이종호"]
__version__    = "1.0"
__maintainer__ = "이종호"
__email__      = "hijack72@xgm.co.kr"
__status__     = "Production"


"""
L1 데이터를 SH2 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 : IGD_월고객거래실적_은행
  - 프로그램 ID  : IBTM_SHDMIGD007_TG
  - 한글 테이블명: IGD_월고객거래실적_은행
  - TMP_SH2 테이블명: tmp_sh2.shdmigd007_tmp99
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMIGD007_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = 'IGD_월고객거래실적_은행'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) TMP_SH2 테이블명 (TRUNCATE 대상)
"""
tmp_sh2_table = ['shdmigd007_tmp99']

"""
(@) TMP_SH2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmigd007_tmp99
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹md번호
         , aws_ld_dt                              -- AWS적재일시
         , to_ina	                                -- 총소득금액
         , pay_bt_at                              -- 급여이체금액
         , pnz_bt_at                              -- 연금이체금액
         , liq_al                                 -- 유동성잔액
         , sav_al                                 -- 예금잔액
         , issv_al                                -- 적금잔액
         , trt_al                                 -- 신탁잔액
         , fud_al                                 -- 펀드잔액
         , rtr_pnz_al                             -- 퇴직연금잔액
         , pnz_trt_al                             -- 연금신탁잔액
         , cre_ln_al                              -- 신용대출잔액
         , hsg_ll_ln_al                           -- 주택담보대출잔액
         , leh_mny_ln_al                          -- 전세자금대출잔액
         , et_esa_ln_al                           -- 기타부동산대출잔액
         , fnn_pd_ll_ln_al                        -- 금융상품담보대출잔액
         , car_ln_al                              -- 자동차대출잔액
         , eco_ln_al                              -- 기업대출잔액
         , psn_etk_ln_al                          -- 개인사업자대출잔액
         , et_ln_al                               -- 기타대출잔액
         , liq_lat_ct                             -- 유동성신규건수
         , sav_lat_ct                             -- 예금신규건수
         , issv_lat_ct                            -- 적금신규건수
         , trt_lat_ct                             -- 신탁신규건수
         , fud_lat_ct                             -- 펀드신규건수
         , rtr_pnz_lat_ct                         -- 퇴직연금신규건수
         , pnz_trt_lat_ct                         -- 연금신탁신규건수
         , cre_ln_lat_ct                          -- 신용대출신규건수
         , hsg_ll_ln_lat_ct                       -- 주택담보대출신규건수
         , leh_mny_ln_lat_ct                      -- 전세자금대출신규건수
         , et_esa_ll_ln_lat_ct                    -- 기타부동산담보대출신규건수
         , fnn_pd_ll_ln_lat_ct                    -- 금융상품담보대출신규건수
         , car_ln_lat_ct                          -- 자동차대출신규건수
         , eco_ln_lat_ct                          -- 기업대출신규건수
         , psn_etk_ln_lat_ct                      -- 개인사업자대출신규건수
         , et_ln_lat_ct                           -- 기타대출신규건수
         , liq_me_ct                              -- 유동성해지건수
         , sav_me_ct                              -- 예금해지건수
         , issv_me_ct                             -- 적금해지건수
         , trt_me_ct                              -- 신탁해지건수
         , fud_me_ct                              -- 펀드해지건수
         , rtr_pnz_me_ct                          -- 퇴직연금해지건수
         , pnz_trt_me_ct                          -- 연금신탁해지건수
         , cre_ln_me_ct                           -- 신용대출해지건수
         , hsg_ll_ln_me_ct                        -- 주택담보대출해지건수
         , leh_mny_ln_me_ct                       -- 전세자금대출해지건수
         , et_esa_ll_ln_me_ct                     -- 기타부동산담보대출해지건수
         , fnn_pd_ll_ln_me_ct                     -- 금융상품담보대출해지건수
         , car_ln_me_ct                           -- 자동차대출해지건수
         , eco_ln_me_ct                           -- 기업대출해지건수
         , psn_etk_ln_me_ct                       -- 개인사업자대출해지건수
         , et_ln_me_ct                            -- 기타대출해지건수
         )
    select '{date_cd('P_TA_YM')}'                                           as ta_ym                      -- 기준년월
         , t10.shmdn                                                                                      -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'                                                    -- aws적재일시
         , 0                                                                as to_ina	                    -- 총소득금액
         , sum(nvl(t11.pay_bt_at,0))                                        as pay_bt_at                  -- 급여이체금액
         , sum(nvl(t11.pnz_bt_at,0))                                        as pnz_bt_at                  -- 연금이체금액         
         , sum(case when t10.shd_pd_zcd = 'B11' then t10.al else 0 end)     as liq_al                     -- 유동성잔액
         , sum(case when t10.shd_pd_zcd in ( 'B11'    -- 입출금
                                            ,'B12'    -- 예금
                                            ,'B13'    -- 적금
                                            )
                    then t10.al
                    else 0
               end)                                                         as sav_al                     -- 예금잔액
         , sum(case when t10.shd_pd_zcd = 'B13' then t10.al else 0 end)     as issv_al                    -- 적금잔액
         , sum(case when t10.shd_pd_zcd = 'B15' then t10.al else 0 end)     as trt_al                     -- 신탁잔액
         , sum(case when t10.shd_pd_zcd = 'B14' then t10.al else 0 end)     as fud_al                     -- 펀드잔액
         , sum(case when t10.shd_pd_zcd = 'B17' then t10.al else 0 end)     as rtr_pnz_al                 -- 퇴직연금잔액
         , sum(case when t10.shd_pd_zcd = 'B16' then t10.al else 0 end)     as pnz_trt_al                 -- 연금신탁잔액
         , sum(case when t10.shd_pd_zcd = 'B21' then t10.al else 0 end)     as cre_ln_al                  -- 신용대출잔액
         , sum(case when t10.shd_pd_zcd = 'B23' then t10.al else 0 end)     as hsg_ll_ln_al               -- 주택담보대출잔액
         , sum(case when t10.shd_pd_zcd = 'B22' then t10.al else 0 end)     as leh_mny_ln_al              -- 전세자금대출잔액
         , 0                                                                as et_esa_ln_al               -- 기타부동산대출잔액
         , sum(case when t10.shd_pd_zcd = 'B25' then t10.al else 0 end)     as fnn_pd_ll_ln_al            -- 금융상품담보대출잔액
         , 0                                                                as car_ln_al                  -- 자동차대출잔액
         , sum(case when t10.shd_pd_zcd = 'B28' then t10.al else 0 end)     as eco_ln_al                  -- 기업대출잔액
         , 0                                                                as psn_etk_ln_al              -- 개인사업자대출잔액
         , 0                                                                as et_ln_al                   -- 기타대출잔액
         , sum(case when t10.shd_pd_zcd = 'B11' then t10.lat_ct else 0 end) as liq_lat_ct                 -- 유동성신규건수
         , sum(case when t10.shd_pd_zcd in ( 'B11'    -- 입출금
                                            ,'B12'    -- 예금
                                            ,'B13'    -- 적금
                                            )
                    then t10.lat_ct
                    else 0
               end)                                                         as sav_lat_ct                 -- 예금신규건수
         , sum(case when t10.shd_pd_zcd = 'B13' then t10.lat_ct else 0 end) as issv_lat_ct                -- 적금신규건수
         , sum(case when t10.shd_pd_zcd = 'B15' then t10.lat_ct else 0 end) as trt_lat_ct                 -- 신탁신규건수
         , sum(case when t10.shd_pd_zcd = 'B14' then t10.lat_ct else 0 end) as fud_lat_ct                 -- 펀드신규건수
         , sum(case when t10.shd_pd_zcd = 'B17' then t10.lat_ct else 0 end) as rtr_pnz_lat_ct             -- 퇴직연금신규건수
         , sum(case when t10.shd_pd_zcd = 'B16' then t10.lat_ct else 0 end) as pnz_trt_lat_ct             -- 연금신탁신규건수
         , sum(case when t10.shd_pd_zcd = 'B21' then t10.lat_ct else 0 end) as cre_ln_lat_ct              -- 신용대출신규건수
         , sum(case when t10.shd_pd_zcd = 'B23' then t10.lat_ct else 0 end) as hsg_ll_ln_lat_ct           -- 주택담보대출신규건수
         , sum(case when t10.shd_pd_zcd = 'B22' then t10.lat_ct else 0 end) as leh_mny_ln_lat_ct          -- 전세자금대출신규건수
         , 0                                                                as et_esa_ll_ln_lat_ct        -- 기타부동산담보대출신규건수
         , sum(case when t10.shd_pd_zcd = 'B25' then t10.lat_ct else 0 end) as fnn_pd_ll_ln_lat_ct        -- 금융상품담보대출신규건수
         , 0                                                                as car_ln_lat_ct              -- 자동차대출신규건수
         , sum(case when t10.shd_pd_zcd = 'B28' then t10.lat_ct else 0 end) as eco_ln_lat_ct              -- 기업대출신규건수
         , 0                                                                as psn_etk_ln_lat_ct          -- 개인사업자대출신규건수
         , 0                                                                as et_ln_lat_ct               -- 기타대출신규건수
         , sum(case when t10.shd_pd_zcd = 'B11' then t10.me_ct else 0 end)  as liq_me_ct                  -- 유동성해지건수
         , sum(case when t10.shd_pd_zcd in ( 'B11'    -- 입출금
                                            ,'B12'    -- 예금
                                            ,'B13'    -- 적금
                                            )
                    then t10.me_ct
                    else 0
               end)                                                         as sav_me_ct                  -- 예금해지건수
         , sum(case when t10.shd_pd_zcd = 'B13' then t10.me_ct else 0 end)  as issv_me_ct                 -- 적금해지건수
         , sum(case when t10.shd_pd_zcd = 'B15' then t10.me_ct else 0 end)  as trt_me_ct                  -- 신탁해지건수
         , sum(case when t10.shd_pd_zcd = 'B14' then t10.me_ct else 0 end)  as fud_me_ct                  -- 펀드해지건수
         , sum(case when t10.shd_pd_zcd = 'B17' then t10.me_ct else 0 end)  as rtr_pnz_me_ct              -- 퇴직연금해지건수
         , sum(case when t10.shd_pd_zcd = 'B16' then t10.me_ct else 0 end)  as pnz_trt_me_ct              -- 연금신탁해지건수
         , sum(case when t10.shd_pd_zcd = 'B21' then t10.me_ct else 0 end)  as cre_ln_me_ct               -- 신용대출해지건수
         , sum(case when t10.shd_pd_zcd = 'B23' then t10.me_ct else 0 end)  as hsg_ll_ln_me_ct            -- 주택담보대출해지건수
         , sum(case when t10.shd_pd_zcd = 'B22' then t10.me_ct else 0 end)  as leh_mny_ln_me_ct           -- 전세자금대출해지건수
         , 0                                                                as et_esa_ll_ln_me_ct         -- 기타부동산담보대출해지건수
         , sum(case when t10.shd_pd_zcd = 'B25' then t10.me_ct else 0 end)  as fnn_pd_ll_ln_me_ct         -- 금융상품담보대출해지건수
         , 0                                                                as car_ln_me_ct               -- 자동차대출해지건수
         , sum(case when t10.shd_pd_zcd = 'B28' then t10.me_ct else 0 end)  as eco_ln_me_ct               -- 기업대출해지건수
         , 0                                                                as psn_etk_ln_me_ct           -- 개인사업자대출해지건수
         , 0                                                                as et_ln_me_ct                -- 기타대출해지건수
      from sh1.shbmtrs001 t10                                               --TRS_월고객계좌거래실적_은행
      left outer join (select cusno                as shmdn
                            , sum(payiche_amt)     as pay_bt_at   --급여이체금액
                            , sum(pens_iche_amt)   as pnz_bt_at   --연금이체금액
                         from shb.vam_cus_mkt_mas_m   
                        where dw_bas_nyymm = '{date_cd('P_TA_YM')}'
                        group by cusno
                      )t11
        on t10.shmdn = t11.shmdn
     where t10.ta_ym = '{date_cd('P_TA_YM')}'
     group by t10.shmdn
"""

"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH2 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmigd007_tmp99', 'pk': ['shmdn']},
}
"""
(@) SH2 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmigd007
    where ta_ym = '{date_cd('P_TA_YM')}'
"""

"""
(@) SH2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shdmigd007
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹md번호
         , aws_ld_dt                              -- AWS적재일시
         , to_ina	                                -- 총소득금액
         , pay_bt_at                              -- 급여이체금액
         , pnz_bt_at                              -- 연금이체금액
         , liq_al                                 -- 유동성잔액
         , sav_al                                 -- 예금잔액
         , issv_al                                -- 적금잔액
         , trt_al                                 -- 신탁잔액
         , fud_al                                 -- 펀드잔액
         , rtr_pnz_al                             -- 퇴직연금잔액
         , pnz_trt_al                             -- 연금신탁잔액
         , cre_ln_al                              -- 신용대출잔액
         , hsg_ll_ln_al                           -- 주택담보대출잔액
         , leh_mny_ln_al                          -- 전세자금대출잔액
         , et_esa_ln_al                           -- 기타부동산대출잔액
         , fnn_pd_ll_ln_al                        -- 금융상품담보대출잔액
         , car_ln_al                              -- 자동차대출잔액
         , eco_ln_al                              -- 기업대출잔액
         , psn_etk_ln_al                          -- 개인사업자대출잔액
         , et_ln_al                               -- 기타대출잔액
         , liq_lat_ct                             -- 유동성신규건수
         , sav_lat_ct                             -- 예금신규건수
         , issv_lat_ct                            -- 적금신규건수
         , trt_lat_ct                             -- 신탁신규건수
         , fud_lat_ct                             -- 펀드신규건수
         , rtr_pnz_lat_ct                         -- 퇴직연금신규건수
         , pnz_trt_lat_ct                         -- 연금신탁신규건수
         , cre_ln_lat_ct                          -- 신용대출신규건수
         , hsg_ll_ln_lat_ct                       -- 주택담보대출신규건수
         , leh_mny_ln_lat_ct                      -- 전세자금대출신규건수
         , et_esa_ll_ln_lat_ct                    -- 기타부동산담보대출신규건수
         , fnn_pd_ll_ln_lat_ct                    -- 금융상품담보대출신규건수
         , car_ln_lat_ct                          -- 자동차대출신규건수
         , eco_ln_lat_ct                          -- 기업대출신규건수
         , psn_etk_ln_lat_ct                      -- 개인사업자대출신규건수
         , et_ln_lat_ct                           -- 기타대출신규건수
         , liq_me_ct                              -- 유동성해지건수
         , sav_me_ct                              -- 예금해지건수
         , issv_me_ct                             -- 적금해지건수
         , trt_me_ct                              -- 신탁해지건수
         , fud_me_ct                              -- 펀드해지건수
         , rtr_pnz_me_ct                          -- 퇴직연금해지건수
         , pnz_trt_me_ct                          -- 연금신탁해지건수
         , cre_ln_me_ct                           -- 신용대출해지건수
         , hsg_ll_ln_me_ct                        -- 주택담보대출해지건수
         , leh_mny_ln_me_ct                       -- 전세자금대출해지건수
         , et_esa_ll_ln_me_ct                     -- 기타부동산담보대출해지건수
         , fnn_pd_ll_ln_me_ct                     -- 금융상품담보대출해지건수
         , car_ln_me_ct                           -- 자동차대출해지건수
         , eco_ln_me_ct                           -- 기업대출해지건수
         , psn_etk_ln_me_ct                       -- 개인사업자대출해지건수
         , et_ln_me_ct                            -- 기타대출해지건수
         )
    select ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹md번호
         , aws_ld_dt                              -- AWS적재일시
         , to_ina	                                -- 총소득금액
         , pay_bt_at                              -- 급여이체금액
         , pnz_bt_at                              -- 연금이체금액
         , liq_al                                 -- 유동성잔액
         , sav_al                                 -- 예금잔액
         , issv_al                                -- 적금잔액
         , trt_al                                 -- 신탁잔액
         , fud_al                                 -- 펀드잔액
         , rtr_pnz_al                             -- 퇴직연금잔액
         , pnz_trt_al                             -- 연금신탁잔액
         , cre_ln_al                              -- 신용대출잔액
         , hsg_ll_ln_al                           -- 주택담보대출잔액
         , leh_mny_ln_al                          -- 전세자금대출잔액
         , et_esa_ln_al                           -- 기타부동산대출잔액
         , fnn_pd_ll_ln_al                        -- 금융상품담보대출잔액
         , car_ln_al                              -- 자동차대출잔액
         , eco_ln_al                              -- 기업대출잔액
         , psn_etk_ln_al                          -- 개인사업자대출잔액
         , et_ln_al                               -- 기타대출잔액
         , liq_lat_ct                             -- 유동성신규건수
         , sav_lat_ct                             -- 예금신규건수
         , issv_lat_ct                            -- 적금신규건수
         , trt_lat_ct                             -- 신탁신규건수
         , fud_lat_ct                             -- 펀드신규건수
         , rtr_pnz_lat_ct                         -- 퇴직연금신규건수
         , pnz_trt_lat_ct                         -- 연금신탁신규건수
         , cre_ln_lat_ct                          -- 신용대출신규건수
         , hsg_ll_ln_lat_ct                       -- 주택담보대출신규건수
         , leh_mny_ln_lat_ct                      -- 전세자금대출신규건수
         , et_esa_ll_ln_lat_ct                    -- 기타부동산담보대출신규건수
         , fnn_pd_ll_ln_lat_ct                    -- 금융상품담보대출신규건수
         , car_ln_lat_ct                          -- 자동차대출신규건수
         , eco_ln_lat_ct                          -- 기업대출신규건수
         , psn_etk_ln_lat_ct                      -- 개인사업자대출신규건수
         , et_ln_lat_ct                           -- 기타대출신규건수
         , liq_me_ct                              -- 유동성해지건수
         , sav_me_ct                              -- 예금해지건수
         , issv_me_ct                             -- 적금해지건수
         , trt_me_ct                              -- 신탁해지건수
         , fud_me_ct                              -- 펀드해지건수
         , rtr_pnz_me_ct                          -- 퇴직연금해지건수
         , pnz_trt_me_ct                          -- 연금신탁해지건수
         , cre_ln_me_ct                           -- 신용대출해지건수
         , hsg_ll_ln_me_ct                        -- 주택담보대출해지건수
         , leh_mny_ln_me_ct                       -- 전세자금대출해지건수
         , et_esa_ll_ln_me_ct                     -- 기타부동산담보대출해지건수
         , fnn_pd_ll_ln_me_ct                     -- 금융상품담보대출해지건수
         , car_ln_me_ct                           -- 자동차대출해지건수
         , eco_ln_me_ct                           -- 기업대출해지건수
         , psn_etk_ln_me_ct                       -- 개인사업자대출해지건수
         , et_ln_me_ct                            -- 기타대출해지건수
      from tmp_sh2.shdmigd007_tmp99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh2 = [insert_sql_1]
### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh2_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh2.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh2]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end