# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "노재홍"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["노재홍"]
__version__    = "1.0"
__maintainer__ = "노재홍"
__email__      = ""
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 한글 테이블명
  - TMP_SH1 테이블명
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTD_SHDDIGD002_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L2통합) IGD_일개인사업자마스터 배치프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shddigd002_tmp99']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""

############################################################################################
# TO_DO
############################################################################################
# 가맹점건수       은행은 무조건 0, 결국 카드가맹점건수
############################################################################################

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shddigd002_tmp99                                        -- IGD_일개인사업자마스터_TMP99
    (
           shmdn                                                                -- 그룹MD번호
         , aws_ld_dt                                                            -- AWS적재일시
         , cln_age                                                              -- 고객연령
         , sex_ccd                                                              -- 성별구분코드
         , age_ccd                                                              -- 연령구분코드
         , hm_zpn                                                               -- 자택우편번호
         , hm_adm_gds_apb_cd                                                    -- 자택행정GDS동코드
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , shp_tps_clb_gcd                                                      -- 신한그룹탑스클럽등급코드
         , to_bsu_cn                                                            -- 총사업장수
         , mct_ct                                                               -- 가맹점건수
         , yuba_jn_tf                                                           -- 노란우산공제회가입TF
         , etk_crd_pss_tf                                                       -- 사업자카드보유TF
         , crd_mct_tf                                                           -- 카드가맹점TF
         , jnt_etk_tf                                                           -- 공동사업자TF
         , jnt_etk_cn                                                           -- 공동사업자수
         , shb_cln_tf                                                           -- 신한은행고객TF
         , shc_cln_tf                                                           -- 신한카드고객TF
         , shi_cln_tf                                                           -- 신한금융투자고객TF
         , shl_cln_tf                                                           -- 신한라이프고객TF
    )
    select t10.shmdn                                                            -- 그룹md번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , t11.cln_age                                                          -- 고객연령
         , t11.sex_ccd                                                          -- 성별구분코드
         , t11.age_ccd                                                          -- 연령구분코드
         , t11.hm_zpn                                                           -- 자택우편번호
         , t11.hm_adm_gds_apb_cd                                                -- 자택행정GDS동코드
         , t11.hm_cou_gds_apb_cd                                                -- 자택법정GDS동코드
         , t11.shp_tps_clb_gcd                                                  -- 신한그룹탑스클럽등급코드
         , nvl(t10.to_bsu_cn, 0)                           as to_bsu_cn         -- 총사업장수
         , nvl(t10.mct_ct, 0)                              as mct_ct            -- 가맹점수
         , nvl(t10.yuba_jn_tf, 0)                          as yuba_jn_tf        -- 노란우산공제회가입TF
         , nvl(t12.etk_crd_pss_tf, 0)                      as etk_crd_pss_tf    -- 사업자카드보유TF
         , nvl(t10.crd_mct_tf, 0)                          as crd_mct_tf        -- 카드가맹점TF
         , nvl(t10.jnt_etk_tf, 0)                          as jnt_etk_tf        -- 공동사업자TF
         , nvl(t10.jnt_etk_cn, 0)                          as jnt_etk_cn        -- 공동사업자수
         , nvl(t11.shb_cln_tf, 0)                          as shb_cln_tf        -- 신한은행고객TF
         , nvl(t11.shc_cln_tf, 0)                          as shc_cln_tf        -- 신한카드고객TF
         , nvl(t11.shi_cln_tf, 0)                          as shi_cln_tf        -- 신한금융투자고객TF
         , nvl(t11.shl_cln_tf, 0)                          as shl_cln_tf        -- 신한라이프고객TF
      from
           (
              select t20.shmdn                                                  -- 그룹MD번호
                   , count(distinct t20.brn )              as to_bsu_cn         -- 총사업장수
                   , max(t20.yuba_jn_tf)                   as yuba_jn_tf        -- 노란우산공제회가입TF
                   , nvl(sum(t20.rlp_mct_ct), 0)           as mct_ct            -- 가맹점수(실질가맹점건수)
                   , max(t20.crd_mct_tf)                   as crd_mct_tf        -- 카드가맹점TF
                   , max(t20.jnt_etk_tf)                   as jnt_etk_tf        -- 공동사업자TF
                   , nvl(sum(t20.jnt_etk_cn), 0)           as jnt_etk_cn        -- 공동사업자수
                from
                     (
                        select t30.shmdn                                        -- 그룹md번호
                             , t30.brn                                          -- 사업자등록번호
                             , t30.yuba_jn_tf                                   -- 노란우산공제회가입TF
                             , 0                           as rlp_mct_ct        -- 실질가맹점건수
                             , t30.crd_mct_tf              as crd_mct_tf        -- 카드가맹점TF
                             , t30.jnt_etk_tf              as jnt_etk_tf        -- 공동사업자TF
                             , t30.jnt_etk_cn              as jnt_etk_cn        -- 공동사업자수
                          from sh1.shbdcln003                        t30        -- cln_일개인사업자마스터_은행
                         union all
                        select t30.shmdn                                        -- 그룹md번호
                             , t30.brn                                          -- 사업자등록번호
                             , 0                           as yuba_jn_tf        -- 노란우산공제회가입TF
                             , nvl(t30.rlp_mct_ct, 0)      as rlp_mct_ct        -- 실질가맹점건수
                             , 0                           as crd_mct_tf        -- 카드가맹점TF
                             , 0                           as jnt_etk_tf        -- 공동사업자TF
                             , 0                           as jnt_etk_cn        -- 공동사업자수
                          from sh1.shcdcln003                        t30        -- CLN_일개인사업자마스터_카드
                     )                                     t20
               group by
                     t20.shmdn                                                  -- 그룹MD번호
           )                                     t10
      left outer join
           sh2.shddigd001                        t11                            -- IGD_일고객마스터
        on t10.shmdn = t11.shmdn                                                -- 그룹MD번호
      left outer join
           (
              select t20.rpk_sgdmd                                              -- 대표자그룹MD번호
                   , max(case when t20.crd_rpl_n is not null then 1
                              else 0
                         end)                           as etk_crd_pss_tf       -- 사업자카드보유TF
                from
                     (
                        select t30.rpk_sgdmd                                    -- 대표자그룹MD번호
                             , t31.crd_rpl_n                                    -- 카드대체번호
                             , t31.sgdmd                                        -- 그룹MD번호
                          from shc.mtdia5011            t30                     -- 일가맹점디멘젼마스터
                          left outer join
                               shc.mtdia5008            t31                     -- 일카드디멘젼마스터
                            on t30.rpk_sgdmd = t31.sgdmd                        -- 대표자그룹MD번호
                           and t31.rlp_crd_tf = 1                               -- 실질카드tf
                         inner join
                               (
                                   select t40.lcd_cri_vl1                       -- 상세코드특성값1
                                     from sh1.shddcom002    t40                 -- COM_수기관리기본
                                    where t40.ta_itm_key_vl = 'CRD_PD_N_001'    -- 기준항목key값(사업자카드에 해당하는 상품)
                                      and t40.itm_un_se_tf = 0                  -- 항목미사용tf(0.사용)
                               )                         t32
                            on t31.crd_pd_n = t32.lcd_cri_vl1                   -- 카드상품번호
                         where t30.psn_etk_tf = 1                               -- 개인사업자tf
                     )                                     t20
               group by
                     t20.rpk_sgdmd                                              -- 대표자그룹MD번호
           )                                     t12
        on t10.shmdn = t12.rpk_sgdmd                                            -- 그룹MD번호
"""


"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shddigd002_tmp99', 'pk': ['shmdn']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shddigd002                                                  -- IGD_일개인사업자마스터
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""

insert_sql_1 = f"""
    insert into sh2.shddigd002                                                  -- IGD_일개인사업자마스터
    (
           shmdn                                                                -- 그룹MD번호
         , aws_ld_dt                                                            -- AWS적재일시
         , cln_age                                                              -- 고객연령
         , sex_ccd                                                              -- 성별구분코드
         , age_ccd                                                              -- 연령구분코드
         , hm_zpn                                                               -- 자택우편번호
         , hm_adm_gds_apb_cd                                                    -- 자택행정GDS동코드
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , shp_tps_clb_gcd                                                      -- 신한그룹탑스클럽등급코드
         , to_bsu_cn                                                            -- 총사업장수
         , mct_ct                                                               -- 가맹점건수
         , yuba_jn_tf                                                           -- 노란우산공제회가입TF
         , etk_crd_pss_tf                                                       -- 사업자카드보유TF
         , crd_mct_tf                                                           -- 카드가맹점TF
         , jnt_etk_tf                                                           -- 공동사업자TF
         , jnt_etk_cn                                                           -- 공동사업자수
         , shb_cln_tf                                                           -- 신한은행고객TF
         , shc_cln_tf                                                           -- 신한카드고객TF
         , shi_cln_tf                                                           -- 신한금융투자고객TF
         , shl_cln_tf                                                           -- 신한라이프고객TF
    )
    select shmdn                                                                -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , cln_age                                                              -- 고객연령
         , sex_ccd                                                              -- 성별구분코드
         , age_ccd                                                              -- 연령구분코드
         , hm_zpn                                                               -- 자택우편번호
         , hm_adm_gds_apb_cd                                                    -- 자택행정GDS동코드
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , shp_tps_clb_gcd                                                      -- 신한그룹탑스클럽등급코드
         , to_bsu_cn                                                            -- 총사업장수
         , mct_ct                                                               -- 가맹점건수
         , yuba_jn_tf                                                           -- 노란우산공제회가입TF
         , etk_crd_pss_tf                                                       -- 사업자카드보유TF
         , crd_mct_tf                                                           -- 카드가맹점TF
         , jnt_etk_tf                                                           -- 공동사업자TF
         , jnt_etk_cn                                                           -- 공동사업자수
         , shb_cln_tf                                                           -- 신한은행고객TF
         , shc_cln_tf                                                           -- 신한카드고객TF
         , shi_cln_tf                                                           -- 신한금융투자고객TF
         , shl_cln_tf                                                           -- 신한라이프고객TF
      from tmp_sh2.shddigd002_tmp99                                             -- IGD_일개인사업자마스터_TMP99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end