# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "노재홍"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["노재홍"]
__version__    = "1.0"
__maintainer__ = "노재홍"
__email__      = ""
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 한글 테이블명
  - TMP_SH1 테이블명
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTD_SHDDIGD001_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L2통합) IGD_일고객마스터 배치프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shddigd001_tmp99', 'shddigd001_tmp01']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
############################################################################################
# TO_DO
############################################################################################
# 신한그룹탑스클럽등급코드은 원천의 신한그룹탑스클럽등급코드에서 우선순위처리( 문서에서는 Tops등급 )
# 각지주사의 탑스클럽등급코드은 탑스클럽등급코드로 일단 처리( 문서에서는 Tops등급 )
#
#  < 추출로직 순위 >   보유상품은 가장 최근월을 처리한다.
# 1) 은행 및 카드별 최신 ""주소 반영일자""①주 의 최우선 순위 그룹사의 gis항목 설정
# 2) 금투 & 라이프 일 경우는 라이프를 우선으로 함.
# 3) Only 금투, Only 라이프 대상은 각 사의 gis항목 설정
#
#
#  ①주 ""주소 반영일자"" 정의
#  (카드)
# 1) 보유상품기본MAX일자(카드발급일자, 론대출일자, 대출일자)
# 2) 고객마스터의 최초카드발급일자
# 3) 1)과 2)의 MAX일자 선정
#
# (은행)
# 1) 보유상품기본의 신규일자
# 2) 일고객마스터의 최초거래일자
# 3) 1)과 2)의 MAX일자 선정
#
#
# drop table tmp_sh2.shddigd001_tmp01;
# create table tmp_sh2.shddigd001_tmp01 as select shmdn, hm_zpn, hm_adm_gds_apb_cd, hm_cou_gds_apb_cd from sh2.shddigd001 where 1 = 2;
#
# comment on table tmp_sh2.shddigd001_tmp01 is 'IGD_일고객마스터_TMP01';
# comment on column tmp_sh2.shddigd001_tmp01.shmdn is '그룹MD번호';
# comment on column tmp_sh2.shddigd001_tmp01.hm_zpn is '자택우편번호';
# comment on column tmp_sh2.shddigd001_tmp01.hm_adm_gds_apb_cd is '자택행정GDS동코드';
# comment on column tmp_sh2.shddigd001_tmp01.hm_cou_gds_apb_cd is '자택법정GDS동코드';
#
############################################################################################

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shddigd001_tmp01                                        -- IGD_일고객마스터_TMP01
    (
           shmdn                                                                -- 그룹MD번호
         , hm_zpn                                                               -- 자택우편번호
         , hm_adm_gds_apb_cd                                                    -- 자택행정GDS동코드
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
    )
    select t10.shmdn                                                            -- 그룹MD번호
         , t11.hm_zpn                                      as hm_zpn            -- 자택우편번호
         , t11.hm_adm_gds_apb_cd                           as hm_adm_gds_apb_cd -- 자택행정GDS동코드
         , t11.hm_cou_gds_apb_cd                           as hm_cou_gds_apb_cd -- 자택법정GDS동코드
      from
           (
               select t20.shmdn                                                 -- 그룹MD번호
                    , substring(max(t20.ni_ts_d),10, 4)    as shp_co_cd         -- 신한그룹사코드
                    , substring(max(t20.ni_ts_d), 2, 8)    as ni_ts_d           -- 최초거래일자
                 from
                      (
                        -- 카드
                        select t30.shmdn                                        -- 그룹MD번호
                             , '9'||rpad(t30.ni_crd_iss_d, 8, ' ')||'S012' as ni_ts_d  -- 최초거래일자(최초카드발급일자)
                          from sh1.shcdcln001              t30                  -- CLN_일고객마스터_카드
                        union all
                        select t30.shmdn                                        -- 그룹MD번호
                             , '9'||rpad(t30.crd_iss_d, 8, ' ')||'S012' as ni_ts_d           -- 최초거래일자(카드발급일자)
                          from sh1.shcmpdt001              t30                  -- PDT_월카드상품기본_카드
                         inner join
                               (
                                select max(t40.ta_ym)      as max_ta_ym         -- 기준년월
                                  from sh1.shcmpdt001      t40                  -- PDT_월카드상품기본_카드
                                 where t40.ta_ym <= '{date_cd('P_TA_YM')}'      -- 기준년월
                               )                           t31
                            on t30.ta_ym = t31.max_ta_ym                        -- 기준년월
                        union all
                        select t30.shmdn                                        -- 그룹MD번호
                             , '9'||rpad(t30.lln_d, 8, ' ')||'S012' as ni_ts_d           -- 최초거래일자(론대출일자)
                          from sh1.shcmpdt002              t30                  -- PDT_월론대출상품기본_카드
                         inner join
                               (
                                select max(t40.ta_ym)      as max_ta_ym         -- 기준년월
                                  from sh1.shcmpdt002      t40                  -- PDT_월론대출상품기본_카드
                                 where t40.ta_ym <= '{date_cd('P_TA_YM')}'      -- 기준년월
                               )                           t31
                            on t30.ta_ym = t31.max_ta_ym                        -- 기준년월
                        union all
                        select t30.shmdn                                        -- 그룹MD번호
                             , '9'||rpad(t30.ln_d, 8, ' ')||'S012' as ni_ts_d           -- 최초거래일자(대출일자)
                          from sh1.shcmpdt003              t30                  -- PDT_월오토금융대출상품기본_카드
                         inner join
                               (
                                select max(t40.ta_ym)      as max_ta_ym         -- 기준년월
                                  from sh1.shcmpdt003      t40                  -- PDT_월오토금융대출상품기본_카드
                                 where t40.ta_ym <= '{date_cd('P_TA_YM')}'      -- 기준년월
                               )                           t31
                            on t30.ta_ym = t31.max_ta_ym                        -- 기준년월
                        union all
                        -- 은행
                        select t30.shmdn                                        -- 그룹MD번호
                             , '9'||rpad(t30.ni_ts_d, 8, ' ')||'S001' as ni_ts_d           -- 최초거래일자(최초거래일자)
                          from sh1.shbdcln001              t30                  -- CLN_일고객마스터_은행
                        union all
                        select t30.shmdn                                        -- 그룹MD번호
                             , '9'||rpad(t30.lat_d, 8, ' ')||'S001' as ni_ts_d           -- 최초거래일자(신규일자)
                          from sh1.shbmpdt001              t30                  -- PDT_월계좌보유상품기본_은행
                         inner join
                               (
                                select max(t40.ta_ym)      as max_ta_ym         -- 기준년월
                                  from sh1.shbmpdt001      t40                  -- PDT_월계좌보유상품기본_은행
                                 where t40.ta_ym <= '{date_cd('P_TA_YM')}'      -- 기준년월
                               )                          t31
                            on t30.ta_ym = t31.max_ta_ym                        -- 기준년월
                        union all
                        -- 라이프
                        select t30.shmdn                                        -- 그룹MD번호
                             , '8'||rpad(t30.ni_ts_d, 8, ' ')||'S016' as ni_ts_d           -- 최초거래일자(최초계약일자)
                          from sh1.shldcln001              t30                  -- CLN_일고객마스터_라이프
                        union all
                        -- 금투
                        select t30.shmdn                                        -- 그룹MD번호
                             , '7'||rpad(t30.ni_ac_opn_d, 8, ' ')||'S011' as ni_ts_d           -- 최초거래일자(최초계좌개설일자)
                          from sh1.shidcln001              t30                  -- CLN_일고객마스터_금투
                      )                          t20
                group by
                      t20.shmdn                                                 -- 그룹MD번호
           )                                     t10
      left outer join
           (
               select 'S012'                               as shp_co_cd         -- 신한그룹사코드(신한카드)
                    , t20.shmdn                                                 -- 그룹MD번호
                    , t20.hm_zpn                           as hm_zpn            -- 자택우편번호
                    , t20.hm_adm_gds_apb_cd                as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                    , t20.hm_cou_gds_apb_cd                as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                 from sh1.shcdcln001             t20                            -- CLN_일고객마스터_카드
                union all
               select 'S001'                               as shp_co_cd         -- 신한그룹사코드(신한은행)
                    , t20.shmdn                                                 -- 그룹MD번호
                    , t20.hm_zpn                           as hm_zpn            -- 자택우편번호
                    , t20.hm_adm_gds_apb_cd                as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                    , t20.hm_cou_gds_apb_cd                as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                 from sh1.shbdcln001             t20                            -- CLN_일고객마스터_은행
                union all
               select 'S011'                               as shp_co_cd         -- 신한그룹사코드(신한금융투자)
                    , t20.shmdn                                                 -- 그룹MD번호
                    , t20.hm_zpn                           as hm_zpn            -- 자택우편번호
                    , null                                 as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                    , null                                 as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                 from sh1.shidcln001             t20                            -- CLN_일고객마스터_금투
                union all
               select 'S016'                               as shp_co_cd         -- 신한그룹사코드(신한생명)
                    , t20.shmdn                                                 -- 그룹MD번호
                    , t20.hm_zpn                           as hm_zpn            -- 자택우편번호
                    , null                                 as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                    , t20.hm_cou_gds_apb_cd                as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                 from sh1.shldcln001             t20                            -- CLN_일고객마스터_라이프
           )                                     t11
        on t10.shp_co_cd = t11.shp_co_cd                                        -- 신한그룹사코드
       and t10.shmdn = t11.shmdn                                                -- 그룹MD번호
"""

############################################################################################
# 고객연령, 고객만기연령, 성별구분코드, 내국인TF는 아래의 우선순위 기반
# 우선순위 기반 1개의 값 정의 ==> (우선순위: 카드 > 은행 > 금투 > 라이프)
############################################################################################

insert_sql_for_tmp_2 = f"""
    insert into tmp_sh2.shddigd001_tmp99                                        -- IGD_일고객마스터_TMP99
    (
           shmdn                                                                -- 그룹MD번호
         , aws_ld_dt                                                            -- AWS적재일시
         , cln_age                                                              -- 고객연령
         , cln_xp_age                                                           -- 고객만기연령
         , age_ccd                                                              -- 연령구분코드
         , age_y5_blk_cd                                                        -- 연령5년구간코드
         , sex_ccd                                                              -- 성별구분코드
         , lcr_tf                                                               -- 내국인TF
         , hm_zpn                                                               -- 자택우편번호
         , hm_adm_gds_apb_cd                                                    -- 자택행정GDS동코드
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , shp_tps_clb_gcd                                                      -- 신한그룹탑스클럽등급코드
         , ni_ts_d                                                              -- 최초거래일자
         , ni_crd_iss_d                                                         -- 최초카드발급일자
         , ni_ac_opn_d                                                          -- 최초계좌개설일자
         , ni_are_d                                                             -- 최초계약일자
         , shb_cln_tf                                                           -- 신한은행고객TF
         , shc_cln_tf                                                           -- 신한카드고객TF
         , shi_cln_tf                                                           -- 신한금융투자고객TF
         , shl_cln_tf                                                           -- 신한라이프고객TF
         , ts_shp_co_cn                                                         -- 거래신한그룹사수
         , shb_tps_clb_gcd                                                      -- 신한은행탑스클럽등급코드
         , shc_tps_clb_gcd                                                      -- 신한카드탑스클럽등급코드
         , shi_tps_clb_gcd                                                      -- 신한금융투자탑스클럽등급코드
         , shl_tps_clb_gcd                                                      -- 신한라이프탑스클럽등급코드
         , psn_etk_tf                                                           -- 개인사업자TF
         , shb_atv_tf                                                           -- 신한은행활동TF
         , shi_atv_tf                                                           -- 신한금융투자활동TF
         , shl_atv_tf                                                           -- 신한라이프활동TF
    )
    select t10.shmdn                                                            -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , to_number(substring(max(t10.cln_age), 2), '999')     as cln_age      -- 고객연령
         , to_number(substring(max(t10.cln_xp_age), 2), '999')  as cln_xp_age   -- 고객만기연령
         , substring(max(t10.age_ccd), 2)                  as age_ccd           -- 연령구분코드
         , substring(max(t10.age_y5_blk_cd), 2)            as age_y5_blk_cd     -- 연령5년구간코드
         , substring(max(t10.sex_ccd), 2)                  as sex_ccd           -- 성별구분코드
         , to_number(substring(max(t10.lcr_tf), 2), '9')   as lcr_tf            -- 내국인TF
         , max(t11.hm_zpn)                                 as hm_zpn            -- 자택우편번호
         , max(t11.hm_adm_gds_apb_cd)                      as hm_adm_gds_apb_cd -- 자택행정GDS동코드
         , max(t11.hm_cou_gds_apb_cd)                      as hm_cou_gds_apb_cd -- 자택법정GDS동코드
         , substring(max(t10.shp_tps_clb_gcd), 2)          as shp_tps_clb_gcd   -- 신한그룹탑스클럽등급코드
         , max( case when t10.shp_co_cd = 'S001'                                -- 신한그룹사코드(신한은행)
                     then t10.ni_ts_d                                           -- 최초거래일자
                end )                                      as ni_ts_d           -- 최초거래일자(은행)
         , max( case when t10.shp_co_cd = 'S012'                                -- 신한그룹사코드(신한카드)
                     then t10.ni_ts_d                                           -- 최초거래일자
                end )                                      as ni_crd_iss_d      -- 최초거래일자(최초카드발급일자)
         , max( case when t10.shp_co_cd = 'S011'                                -- 신한그룹사코드(신한금융투자)
                     then t10.ni_ts_d                                           -- 최초거래일자
                end )                                      as ni_ac_opn_d       -- 최초거래일자(최초계좌개설일자)
         , max( case when t10.shp_co_cd = 'S016'                                -- 신한그룹사코드(신한생명)
                     then t10.ni_ts_d                                           -- 최초거래일자
                end )                                      as ni_are_d          -- 최초거래일자(최초계약일자)
         , max( case when t10.shp_co_cd = 'S001'                                -- 신한그룹사코드(신한은행)
                     then t10.cln_tf                                            -- 고객TF
                end )                                      as shb_cln_tf        -- 신한은행고객TF
         , max( case when t10.shp_co_cd = 'S012'                                -- 신한그룹사코드(신한카드)
                     then t10.cln_tf                                            -- 고객TF
                end )                                      as shc_cln_tf        -- 신한카드고객TF
         , max( case when t10.shp_co_cd = 'S011'                                -- 신한그룹사코드(신한금융투자)
                     then t10.cln_tf                                            -- 고객TF
                end )                                      as shi_cln_tf        -- 신한금융투자고객TF
         , max( case when t10.shp_co_cd = 'S016'                                -- 신한그룹사코드(신한생명)
                     then t10.cln_tf                                            -- 고객TF
                end )                                      as shl_cln_tf        -- 신한라이프고객TF
         , nvl(sum(t10.cln_tf), 0)                         as ts_shp_co_cn      -- 거래신한그룹사수
         , max( case when t10.shp_co_cd = 'S001'                                -- 신한그룹사코드(신한은행)
                     then t10.tps_clb_gcd                                       -- 탑스클럽등급코드
                end )                                      as shb_tps_clb_gcd   -- 신한은행탑스클럽등급코드
         , max( case when t10.shp_co_cd = 'S012'                                -- 신한그룹사코드(신한카드)
                     then t10.tps_clb_gcd                                       -- 탑스클럽등급코드
                end )                                      as shc_tps_clb_gcd   -- 신한카드탑스클럽등급코드
         , max( case when t10.shp_co_cd = 'S011'                                -- 신한그룹사코드(신한금융투자)
                     then t10.tps_clb_gcd                                       -- 탑스클럽등급코드
                end )                                      as shi_tps_clb_gcd   -- 신한금융투자탑스클럽등급코드
         , max( case when t10.shp_co_cd = 'S016'                                -- 신한그룹사코드(신한생명)
                     then t10.tps_clb_gcd                                       -- 탑스클럽등급코드
                end )                                      as shl_tps_clb_gcd   -- 신한라이프탑스클럽등급코드
         , max(case when trim(t12.shmdn) is not null                            -- 그룹MD번호
                    then 1
                    else 0
               end)                                        as psn_etk_tf        -- 개인사업자TF
         , max( case when t10.shp_co_cd = 'S001'                                -- 신한그룹사코드(신한은행)
                     then t10.atv_tf                                            -- 활동TF
                end )                                      as shb_atv_tf        -- 신한은행활동TF
         , max( case when t10.shp_co_cd = 'S011'                                -- 신한그룹사코드(신한금융투자)
                     then t10.atv_tf                                            -- 활동TF
                end )                                      as shi_atv_tf        -- 신한금융투자활동TF
         , max( case when t10.shp_co_cd = 'S016'                                -- 신한그룹사코드(신한생명)
                     then t10.atv_tf                                            -- 활동TF
                end )                                      as shl_atv_tf        -- 신한라이프활동TF
      from
           (
               select 'S012'                               as shp_co_cd         -- 신한그룹사코드(신한카드)
                    , t20.shmdn                                                 -- 그룹MD번호
                    , '4'||to_char(t20.cln_age, '999')     as cln_age           -- 고객연령
                    , '4'||to_char(t20.cln_xp_age, '999')  as cln_xp_age        -- 고객만기연령
                    , '4'||t20.age_ccd                     as age_ccd           -- 연령구분코드
                    , '4'||t20.age_y5_blk_cd               as age_y5_blk_cd     -- 연령5년구간코드
                    , '4'||t20.sex_ccd                     as sex_ccd           -- 성별구분코드
                    , '4'||to_char(t20.lcr_tf, '9')        as lcr_tf            -- 내국인TF
                    , '4'||t20.hm_zpn                      as hm_zpn            -- 자택우편번호
                    , '4'||t20.hm_adm_gds_apb_cd           as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                    , '4'||t20.hm_cou_gds_apb_cd           as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                    , t20.shp_tps_clb_gcd                                       -- 신한그룹탑스클럽등급코드
                    , t20.ni_crd_iss_d                     as ni_ts_d           -- 최초거래일자(최초카드발급일자)
                    , 1                                    as cln_tf            -- 고객TF
                    , t20.shc_tps_clb_gcd	              as tps_clb_gcd       -- 탑스클럽등급코드(신한카드탑스클럽등급코드)
                    , 0                                    as atv_tf	          -- 활동TF
                 from sh1.shcdcln001             t20                            -- CLN_일고객마스터_카드
                union all
               select 'S001'                               as shp_co_cd         -- 신한그룹사코드(신한은행)
                    , t20.shmdn                                                 -- 그룹MD번호
                    , '3'||to_char(t20.cln_xp_age, '999')  as cln_age           -- 고객연령
                    , '3'||to_char(t20.cln_xp_age, '999')  as cln_xp_age        -- 고객만기연령
                    , '3'||t20.age_ccd                     as age_ccd           -- 연령구분코드
                    , '3'||t20.age_y5_blk_cd               as age_y5_blk_cd     -- 연령5년구간코드
                    , '3'||t20.sex_ccd                     as sex_ccd           -- 성별구분코드
                    , '3'||to_char(t20.lcr_tf, '9')        as lcr_tf            -- 내국인TF
                    , '3'||t20.hm_zpn                      as hm_zpn            -- 자택우편번호
                    , '3'||t20.hm_adm_gds_apb_cd           as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                    , '3'||t20.hm_cou_gds_apb_cd           as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                    , t20.shp_tps_clb_gcd                                       -- 신한그룹탑스클럽등급코드
                    , t20.ni_ts_d                          as ni_ts_d           -- 최초거래일자(최초거래일자)
                    , 1                                    as cln_tf            -- 고객TF
                    , t20.shb_tps_clb_gcd	              as tps_clb_gcd       -- 탑스클럽등급코드(신한은행탑스클럽등급코드)
                    , t20.atv_tf                           as atv_tf	          -- 활동TF
                 from sh1.shbdcln001             t20                            -- CLN_일고객마스터_은행
                union all
               select 'S011'                               as shp_co_cd         -- 신한그룹사코드(신한금융투자)
                    , t20.shmdn                                                 -- 그룹MD번호
                    , '2'||to_char(t20.cln_xp_age, '999')  as cln_age           -- 고객연령
                    , '2'||to_char(t20.cln_xp_age, '999')  as cln_xp_age        -- 고객만기연령
                    , '2'||t20.age_ccd                     as age_ccd           -- 연령구분코드
                    , '2'||t20.age_y5_blk_cd               as age_y5_blk_cd     -- 연령5년구간코드
                    , '2'||t20.sex_ccd                     as sex_ccd           -- 성별구분코드
                    , '2'||to_char(t20.lcr_tf, '9')        as lcr_tf            -- 내국인TF
                    , '2'||t20.hm_zpn                      as hm_zpn            -- 자택우편번호
                    , '2'||' '                             as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                    , '2'||' '                             as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                    , t20.shp_tps_clb_gcd                                       -- 신한그룹탑스클럽등급코드
                    , t20.ni_ac_opn_d                      as ni_ts_d           -- 최초거래일자(최초계좌개설일자)
                    , 1                                    as cln_tf            -- 고객TF
                    , t20.shi_tps_clb_gcd	              as tps_clb_gcd       -- 탑스클럽등급코드(신한금융투자탑스클럽등급코드)
                    , t20.atv_tf                           as atv_tf	          -- 활동TF
                 from sh1.shidcln001             t20                            -- CLN_일고객마스터_금투
                union all
               select 'S016'                               as shp_co_cd         -- 신한그룹사코드(신한생명)
                    , t20.shmdn                                                 -- 그룹MD번호
                    , '1'||to_char(t20.cln_xp_age, '999')  as cln_age           -- 고객연령
                    , '1'||to_char(t20.cln_xp_age, '999')  as cln_xp_age        -- 고객만기연령
                    , '1'||t20.age_ccd                     as age_ccd           -- 연령구분코드
                    , '1'||t20.age_y5_blk_cd               as age_y5_blk_cd     -- 연령5년구간코드
                    , '1'||t20.sex_ccd                     as sex_ccd           -- 성별구분코드
                    , '1'||to_char(t20.lcr_tf, '9')        as lcr_tf            -- 내국인TF
                    , '1'||t20.hm_zpn                      as hm_zpn            -- 자택우편번호
                    , '1'||' '                             as hm_adm_gds_apb_cd -- 자택행정GDS동코드
                    , '1'||t20.hm_cou_gds_apb_cd           as hm_cou_gds_apb_cd -- 자택법정GDS동코드
                    , t20.shp_tps_clb_gcd                                       -- 신한그룹탑스클럽등급코드
                    , t20.ni_ts_d                          as ni_ts_d           -- 최초거래일자(최초계약일자)
                    , 1                                    as cln_tf            -- 고객TF
                    , t20.shl_tps_clb_gcd	              as tps_clb_gcd       -- 탑스클럽등급코드(신한라이프탑스클럽등급코드)
                    , t20.atv_tf                           as atv_tf	          -- 활동TF
                 from sh1.shldcln001             t20                            -- CLN_일고객마스터_라이프
           )                                     t10
      left outer join
           tmp_sh2.shddigd001_tmp01              t11                            -- IGD_일고객마스터_TMP01
        on t10.shmdn = t11.shmdn                                                -- 그룹MD번호
      left outer join
           (
               select t20.shmdn                                                 -- 그룹MD번호
                 from sh1.shbdcln003             t20                            -- CLN_일개인사업자마스터_은행
                union
               select t20.shmdn                                                 -- 그룹MD번호
                 from sh1.shcdcln003             t20                            -- CLN_일개인사업자마스터_카드
           )                                     t12
        on t10.shmdn = t12.shmdn                                                -- 그룹MD번호
     group by
           t10.shmdn                                                            -- 그룹MD번호
"""


"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shddigd001_tmp99', 'pk': ['shmdn']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shddigd001                                                  -- IGD_일고객마스터
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shddigd001                                                  -- IGD_일고객마스터
    (
           shmdn                                                                -- 그룹MD번호
         , aws_ld_dt                                                            -- AWS적재일시
         , cln_age                                                              -- 고객연령
         , cln_xp_age                                                           -- 고객만기연령
         , age_ccd                                                              -- 연령구분코드
         , age_y5_blk_cd                                                        -- 연령5년구간코드
         , sex_ccd                                                              -- 성별구분코드
         , lcr_tf                                                               -- 내국인TF
         , hm_zpn                                                               -- 자택우편번호
         , hm_adm_gds_apb_cd                                                    -- 자택행정GDS동코드
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , shp_tps_clb_gcd                                                      -- 신한그룹탑스클럽등급코드
         , ni_ts_d                                                              -- 최초거래일자
         , ni_crd_iss_d                                                         -- 최초카드발급일자
         , ni_ac_opn_d                                                          -- 최초계좌개설일자
         , ni_are_d                                                             -- 최초계약일자
         , shb_cln_tf                                                           -- 신한은행고객TF
         , shc_cln_tf                                                           -- 신한카드고객TF
         , shi_cln_tf                                                           -- 신한금융투자고객TF
         , shl_cln_tf                                                           -- 신한라이프고객TF
         , ts_shp_co_cn                                                         -- 거래신한그룹사수
         , shb_tps_clb_gcd                                                      -- 신한은행탑스클럽등급코드
         , shc_tps_clb_gcd                                                      -- 신한카드탑스클럽등급코드
         , shi_tps_clb_gcd                                                      -- 신한금융투자탑스클럽등급코드
         , shl_tps_clb_gcd                                                      -- 신한라이프탑스클럽등급코드
         , psn_etk_tf                                                           -- 개인사업자TF
         , shb_atv_tf                                                           -- 신한은행활동TF
         , shi_atv_tf                                                           -- 신한금융투자활동TF
         , shl_atv_tf                                                           -- 신한라이프활동TF
    )
    select shmdn                                                                -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , cln_age                                                              -- 고객연령
         , cln_xp_age                                                           -- 고객만기연령
         , age_ccd                                                              -- 연령구분코드
         , age_y5_blk_cd                                                        -- 연령5년구간코드
         , sex_ccd                                                              -- 성별구분코드
         , lcr_tf                                                               -- 내국인TF
         , hm_zpn                                                               -- 자택우편번호
         , hm_adm_gds_apb_cd                                                    -- 자택행정GDS동코드
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , shp_tps_clb_gcd                                                      -- 신한그룹탑스클럽등급코드
         , ni_ts_d                                                              -- 최초거래일자
         , ni_crd_iss_d                                                         -- 최초카드발급일자
         , ni_ac_opn_d                                                          -- 최초계좌개설일자
         , ni_are_d                                                             -- 최초계약일자
         , shb_cln_tf                                                           -- 신한은행고객TF
         , shc_cln_tf                                                           -- 신한카드고객TF
         , shi_cln_tf                                                           -- 신한금융투자고객TF
         , shl_cln_tf                                                           -- 신한라이프고객TF
         , ts_shp_co_cn                                                         -- 거래신한그룹사수
         , shb_tps_clb_gcd                                                      -- 신한은행탑스클럽등급코드
         , shc_tps_clb_gcd                                                      -- 신한카드탑스클럽등급코드
         , shi_tps_clb_gcd                                                      -- 신한금융투자탑스클럽등급코드
         , shl_tps_clb_gcd                                                      -- 신한라이프탑스클럽등급코드
         , psn_etk_tf                                                           -- 개인사업자TF
         , shb_atv_tf                                                           -- 신한은행활동TF
         , shi_atv_tf                                                           -- 신한금융투자활동TF
         , shl_atv_tf                                                           -- 신한라이프활동TF
      from tmp_sh2.shddigd001_tmp99                                             -- IGD_일고객마스터_TMP99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_99 = RedshiftQueryOperator(
        task_id='003_tmp_load_task_99',
        execute_query=insert_sql_for_tmp_2,
    )

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='004_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='005_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='006_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_99 >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end