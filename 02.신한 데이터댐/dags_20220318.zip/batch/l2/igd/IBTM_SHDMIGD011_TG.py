# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "노재홍"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["노재홍"]
__version__    = "1.0"
__maintainer__ = "노재홍"
__email__      = ""
__status__     = "Production"


"""
L0 데이터를 SH1 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 한글 테이블명
  - TMP_SH1 테이블명
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMIGD011_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = '(L2통합) IGD_월고객기본 배치프로그램'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'

"""
(@) TMP_SH1 테이블명 (TRUNCATE 대상)
"""
tmp_sh1_table = ['shdmigd011_tmp99']

"""
(@) TMP_SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""

############################################################################################
#  신한카드활동TF만 CLN_월고객기본_카드(sh1.shcmcln002)의 활동TF(atv_tf)에서 처리
############################################################################################

insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmigd011_tmp99                                        -- IGD_월고객기본_TMP99
    (
           ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , aws_ld_dt                                                            -- AWS적재일시
         , cln_age                                                              -- 고객연령
         , cln_xp_age                                                           -- 고객만기연령
         , age_ccd                                                              -- 연령구분코드
         , age_y5_blk_cd                                                        -- 연령5년구간코드
         , sex_ccd                                                              -- 성별구분코드
         , lcr_tf                                                               -- 내국인TF
         , hm_zpn                                                               -- 자택우편번호
         , hm_adm_gds_apb_cd                                                    -- 자택행정GDS동코드
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , shp_tps_clb_gcd                                                      -- 신한그룹탑스클럽등급코드
         , ni_ts_d                                                              -- 최초거래일자
         , ni_crd_iss_d                                                         -- 최초카드발급일자
         , ni_ac_opn_d                                                          -- 최초계좌개설일자
         , ni_are_d                                                             -- 최초계약일자
         , shb_cln_tf                                                           -- 신한은행고객TF
         , shc_cln_tf                                                           -- 신한카드고객TF
         , shi_cln_tf                                                           -- 신한금융투자고객TF
         , shl_cln_tf                                                           -- 신한라이프고객TF
         , ts_shp_co_cn                                                         -- 거래신한그룹사수
         , shb_tps_clb_gcd                                                      -- 신한은행탑스클럽등급코드
         , shc_tps_clb_gcd                                                      -- 신한카드탑스클럽등급코드
         , shi_tps_clb_gcd                                                      -- 신한금융투자탑스클럽등급코드
         , shl_tps_clb_gcd                                                      -- 신한라이프탑스클럽등급코드
         , psn_etk_tf                                                           -- 개인사업자TF
         , shb_atv_tf                                                           -- 신한은행활동TF
         , shc_atv_tf                                                           -- 신한카드활동TF
         , shi_atv_tf                                                           -- 신한금융투자활동TF
         , shl_atv_tf                                                           -- 신한라이프활동TF
    )
    select '{date_cd('P_TA_YM')}'                          as ta_ym             -- 기준년월
         , t10.shmdn                                                            -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , t10.cln_age                                                          -- 고객연령
         , t10.cln_xp_age                                                       -- 고객만기연령
         , t10.age_ccd                                                          -- 연령구분코드
         , t10.age_y5_blk_cd                                                    -- 연령5년구간코드
         , t10.sex_ccd                                                          -- 성별구분코드
         , t10.lcr_tf                                                           -- 내국인TF
         , t10.hm_zpn                                                           -- 자택우편번호
         , t10.hm_adm_gds_apb_cd                                                -- 자택행정GDS동코드
         , t10.hm_cou_gds_apb_cd                                                -- 자택법정GDS동코드
         , t10.shp_tps_clb_gcd                                                  -- 신한그룹탑스클럽등급코드
         , t10.ni_ts_d                                                          -- 최초거래일자
         , t10.ni_crd_iss_d                                                     -- 최초카드발급일자
         , t10.ni_ac_opn_d                                                      -- 최초계좌개설일자
         , t10.ni_are_d                                                         -- 최초계약일자
         , t10.shb_cln_tf                                                       -- 신한은행고객TF
         , t10.shc_cln_tf                                                       -- 신한카드고객TF
         , t10.shi_cln_tf                                                       -- 신한금융투자고객TF
         , t10.shl_cln_tf                                                       -- 신한라이프고객TF
         , t10.ts_shp_co_cn                                                     -- 거래신한그룹사수
         , t10.shb_tps_clb_gcd                                                  -- 신한은행탑스클럽등급코드
         , t10.shc_tps_clb_gcd                                                  -- 신한카드탑스클럽등급코드
         , t10.shi_tps_clb_gcd                                                  -- 신한금융투자탑스클럽등급코드
         , t10.shl_tps_clb_gcd                                                  -- 신한라이프탑스클럽등급코드
         , t10.psn_etk_tf                                                       -- 개인사업자TF
         , t10.shb_atv_tf                                                       -- 신한은행활동TF
         , nvl(t11.atv_tf, 0)                              as shc_atv_tf        -- 신한카드활동TF
         , t10.shi_atv_tf                                                       -- 신한금융투자활동TF
         , t10.shl_atv_tf                                                       -- 신한라이프활동TF
      from sh2.shddigd001                        t10                            -- IGD_일고객마스터
      left outer join
           sh1.shcmcln002                        t11                            -- CLN_월고객기본_카드
        on t10.shmdn = t11.shmdn                                                -- 그룹MD번호
       and t11.ta_ym = '{date_cd('P_TA_YM')}'                                   -- 기준년월
"""

"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmigd011_tmp99', 'pk': ['ta_ym', 'shmdn']},
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmigd011                                                  -- IGD_월고객기본
     where ta_ym = '{date_cd('P_TA_YM')}'                                       -- 기준년월
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shdmigd011                                                  -- IGD_월고객기본
    (
           ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , aws_ld_dt                                                            -- AWS적재일시
         , cln_age                                                              -- 고객연령
         , cln_xp_age                                                           -- 고객만기연령
         , age_ccd                                                              -- 연령구분코드
         , age_y5_blk_cd                                                        -- 연령5년구간코드
         , sex_ccd                                                              -- 성별구분코드
         , lcr_tf                                                               -- 내국인TF
         , hm_zpn                                                               -- 자택우편번호
         , hm_adm_gds_apb_cd                                                    -- 자택행정GDS동코드
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , shp_tps_clb_gcd                                                      -- 신한그룹탑스클럽등급코드
         , ni_ts_d                                                              -- 최초거래일자
         , ni_crd_iss_d                                                         -- 최초카드발급일자
         , ni_ac_opn_d                                                          -- 최초계좌개설일자
         , ni_are_d                                                             -- 최초계약일자
         , shb_cln_tf                                                           -- 신한은행고객TF
         , shc_cln_tf                                                           -- 신한카드고객TF
         , shi_cln_tf                                                           -- 신한금융투자고객TF
         , shl_cln_tf                                                           -- 신한라이프고객TF
         , ts_shp_co_cn                                                         -- 거래신한그룹사수
         , shb_tps_clb_gcd                                                      -- 신한은행탑스클럽등급코드
         , shc_tps_clb_gcd                                                      -- 신한카드탑스클럽등급코드
         , shi_tps_clb_gcd                                                      -- 신한금융투자탑스클럽등급코드
         , shl_tps_clb_gcd                                                      -- 신한라이프탑스클럽등급코드
         , psn_etk_tf                                                           -- 개인사업자TF
         , shb_atv_tf                                                           -- 신한은행활동TF
         , shc_atv_tf                                                           -- 신한카드활동TF
         , shi_atv_tf                                                           -- 신한금융투자활동TF
         , shl_atv_tf                                                           -- 신한라이프활동TF
    )
    select ta_ym                                                                -- 기준년월
         , shmdn                                                                -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'     as aws_ld_dt         -- AWS적재일시
         , cln_age                                                              -- 고객연령
         , cln_xp_age                                                           -- 고객만기연령
         , age_ccd                                                              -- 연령구분코드
         , age_y5_blk_cd                                                        -- 연령5년구간코드
         , sex_ccd                                                              -- 성별구분코드
         , lcr_tf                                                               -- 내국인TF
         , hm_zpn                                                               -- 자택우편번호
         , hm_adm_gds_apb_cd                                                    -- 자택행정GDS동코드
         , hm_cou_gds_apb_cd                                                    -- 자택법정GDS동코드
         , shp_tps_clb_gcd                                                      -- 신한그룹탑스클럽등급코드
         , ni_ts_d                                                              -- 최초거래일자
         , ni_crd_iss_d                                                         -- 최초카드발급일자
         , ni_ac_opn_d                                                          -- 최초계좌개설일자
         , ni_are_d                                                             -- 최초계약일자
         , shb_cln_tf                                                           -- 신한은행고객TF
         , shc_cln_tf                                                           -- 신한카드고객TF
         , shi_cln_tf                                                           -- 신한금융투자고객TF
         , shl_cln_tf                                                           -- 신한라이프고객TF
         , ts_shp_co_cn                                                         -- 거래신한그룹사수
         , shb_tps_clb_gcd                                                      -- 신한은행탑스클럽등급코드
         , shc_tps_clb_gcd                                                      -- 신한카드탑스클럽등급코드
         , shi_tps_clb_gcd                                                      -- 신한금융투자탑스클럽등급코드
         , shl_tps_clb_gcd                                                      -- 신한라이프탑스클럽등급코드
         , psn_etk_tf                                                           -- 개인사업자TF
         , shb_atv_tf                                                           -- 신한은행활동TF
         , shc_atv_tf                                                           -- 신한카드활동TF
         , shi_atv_tf                                                           -- 신한금융투자활동TF
         , shl_atv_tf                                                           -- 신한라이프활동TF
      from tmp_sh2.shdmigd011_tmp99                                             -- IGD_월고객기본_TMP99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]

### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh1_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='004_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end