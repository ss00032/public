# -*- coding: utf-8 -*-

from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd.utils import *
from sgd import config
from sgd.date_util import *


__author__     = "이종호"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["이종호"]
__version__    = "1.0"
__maintainer__ = "이종호"
__email__      = "hijack72@xgm.co.kr"
__status__     = "Production"


"""
L1 데이터를 SH2 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 : IGD_월고객거래실적_카드
  - 프로그램 ID  : IBTM_SHDMIGD008_TG
  - 한글 테이블명: IGD_월고객거래실적_카드
  - TMP_SH2 테이블명: tmp_sh2.shdmigd008_tmp99
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMIGD008_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = 'IGD_월고객거래실적_카드'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) TMP_SH2 테이블명 (TRUNCATE 대상)
"""
tmp_sh2_table = ['shdmigd008_tmp99']

"""
(@) TMP_SH2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmigd008_tmp99
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , crd_lln_al                             -- 카드론대출잔액
         , dfl_ln_al                              -- 대환론대출잔액
         , fnc_ln_al                              -- 오토금융대출잔액
         , fna_ncr_ln_al                          -- 할부금융신차대출잔액
         , fna_uca_ln_al                          -- 할부금융중고차대출잔액
         , atl_ln_al                              -- 오토리스대출잔액
         , ltm_rntc_ln_al                         -- 장기렌터카대출잔액
         , cre_cl_uea                             -- 신용신판이용금액
         , chc_uea                                -- 체크카드이용금액
         , p_uea                                  -- 일시불이용금액
         , utb_uea                                -- 공과금이용금액
         , cmu_rain_uea                           -- 통신비이용금액
         , irg_uea                                -- 보험료이용금액
         , trf_uea                                -- 교통이용금액
         , dot_uea                                -- 외식이용금액
         , car_oln_uea                            -- 자동차주유이용금액
         , cnvs_uea                               -- 편의점이용금액
         , byu_hlt_uea                            -- 미용건강이용금액
         , dpr_uea                                -- 백화점이용금액
         , bkry_uea                               -- 제과이용금액
         , hspt_phmc_uea                          -- 병원약국이용금액
         , crd_lon_ue_ct                          -- 카드론이용건수
         , dfl_ue_ct                              -- 대환론이용건수
         , cre_cl_ue_ct                           -- 신용신판이용건수
         , chc_ue_ct                              -- 체크카드이용건수
         , p_ue_ct                                -- 일시불이용건수
         , ns_ue_ct                               -- 할부이용건수
         , vv_cl_ue_ct                            -- 리볼빙신판이용건수
         , vv_cv_ue_ct                            -- 리볼빙현금서비스이용건수
         , cv_ue_ct                               -- 현금서비스이용건수
         , fna_ncr_lna                            -- 할부금융신차대출금액
         , fna_ncr_ls_rca                         -- 할부금융신차최종입금금액
         , fna_uca_lna                            -- 할부금융중고차대출금액
         , fna_uca_ls_rca                         -- 할부금융중고차최종입금금액
         , atl_lna                                -- 오토리스대출금액
         , atl_ls_rca                             -- 오토리스최종입금금액
         , ltm_rntc_lna                           -- 장기렌터카대출금액
         , ltm_rntc_ls_rca                        -- 장기렌터카최종입금금액
         , fna_ncr_ln_lat_ct                      -- 할부금융신차대출신규건수
         , fna_uca_ln_lat_ct                      -- 할부금융중고차대출신규건수
         , atl_ln_lat_ct                          -- 오토리스대출신규건수
         , ltm_rntc_ln_lat_ct                     -- 장기렌터카대출신규건수
         , crd_lln_lat_ct                         -- 카드론대출신규건수
         , df_lln_lat_ct                          -- 대환론대출신규건수
         , cre_crd_lat_iss_ue_ct                  -- 신용카드신규발급이용건수
         , chc_lat_iss_ue_ct                      -- 체크카드신규발급이용건수
         , lat_p_ue_ct                            -- 신규일시불이용건수
         , lat_ns_ue_ct                           -- 신규할부이용건수
         , lat_cv_ue_ct                           -- 신규현금서비스이용건수
         , fna_ncr_ln_ce_ct                       -- 할부금융신차대출취소건수
         , fna_uca_ln_ce_ct                       -- 할부금융중고차대출취소건수
         , atl_ln_ce_ct                           -- 오토리스대출취소건수
         , ltm_rntc_ln_ce_ct                      -- 장기렌터카대출취소건수
         , crd_lln_ce_ct                          -- 카드론대출취소건수
         , df_lln_ce_ct                           -- 대환론대출취소건수
         )
    select '{date_cd('P_TA_YM')}'                                           as ta_ym                       -- 기준년월
         , t10.shmdn                                                                                       -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul'                                                     -- aws적재일시
         , sum(case when t10.shd_pd_zcd = 'C41' then t10.ln_al  else 0 end)    as crd_lln_al               -- 카드론대출잔액
         , sum(case when t10.shd_pd_zcd = 'C42' then t10.ln_al  else 0 end)    as dfl_ln_al                -- 대환론대출잔액
         , sum(case when t10.shd_pd_zcd in ('C51','C52','C53','C54')
                    then t10.ln_al
                    else 0
               end)                                                            as fnc_ln_al                -- 오토금융대출잔액
         , sum(case when t10.shd_pd_zcd = 'C51' then t10.ln_al  else 0 end)    as fna_ncr_ln_al            -- 할부금융신차대출잔액
         , sum(case when t10.shd_pd_zcd = 'C52' then t10.ln_al  else 0 end)    as fna_uca_ln_al            -- 할부금융중고차대출잔액
         , sum(case when t10.shd_pd_zcd = 'C53' then t10.ln_al  else 0 end)    as atl_ln_al                -- 오토리스대출잔액
         , sum(case when t10.shd_pd_zcd = 'C54' then t10.ln_al  else 0 end)    as ltm_rntc_ln_al           -- 장기렌터카대출잔액
         , sum(case when t10.shd_pd_zcd = 'C10' then t10.to_uea else 0 end)    as cre_cl_uea               -- 신용신판이용금액
         , sum(case when t10.shd_pd_zcd = 'C31' then t10.to_uea else 0 end)    as chc_uea                  -- 체크카드이용금액
         , sum(case when t10.shd_pd_zcd = 'C11' then t10.to_uea else 0 end)    as p_uea                    -- 일시불이용금액
         , sum(nvl(t11.utb_uea       ,0))                                      as utb_uea                  -- 공과금이용금액
         , sum(nvl(t11.cmu_rain_uea  ,0))                                      as cmu_rain_uea             -- 통신비이용금액
         , sum(nvl(t11.irg_uea       ,0))                                      as irg_uea                  -- 보험료이용금액
         , sum(nvl(t11.trf_uea       ,0))                                      as trf_uea                  -- 교통이용금액
         , sum(nvl(t11.dot_uea       ,0))                                      as dot_uea                  -- 외식이용금액
         , sum(nvl(t11.car_oln_uea   ,0))                                      as car_oln_uea              -- 자동차주유이용금액
         , sum(nvl(t11.cnvs_uea      ,0))                                      as cnvs_uea                 -- 편의점이용금액
         , sum(nvl(t11.byu_hlt_uea   ,0))                                      as byu_hlt_uea              -- 미용건강이용금액
         , sum(nvl(t11.dpr_uea       ,0))                                      as dpr_uea                  -- 백화점이용금액
         , sum(nvl(t11.bkry_uea      ,0))                                      as bkry_uea                 -- 제과이용금액
         , sum(nvl(t11.hspt_phmc_uea ,0))                                      as hspt_phmc_uea            -- 병원약국이용금액
         , sum(case when t10.shd_pd_zcd = 'C41' then t10.to_ue_ct  else 0 end) as crd_lon_ue_ct           -- 카드론이용건수
         , sum(case when t10.shd_pd_zcd = 'C42' then t10.to_ue_ct  else 0 end) as dfl_ue_ct               -- 대환론이용건수
         , sum(case when t10.shd_pd_zcd = 'C10' then t10.to_ue_ct  else 0 end) as cre_cl_ue_ct            -- 신용신판이용건수
         , sum(case when t10.shd_pd_zcd = 'C31' then t10.to_ue_ct  else 0 end) as chc_ue_ct               -- 체크카드이용건수
         , sum(case when t10.shd_pd_zcd = 'C11' then t10.to_ue_ct  else 0 end) as p_ue_ct                 -- 일시불이용건수
         , sum(case when t10.shd_pd_zcd = 'C12' then t10.to_ue_ct  else 0 end) as ns_ue_ct                -- 할부이용건수
         , sum(case when t10.shd_pd_zcd = 'C13' then t10.to_ue_ct  else 0 end) as vv_cl_ue_ct             -- 리볼빙신판이용건수
         , sum(case when t10.shd_pd_zcd = 'C22' then t10.to_ue_ct  else 0 end) as vv_cv_ue_ct             -- 리볼빙현금서비스이용건수
         , sum(case when t10.shd_pd_zcd = 'C21' then t10.to_ue_ct  else 0 end) as cv_ue_ct                -- 현금서비스이용건수
         , sum(case when t10.shd_pd_zcd = 'C51' then t10.to_uea	   else 0 end) as fna_ncr_lna             -- 할부금융신차대출금액
         , sum(case when t10.shd_pd_zcd = 'C51' then t10.rca       else 0 end) as fna_ncr_ls_rca          -- 할부금융신차최종입금금액
         , sum(case when t10.shd_pd_zcd = 'C52' then t10.to_uea    else 0 end) as fna_uca_lna             -- 할부금융중고차대출금액
         , sum(case when t10.shd_pd_zcd = 'C52' then t10.rca       else 0 end) as fna_uca_ls_rca          -- 할부금융중고차최종입금금액
         , sum(case when t10.shd_pd_zcd = 'C53' then t10.to_uea    else 0 end) as atl_lna                 -- 오토리스대출금액
         , sum(case when t10.shd_pd_zcd = 'C53' then t10.rca       else 0 end) as atl_ls_rca              -- 오토리스최종입금금액
         , sum(case when t10.shd_pd_zcd = 'C54' then t10.to_uea    else 0 end) as ltm_rntc_lna            -- 장기렌터카대출금액
         , sum(case when t10.shd_pd_zcd = 'C54' then t10.rca       else 0 end) as ltm_rntc_ls_rca         -- 장기렌터카최종입금금액
         , sum(case when t10.shd_pd_zcd = 'C51' then t10.lat_ue_tf else 0 end) as fna_ncr_ln_lat_ct       -- 할부금융신차대출신규건수
         , sum(case when t10.shd_pd_zcd = 'C52' then t10.lat_ue_tf else 0 end) as fna_uca_ln_lat_ct       -- 할부금융중고차대출신규건수
         , sum(case when t10.shd_pd_zcd = 'C53' then t10.lat_ue_tf else 0 end) as atl_ln_lat_ct           -- 오토리스대출신규건수
         , sum(case when t10.shd_pd_zcd = 'C54' then t10.lat_ue_tf else 0 end) as ltm_rntc_ln_lat_ct      -- 장기렌터카대출신규건수
         , sum(case when t10.shd_pd_zcd = 'C41' then t10.lat_ue_tf else 0 end) as crd_lln_lat_ct          -- 카드론대출신규건수
         , sum(case when t10.shd_pd_zcd = 'C42' then t10.lat_ue_tf else 0 end) as df_lln_lat_ct           -- 대환론대출신규건수
         , sum(case when t10.shd_pd_zcd = 'C10' then t10.lat_ue_tf else 0 end) as cre_crd_lat_iss_ue_ct   -- 신용카드신규발급이용건수
         , sum(case when t10.shd_pd_zcd = 'C31' then t10.lat_ue_tf else 0 end) as chc_lat_iss_ue_ct       -- 체크카드신규발급이용건수
         , sum(case when t10.shd_pd_zcd = 'C11' then t10.lat_ue_tf else 0 end) as lat_p_ue_ct             -- 신규일시불이용건수
         , sum(case when t10.shd_pd_zcd = 'C12' then t10.lat_ue_tf else 0 end) as lat_ns_ue_ct            -- 신규할부이용건수
         , sum(case when t10.shd_pd_zcd = 'C21' then t10.lat_ue_tf else 0 end) as lat_cv_ue_ct            -- 신규현금서비스이용건수
         , sum(case when t10.shd_pd_zcd = 'C51' then t10.ce_tf     else 0 end)fna_ncr_ln_ce_ct            -- 할부금융신차대출취소건수
         , sum(case when t10.shd_pd_zcd = 'C52' then t10.ce_tf     else 0 end)fna_uca_ln_ce_ct            -- 할부금융중고차대출취소건수
         , sum(case when t10.shd_pd_zcd = 'C53' then t10.ce_tf     else 0 end)atl_ln_ce_ct                -- 오토리스대출취소건수
         , sum(case when t10.shd_pd_zcd = 'C54' then t10.ce_tf     else 0 end)ltm_rntc_ln_ce_ct           -- 장기렌터카대출취소건수
         , sum(case when t10.shd_pd_zcd = 'C41' then t10.ce_tf     else 0 end)crd_lln_ce_ct               -- 카드론대출취소건수
         , sum(case when t10.shd_pd_zcd = 'C42' then t10.ce_tf     else 0 end)df_lln_ce_ct                -- 대환론대출취소건수
      from sh1.shcmtrs001 t10                     -- TRS_월고객카드거래실적_카드
      left outer join (/* 가맹점업종코드를 이용한 추출*/
                       select sgdmd
                            , sum(case when mct_ry_cd ='131000' then saa else 0 end )               as utb_uea         -- 공과금이용금액
                            , sum(case when mct_ry_cd in ('451000', '452000') then saa else 0 end ) as cmu_rain_uea    -- 통신비이용금액
                            , sum(case when mct_ry_cd in ('721000', '722000', '723000'
                                                        , '724000', '725000', '726000')
                                       then saa else 0 end )                                        as irg_uea         -- 보험료이용금액
                            , sum(case when mct_ry_cd in ('123000', '124000', '125000'
                                                        , '126000')
                                       then saa else 0 end )                                        as trf_uea         -- 교통이용금액
                            , sum(case when substring(mct_ry_cd, 1, 1) = '3' then saa else 0 end )  as dot_uea         -- 외식이용금액
                            , sum(case when mct_ry_cd in ('741000', '742000', '765000'
                                                        , '767000', '911000', '912000'
                                                        , '913000', '921000', '922000'
                                                        , '923000', '931000', '941000'
                                                        , '942000', '951000')
                                       then saa else 0 end )                                        as car_oln_uea     -- 자동차주유이용금액
                            , sum(case when mct_ry_cd in ('215000') then saa else 0 end )           as cnvs_uea        -- 편의점이용금액
                            , sum(case when mct_ry_cd in ('242000', '672000', '671000'
                                                        , '841000', '842000', '843000'
                                                        , '844000', '845000', '846000'
                                                        , '847000', '848000')
                                       then saa else 0 end )                                        as byu_hlt_uea     -- 미용건강이용금액
                            , sum(case when mct_ry_cd in ('211000') then saa else 0 end )           as dpr_uea         -- 백화점이용금액
                            , sum(case when mct_ry_cd in ('327000', '241000') then saa else 0 end ) as bkry_uea        -- 제과이용금액
                            , sum(case when mct_ry_cd in ('811000', '812000', '813000'
                                                        , '814000', '815000', '816000'
                                                        , '821000', '822000', '823000'
                                                        , '824000', '831000')
                                       then saa else 0 end )                                        as hspt_phmc_uea   -- 병원약국이용금액
                         from shc.mtfua0034                    --일매출
                        where substring(ced, 1, 6) = '{date_cd('P_TA_YM')}'
                          and ce_si_tf = '0'                   --취소전표tf
                        group by sgdmd
                      )t11
        on t10.shmdn = t11.sgdmd
     where t10.ta_ym = '{date_cd('P_TA_YM')}'
     group by t10.shmdn
"""

"""
(@) TMP_SH1 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명  나열
"""
insert_sql_for_tmp = [insert_sql_for_tmp_1]

"""
(@) TMP_SH2 테이블 PK 정 보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmigd008_tmp99', 'pk': ['shmdn']},
}
"""
(@) SH2 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmigd008
    where ta_ym = '{date_cd('P_TA_YM')}'
"""

"""
(@) SH2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shdmigd008
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , crd_lln_al                             -- 카드론대출잔액
         , dfl_ln_al                              -- 대환론대출잔액
         , fnc_ln_al                              -- 오토금융대출잔액
         , fna_ncr_ln_al                          -- 할부금융신차대출잔액
         , fna_uca_ln_al                          -- 할부금융중고차대출잔액
         , atl_ln_al                              -- 오토리스대출잔액
         , ltm_rntc_ln_al                         -- 장기렌터카대출잔액
         , cre_cl_uea                             -- 신용신판이용금액
         , chc_uea                                -- 체크카드이용금액
         , p_uea                                  -- 일시불이용금액
         , utb_uea                                -- 공과금이용금액
         , cmu_rain_uea                           -- 통신비이용금액
         , irg_uea                                -- 보험료이용금액
         , trf_uea                                -- 교통이용금액
         , dot_uea                                -- 외식이용금액
         , car_oln_uea                            -- 자동차주유이용금액
         , cnvs_uea                               -- 편의점이용금액
         , byu_hlt_uea                            -- 미용건강이용금액
         , dpr_uea                                -- 백화점이용금액
         , bkry_uea                               -- 제과이용금액
         , hspt_phmc_uea                          -- 병원약국이용금액
         , crd_lon_ue_ct                          -- 카드론이용건수
         , dfl_ue_ct                              -- 대환론이용건수
         , cre_cl_ue_ct                           -- 신용신판이용건수
         , chc_ue_ct                              -- 체크카드이용건수
         , p_ue_ct                                -- 일시불이용건수
         , ns_ue_ct                               -- 할부이용건수
         , vv_cl_ue_ct                            -- 리볼빙신판이용건수
         , vv_cv_ue_ct                            -- 리볼빙현금서비스이용건수
         , cv_ue_ct                               -- 현금서비스이용건수
         , fna_ncr_lna                            -- 할부금융신차대출금액
         , fna_ncr_ls_rca                         -- 할부금융신차최종입금금액
         , fna_uca_lna                            -- 할부금융중고차대출금액
         , fna_uca_ls_rca                         -- 할부금융중고차최종입금금액
         , atl_lna                                -- 오토리스대출금액
         , atl_ls_rca                             -- 오토리스최종입금금액
         , ltm_rntc_lna                           -- 장기렌터카대출금액
         , ltm_rntc_ls_rca                        -- 장기렌터카최종입금금액
         , fna_ncr_ln_lat_ct                      -- 할부금융신차대출신규건수
         , fna_uca_ln_lat_ct                      -- 할부금융중고차대출신규건수
         , atl_ln_lat_ct                          -- 오토리스대출신규건수
         , ltm_rntc_ln_lat_ct                     -- 장기렌터카대출신규건수
         , crd_lln_lat_ct                         -- 카드론대출신규건수
         , df_lln_lat_ct                          -- 대환론대출신규건수
         , cre_crd_lat_iss_ue_ct                  -- 신용카드신규발급이용건수
         , chc_lat_iss_ue_ct                      -- 체크카드신규발급이용건수
         , lat_p_ue_ct                            -- 신규일시불이용건수
         , lat_ns_ue_ct                           -- 신규할부이용건수
         , lat_cv_ue_ct                           -- 신규현금서비스이용건수
         , fna_ncr_ln_ce_ct                       -- 할부금융신차대출취소건수
         , fna_uca_ln_ce_ct                       -- 할부금융중고차대출취소건수
         , atl_ln_ce_ct                           -- 오토리스대출취소건수
         , ltm_rntc_ln_ce_ct                      -- 장기렌터카대출취소건수
         , crd_lln_ce_ct                          -- 카드론대출취소건수
         , df_lln_ce_ct                           -- 대환론대출취소건수
         )
    select ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , crd_lln_al                             -- 카드론대출잔액
         , dfl_ln_al                              -- 대환론대출잔액
         , fnc_ln_al                              -- 오토금융대출잔액
         , fna_ncr_ln_al                          -- 할부금융신차대출잔액
         , fna_uca_ln_al                          -- 할부금융중고차대출잔액
         , atl_ln_al                              -- 오토리스대출잔액
         , ltm_rntc_ln_al                         -- 장기렌터카대출잔액
         , cre_cl_uea                             -- 신용신판이용금액
         , chc_uea                                -- 체크카드이용금액
         , p_uea                                  -- 일시불이용금액
         , utb_uea                                -- 공과금이용금액
         , cmu_rain_uea                           -- 통신비이용금액
         , irg_uea                                -- 보험료이용금액
         , trf_uea                                -- 교통이용금액
         , dot_uea                                -- 외식이용금액
         , car_oln_uea                            -- 자동차주유이용금액
         , cnvs_uea                               -- 편의점이용금액
         , byu_hlt_uea                            -- 미용건강이용금액
         , dpr_uea                                -- 백화점이용금액
         , bkry_uea                               -- 제과이용금액
         , hspt_phmc_uea                          -- 병원약국이용금액
         , crd_lon_ue_ct                          -- 카드론이용건수
         , dfl_ue_ct                              -- 대환론이용건수
         , cre_cl_ue_ct                           -- 신용신판이용건수
         , chc_ue_ct                              -- 체크카드이용건수
         , p_ue_ct                                -- 일시불이용건수
         , ns_ue_ct                               -- 할부이용건수
         , vv_cl_ue_ct                            -- 리볼빙신판이용건수
         , vv_cv_ue_ct                            -- 리볼빙현금서비스이용건수
         , cv_ue_ct                               -- 현금서비스이용건수
         , fna_ncr_lna                            -- 할부금융신차대출금액
         , fna_ncr_ls_rca                         -- 할부금융신차최종입금금액
         , fna_uca_lna                            -- 할부금융중고차대출금액
         , fna_uca_ls_rca                         -- 할부금융중고차최종입금금액
         , atl_lna                                -- 오토리스대출금액
         , atl_ls_rca                             -- 오토리스최종입금금액
         , ltm_rntc_lna                           -- 장기렌터카대출금액
         , ltm_rntc_ls_rca                        -- 장기렌터카최종입금금액
         , fna_ncr_ln_lat_ct                      -- 할부금융신차대출신규건수
         , fna_uca_ln_lat_ct                      -- 할부금융중고차대출신규건수
         , atl_ln_lat_ct                          -- 오토리스대출신규건수
         , ltm_rntc_ln_lat_ct                     -- 장기렌터카대출신규건수
         , crd_lln_lat_ct                         -- 카드론대출신규건수
         , df_lln_lat_ct                          -- 대환론대출신규건수
         , cre_crd_lat_iss_ue_ct                  -- 신용카드신규발급이용건수
         , chc_lat_iss_ue_ct                      -- 체크카드신규발급이용건수
         , lat_p_ue_ct                            -- 신규일시불이용건수
         , lat_ns_ue_ct                           -- 신규할부이용건수
         , lat_cv_ue_ct                           -- 신규현금서비스이용건수
         , fna_ncr_ln_ce_ct                       -- 할부금융신차대출취소건수
         , fna_uca_ln_ce_ct                       -- 할부금융중고차대출취소건수
         , atl_ln_ce_ct                           -- 오토리스대출취소건수
         , ltm_rntc_ln_ce_ct                      -- 장기렌터카대출취소건수
         , crd_lln_ce_ct                          -- 카드론대출취소건수
         , df_lln_ce_ct                           -- 대환론대출취소건수
      from tmp_sh2.shdmigd008_tmp99
"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh2 = [insert_sql_1]
### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh2_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    redshift_pk_valid_task = RedshiftPkValidOperator(
        task_id='003_redshift_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='003_sh1_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='005_sh1_load_task_' + str(insert_sql_for_sh2.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh2]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_end >> redshift_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end