# -*- coding: utf-8 -*-

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from sgd.operators.tmp_truncate_operator import TmpTruncateOperator
from sgd.operators.redshift_query_operator import RedshiftQueryOperator
from sgd.operators.redshift_pk_valid_operator import RedshiftPkValidOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *

__author__     = "이일주"
__copyright__  = "Copyright 2021, Shinhan Datadam"
__credits__    = ["이일주"]
__version__    = "1.0"
__maintainer__ = "이일주"
__email__      = "LEE1122334@xgm.co.kr"
__status__     = "Production"

"""
L0 데이터를 SH2 으로 적재하는 DAG 템플릿

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID  : IBTM_SHDMIGD005_TG
  - 한글 테이블명: IGD_월개인사업자자산실적
  - tmp_sh2 테이블명: tmp_sh2.shdmigd005_tmp99
"""

################################################################################
### Start of Batch Configuration

"""
(@) 프로그램 ID
"""
pgm_id = 'IBTM_SHDMIGD005_TG'

"""
(@) 적재 타겟 테이블 한글명
"""
description = 'IGD_월개인사업자자산실적'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

##날짜변수 사용관련 
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

# 적재 스키마명
target_schema = 'sh2'
tmp_schema = 'tmp_sh2'

"""
(@) tmp_sh2 테이블명 (TRUNCATE 대상)
"""
tmp_sh2_table = ['shdmigd005_tmp99','shdmigd005_tmp01']

"""
(@) tmp_sh2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_1 = f"""
    insert into tmp_sh2.shdmigd005_tmp01
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , psn_etk_ln_al                          -- 개인사업자대출잔액
         , etk_crd_cl_uea                         -- 사업자카드신판이용금액
         , etk_crd_cre_cl_uea                     -- 사업자카드신용신판이용금액
         , etk_crd_chc_uea                        -- 사업자카드체크카드이용금액
         , etk_crd_p_uea                          -- 사업자카드일시불이용금액
         , etk_crd_ns_uea                         -- 사업자카드할부이용금액
         , etk_crd_vv_cl_uea                      -- 사업자카드리볼빙신판이용금액
         , etk_crd_vv_cv_uea                      -- 사업자카드리볼빙현금서비스이용금액
         , etk_crd_cv_uea                         -- 사업자카드현금서비스이용금액
         , etk_crd_cl_ue_ct                       -- 사업자카드신판이용건수
         , etk_crd_cre_cl_ue_ct                   -- 사업자카드신용신판이용건수
         , etk_crd_chc_ue_ct                      -- 사업자카드체크카드이용건수
         , etk_crd_p_ue_ct                        -- 사업자카드일시불이용건수
         , etk_crd_ns_ue_ct                       -- 사업자카드할부이용건수
         , etk_crd_vv_cl_ue_ct                    -- 사업자카드리볼빙신판이용건수
         , etk_crd_vv_cv_ue_ct                    -- 사업자카드리볼빙현금서비스이용건수
         , etk_crd_cv_ue_ct                       -- 사업자카드현금서비스이용건수
         , saa                                    -- 매출금액
         , shc_saa                                -- 신한카드매출금액
         , acco_saa                               -- 타카드사매출금액
         , liq_rca                                -- 유동성입금금액
         , liq_aow_at                             -- 유동성출금금액
         )
    select t10.ta_ym
         , t10.shmdn
         , sum(t10.psn_etk_ln_al)                     as psn_etk_ln_al              -- 개인사업자대출잔액
         , sum(t10.etk_crd_cl_uea)                    as etk_crd_cl_uea             -- 사업자카드신판이용금액
         , sum(t10.etk_crd_cre_cl_uea)                as etk_crd_cre_cl_uea         -- 사업자카드신용신판이용금액
         , sum(t10.etk_crd_chc_uea)                   as etk_crd_chc_uea            -- 사업자카드체크카드이용금액
         , sum(t10.etk_crd_p_uea)                     as etk_crd_p_uea              -- 사업자카드일시불이용금액
         , sum(t10.etk_crd_ns_uea)                    as etk_crd_ns_uea             -- 사업자카드할부이용금액
         , sum(t10.etk_crd_vv_cl_uea)                 as etk_crd_vv_cl_uea          -- 사업자카드리볼빙신판이용금액
         , sum(t10.etk_crd_vv_cv_uea)                 as etk_crd_vv_cv_uea          -- 사업자카드리볼빙현금서비스이용금액
         , sum(t10.etk_crd_cv_uea)                    as etk_crd_cv_uea             -- 사업자카드현금서비스이용금액
         , sum(t10.etk_crd_cl_ue_ct)                  as etk_crd_cl_ue_ct           -- 사업자카드신판이용건수
         , sum(t10.etk_crd_cre_cl_ue_ct)              as etk_crd_cre_cl_ue_ct       -- 사업자카드신용신판이용건수
         , sum(t10.etk_crd_chc_ue_ct)                 as etk_crd_chc_ue_ct          -- 사업자카드체크카드이용건수
         , sum(t10.etk_crd_p_ue_ct)                   as etk_crd_p_ue_ct            -- 사업자카드일시불이용건수
         , sum(t10.etk_crd_ns_ue_ct)                  as etk_crd_ns_ue_ct           -- 사업자카드할부이용건수
         , sum(t10.etk_crd_vv_cl_ue_ct)               as etk_crd_vv_cl_ue_ct        -- 사업자카드리볼빙신판이용건수
         , sum(t10.etk_crd_vv_cv_ue_ct)               as etk_crd_vv_cv_ue_ct        -- 사업자카드리볼빙현금서비스이용건수
         , sum(t10.etk_crd_cv_ue_ct)                  as etk_crd_cv_ue_ct           -- 사업자카드현금서비스이용건수
         , sum(t10.saa)                               as saa                        -- 매출금액
         , sum(t10.shc_saa)                           as shc_saa                    -- 신한카드매출금액
         , sum(t10.acco_saa)                          as acco_saa                   -- 타카드사매출금액
         , sum(t10.liq_rca)                           as liq_rca                    -- 유동성입금금액
         , sum(t10.liq_aow_at)                        as liq_aow_at                 -- 유동성출금금액
      from (select t10.ta_ym
                 , t10.rpk_sgdmd                              as shmdn
                 , 0                                          as psn_etk_ln_al              -- 개인사업자대출잔액
                 , nvl(t11.cl_hga,0)                          as etk_crd_cl_uea             -- 사업자카드신판이용금액
                 , nvl(t11.cre_cl_hga,0)                      as etk_crd_cre_cl_uea         -- 사업자카드신용신판이용금액
                 , nvl(t11.chc_hga,0)                         as etk_crd_chc_uea            -- 사업자카드체크카드이용금액
                 , nvl(t11.p_hga,0)                           as etk_crd_p_uea              -- 사업자카드일시불이용금액
                 , nvl(t11.ns_hga,0)                          as etk_crd_ns_uea             -- 사업자카드할부이용금액
                 , nvl(t11.vv_cl_hga,0)                       as etk_crd_vv_cl_uea          -- 사업자카드리볼빙신판이용금액
                 , nvl(t11.vv_cv_hga,0)                       as etk_crd_vv_cv_uea          -- 사업자카드리볼빙현금서비스이용금액
                 , nvl(t11.cv_hga,0)                          as etk_crd_cv_uea             -- 사업자카드현금서비스이용금액
                 , nvl(t11.cl_ue_ct,0)                        as etk_crd_cl_ue_ct           -- 사업자카드신판이용건수
                 , nvl(t11.cre_cl_ue_ct,0)                    as etk_crd_cre_cl_ue_ct       -- 사업자카드신용신판이용건수
                 , nvl(t11.chc_ue_ct,0)                       as etk_crd_chc_ue_ct          -- 사업자카드체크카드이용건수
                 , nvl(t11.p_ue_ct,0)                         as etk_crd_p_ue_ct            -- 사업자카드일시불이용건수
                 , nvl(t11.ns_ue_ct,0)                        as etk_crd_ns_ue_ct           -- 사업자카드할부이용건수
                 , nvl(t11.vv_cl_ue_ct,0)                     as etk_crd_vv_cl_ue_ct        -- 사업자카드리볼빙신판이용건수
                 , nvl(t11.vv_cv_ue_ct,0)                     as etk_crd_vv_cv_ue_ct        -- 사업자카드리볼빙현금서비스이용건수
                 , nvl(t11.cv_ue_ct,0)                        as etk_crd_cv_ue_ct           -- 사업자카드현금서비스이용건수
                 , 0                                          as saa                        -- 매출금액
                 , 0                                          shc_saa                       -- 신한카드매출금액
                 , 0                                          acco_saa                      -- 타카드사매출금액
                 , 0                                          liq_rca                       -- 유동성입금금액
                 , 0                                          liq_aow_at                    -- 유동성출금금액
              from shc.mtdia0005 t10 --월가맹점디멘젼
              left outer join
                  (select t21.ta_ym
                        , t21.sgdmd
                        , count(t21.crd_rpl_n)
                        , sum(t21.cl_hga)                     as cl_hga                     -- 신판취급금액
                        , sum(t21.cre_cl_hga)                 as cre_cl_hga                 -- 신용신판취급금액
                        , sum(t21.chc_hga)                    as chc_hga                    -- 체크카드취급금액
                        , sum(t21.p_hga)                      as p_hga                      -- 일시불취급금액
                        , sum(t21.ns_hga)                     as ns_hga                     -- 할부취급금액
                        , sum(t21.vv_cl_hga)                  as vv_cl_hga                  -- 리볼빙신판취급금액
                        , sum(t21.vv_cv_hga)                  as vv_cv_hga                  -- 리볼빙현금서비스취급금액
                        , sum(t21.cv_hga)                     as cv_hga                     -- 현금서비스취급금액
                        , sum(t21.cl_ue_ct)                   as cl_ue_ct                   -- 신판이용건수
                        , sum(t21.cre_cl_ue_ct)               as cre_cl_ue_ct               -- 신용신판이용건수
                        , sum(t21.chc_ue_ct)                  as chc_ue_ct                  -- 체크카드이용건수
                        , sum(t21.p_ue_ct)                    as p_ue_ct                    -- 일시불이용건수
                        , sum(t21.ns_ue_ct)                   as ns_ue_ct                   -- 할부이용건수
                        , sum(t21.vv_cl_ue_ct)                as vv_cl_ue_ct                -- 리볼빙신판이용건수
                        , sum(t21.vv_cv_ue_ct)                as vv_cv_ue_ct                -- 리볼빙현금서비스이용건수
                        , sum(t21.cv_ue_ct)                   as cv_ue_ct                   -- 현금서비스이용건수
                     from (select crd_rpl_n                                                 -- 카드대체번호
                             from shc.mtdia0001
                            where ta_ym = '{date_cd('P_TA_YM')}'
                              and rlp_crd_tf = '1'                                          -- 실질카드tf
                           )            t20                                                 -- 월카드디멘젼
                     left outer join
                          (select t30.ta_ym
                                , t30.sgdmd
                                , t30.crd_rpl_n
                                , t30.cl_hga
                                , t30.cre_cl_hga
                                , t30.chc_hga
                                , t30.p_hga
                                , t30.ns_hga
                                , t30.vv_cl_hga
                                , t30.vv_cv_hga
                                , t30.cv_hga
                                , t30.cl_ue_ct
                                , t30.cre_cl_ue_ct
                                , t30.chc_ue_ct
                                , t30.p_ue_ct
                                , t30.ns_ue_ct
                                , t30.vv_cl_ue_ct
                                , t30.vv_cv_ue_ct
                                , t30.cv_ue_ct
                             from shc.mtfua0002  t30                                        -- 월카드매출
                            inner join
                                  sh1.shddcom002 t31                                        -- COM_수기관리기본
                               on t30.crd_pd_n = t31.lcd_cri_vl1
                              and t31.ta_itm_key_vl = 'CRD_PD_N_001'
                            where t30.ta_ym = '{date_cd('P_TA_YM')}'
                           ) t21
                       on t20.crd_rpl_n = t21.crd_rpl_n
                    group by t21.ta_ym
                           , t21.sgdmd
                   )               t11
                on t10.rpk_sgdmd = t11.sgdmd
             where t10.ta_ym = '{date_cd('P_TA_YM')}'
               and t10.rlp_mct_tf = '1'                                                     -- 실질가맹점tf
            union all
            select ta_ym                                                                    -- 기준년월
                 , shmdn                                                                    -- 그룹MD번호
                 , max(psn_etk_ln_al)                         as psn_etk_ln_al              -- 개인사업자대출잔액
                 , 0                                          as etk_crd_cl_uea             -- 사업자카드신판이용금액
                 , 0                                          as etk_crd_cre_cl_uea         -- 사업자카드신용신판이용금액
                 , 0                                          as etk_crd_chc_uea            -- 사업자카드체크카드이용금액
                 , 0                                          as etk_crd_p_uea              -- 사업자카드일시불이용금액
                 , 0                                          as etk_crd_ns_uea             -- 사업자카드할부이용금액
                 , 0                                          as etk_crd_vv_cl_uea          -- 사업자카드리볼빙신판이용금액
                 , 0                                          as etk_crd_vv_cv_uea          -- 사업자카드리볼빙현금서비스이용금액
                 , 0                                          as etk_crd_cv_uea             -- 사업자카드현금서비스이용금액
                 , 0                                          as etk_crd_cl_ue_ct           -- 사업자카드신판이용건수
                 , 0                                          as etk_crd_cre_cl_ue_ct       -- 사업자카드신용신판이용건수
                 , 0                                          as etk_crd_chc_ue_ct          -- 사업자카드체크카드이용건수
                 , 0                                          as etk_crd_p_ue_ct            -- 사업자카드일시불이용건수
                 , 0                                          as etk_crd_ns_ue_ct           -- 사업자카드할부이용건수
                 , 0                                          as etk_crd_vv_cl_ue_ct        -- 사업자카드리볼빙신판이용건수
                 , 0                                          as etk_crd_vv_cv_ue_ct        -- 사업자카드리볼빙현금서비스이용건수
                 , 0                                          as etk_crd_cv_ue_ct           -- 사업자카드현금서비스이용건수
                 , sum(saa)                                   as saa                        -- 매출금액
                 , sum(shc_saa)                               as shc_saa                    -- 신한카드매출금액
                 , sum(acco_saa)                              as acco_saa                   -- 타카드사매출금액
                 , sum(liq_rca)                               as liq_rca                    -- 유동성입금금액
                 , sum(liq_aow_at)                            as liq_aow_at                 -- 유동성출금금액
              from (
                select ta_ym
                     , shmdn
                     , sum(psn_etk_ln_al) as psn_etk_ln_al -- 개인사업자대출잔액
                     , sum(acco_saa)      as saa           -- 매출금액(은행+카드)
                     , 0                  as shc_saa       -- 신한카드매출금액
                     , sum(acco_saa)      as acco_saa      -- 타카드사매출금액
                     , sum(liq_rca)       as liq_rca       -- 유동성_입금금액
                     , sum(liq_aow_at)    as liq_aow_at    -- 유동성_출금금액
                  from sh1.shbmtrs002
                 where ta_ym = '{date_cd('P_TA_YM')}'
                 group by ta_ym
                        , shmdn
                 union all
                select ta_ym
                     , shmdn
                     , 0                  as psn_etk_ln_al -- 개인사업자대출잔액
                     , sum(shc_hga)       as shc_hga       -- 매출금액(은행+카드)
                     , sum(shc_hga)       as shc_hga       -- 신한카드매출금액
                     , 0                  as acco_saa      -- 타카드사매출금액
                     , 0                  as liq_rca       -- 유동성_입금금액
                     , 0                  as liq_aow_at    -- 유동성_출금금액
                  from sh1.shcmtrs002
                 where ta_ym = '{date_cd('P_TA_YM')}'
                 group by ta_ym
                        , shmdn
                )
             group by ta_ym
                    , shmdn
    
           ) t10
     group by t10.ta_ym
            , t10.shmdn
"""

"""
(@) tmp_sh2 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_for_tmp_1, insert_sql_for_tmp_2 ...)
"""
insert_sql_for_tmp_2 = f"""
    insert into tmp_sh2.shdmigd005_tmp99
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , psn_etk_ln_al                          -- 개인사업자대출잔액
         , etk_crd_cl_uea                         -- 사업자카드신판이용금액
         , etk_crd_cre_cl_uea                     -- 사업자카드신용신판이용금액
         , etk_crd_chc_uea                        -- 사업자카드체크카드이용금액
         , etk_crd_p_uea                          -- 사업자카드일시불이용금액
         , etk_crd_ns_uea                         -- 사업자카드할부이용금액
         , etk_crd_vv_cl_uea                      -- 사업자카드리볼빙신판이용금액
         , etk_crd_vv_cv_uea                      -- 사업자카드리볼빙현금서비스이용금액
         , etk_crd_cv_uea                         -- 사업자카드현금서비스이용금액
         , etk_crd_cl_ue_ct                       -- 사업자카드신판이용건수
         , etk_crd_cre_cl_ue_ct                   -- 사업자카드신용신판이용건수
         , etk_crd_chc_ue_ct                      -- 사업자카드체크카드이용건수
         , etk_crd_p_ue_ct                        -- 사업자카드일시불이용건수
         , etk_crd_ns_ue_ct                       -- 사업자카드할부이용건수
         , etk_crd_vv_cl_ue_ct                    -- 사업자카드리볼빙신판이용건수
         , etk_crd_vv_cv_ue_ct                    -- 사업자카드리볼빙현금서비스이용건수
         , etk_crd_cv_ue_ct                       -- 사업자카드현금서비스이용건수
         , saa                                    -- 매출금액
         , shc_saa                                -- 신한카드매출금액
         , acco_saa                               -- 타카드사매출금액
         , liq_rca                                -- 유동성입금금액
         , liq_aow_at                             -- 유동성출금금액
         , to_ase_at                              -- 총자산금액
         , to_lbt_at                              -- 총부채금액
         , to_epn_at                              -- 총지출금액
         , to_ina                                 -- 총소득금액
         , pss_crd_cn                             -- 보유카드수
         , cre_crd_uea                            -- 신용카드이용금액
         , chc_uea                                -- 체크카드이용금액
         , ivs_ase_at                             -- 투자자산금액
         , pss_iu_cn                              -- 보유보험수
         , gpm_irg_at                             -- 납입보험료금액
         )
    select t10.ta_ym                                                  -- 기준년월
         , t10.shmdn                                                  -- 그룹MD번호
         , current_timestamp AT TIME ZONE 'Asia/Seoul' as aws_ld_dt   -- AWS적재일시
         , t10.psn_etk_ln_al                                          -- 개인사업자대출잔액
         , t10.etk_crd_cl_uea                                         -- 사업자카드신판이용금액
         , t10.etk_crd_cre_cl_uea                                     -- 사업자카드신용신판이용금액
         , t10.etk_crd_chc_uea                                        -- 사업자카드체크카드이용금액
         , t10.etk_crd_p_uea                                          -- 사업자카드일시불이용금액
         , t10.etk_crd_ns_uea                                         -- 사업자카드할부이용금액
         , t10.etk_crd_vv_cl_uea                                      -- 사업자카드리볼빙신판이용금액
         , t10.etk_crd_vv_cv_uea                                      -- 사업자카드리볼빙현금서비스이용금액
         , t10.etk_crd_cv_uea                                         -- 사업자카드현금서비스이용금액
         , t10.etk_crd_cl_ue_ct                                       -- 사업자카드신판이용건수
         , t10.etk_crd_cre_cl_ue_ct                                   -- 사업자카드신용신판이용건수
         , t10.etk_crd_chc_ue_ct                                      -- 사업자카드체크카드이용건수
         , t10.etk_crd_p_ue_ct                                        -- 사업자카드일시불이용건수
         , t10.etk_crd_ns_ue_ct                                       -- 사업자카드할부이용건수
         , t10.etk_crd_vv_cl_ue_ct                                    -- 사업자카드리볼빙신판이용건수
         , t10.etk_crd_vv_cv_ue_ct                                    -- 사업자카드리볼빙현금서비스이용건수
         , t10.etk_crd_cv_ue_ct                                       -- 사업자카드현금서비스이용건수
         , t10.saa                                                    -- 매출금액
         , t10.shc_saa                                                -- 신한카드매출금액
         , t10.acco_saa                                               -- 타카드사매출금액
         , t10.liq_rca                                                -- 유동성입금금액
         , t10.liq_aow_at                                             -- 유동성출금금액
         , t11.to_ase_at                                              -- 총자산금액
         , t11.to_lbt_at                                              -- 총부채금액
         , t11.to_epn_at                                              -- 총지출금액
         , t11.to_ina                                                 -- 총소득금액
         , t12.pss_crd_cn                                             -- 보유카드수
         , t11.cre_cl_uea            as cre_crd_uea                   -- 신용카드이용금액
         , t11.chc_uea                                                -- 체크카드이용금액
         , t11.ivs_ase_at                                             -- 투자자산금액
         , t12.pss_iu_cn                                              -- 보유보험수
         , t11.gpm_irg_at                                             -- 납입보험료금액
      from tmp_sh2.shdmigd005_tmp01 t10
      left outer join
           sh2.shdmigd006           t11
        on t10.ta_ym  = t11.ta_ym
       and t10.shmdn  = t11.shmdn
      left outer join
           sh2.shdmigd003           t12
        on t10.ta_ym  = t12.ta_ym
       and t10.shmdn  = t12.shmdn
     where t10.ta_ym  = '{date_cd('P_TA_YM')}'
"""


"""(@) tmp_sh2 INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""    
insert_sql_for_tmp = [insert_sql_for_tmp_1]

""" 
(@) TMP_SH1 테이블 PK 정보 (duplicate validation 대상)
"""
table_pk_info = {
    0: {'table': 'shdmigd005_tmp99', 'pk': ['ta_ym', 'shmdn']}
}

"""
(@) SH1 테이블 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from sh2.shdmigd005
    where ta_ym = '{date_cd('P_TA_YM')}'
"""

"""
(@) SH1 INSERT 쿼리 (필요한 개수만큼 변수 생성 insert_sql_1, insert_sql_2 ...)
"""
insert_sql_1 = f"""
    insert into sh2.shdmigd005
         (
           ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , psn_etk_ln_al                          -- 개인사업자대출잔액
         , etk_crd_cl_uea                         -- 사업자카드신판이용금액
         , etk_crd_cre_cl_uea                     -- 사업자카드신용신판이용금액
         , etk_crd_chc_uea                        -- 사업자카드체크카드이용금액
         , etk_crd_p_uea                          -- 사업자카드일시불이용금액
         , etk_crd_ns_uea                         -- 사업자카드할부이용금액
         , etk_crd_vv_cl_uea                      -- 사업자카드리볼빙신판이용금액
         , etk_crd_vv_cv_uea                      -- 사업자카드리볼빙현금서비스이용금액
         , etk_crd_cv_uea                         -- 사업자카드현금서비스이용금액
         , etk_crd_cl_ue_ct                       -- 사업자카드신판이용건수
         , etk_crd_cre_cl_ue_ct                   -- 사업자카드신용신판이용건수
         , etk_crd_chc_ue_ct                      -- 사업자카드체크카드이용건수
         , etk_crd_p_ue_ct                        -- 사업자카드일시불이용건수
         , etk_crd_ns_ue_ct                       -- 사업자카드할부이용건수
         , etk_crd_vv_cl_ue_ct                    -- 사업자카드리볼빙신판이용건수
         , etk_crd_vv_cv_ue_ct                    -- 사업자카드리볼빙현금서비스이용건수
         , etk_crd_cv_ue_ct                       -- 사업자카드현금서비스이용건수
         , saa                                    -- 매출금액
         , shc_saa                                -- 신한카드매출금액
         , acco_saa                               -- 타카드사매출금액
         , liq_rca                                -- 유동성입금금액
         , liq_aow_at                             -- 유동성출금금액
         , to_ase_at                              -- 총자산금액
         , to_lbt_at                              -- 총부채금액
         , to_epn_at                              -- 총지출금액
         , to_ina                                 -- 총소득금액
         , pss_crd_cn                             -- 보유카드수
         , cre_crd_uea                            -- 신용카드이용금액
         , chc_uea                                -- 체크카드이용금액
         , ivs_ase_at                             -- 투자자산금액
         , pss_iu_cn                              -- 보유보험수
         , gpm_irg_at                             -- 납입보험료금액
         )
    select ta_ym                                  -- 기준년월
         , shmdn                                  -- 그룹MD번호
         , aws_ld_dt                              -- AWS적재일시
         , psn_etk_ln_al                          -- 개인사업자대출잔액
         , etk_crd_cl_uea                         -- 사업자카드신판이용금액
         , etk_crd_cre_cl_uea                     -- 사업자카드신용신판이용금액
         , etk_crd_chc_uea                        -- 사업자카드체크카드이용금액
         , etk_crd_p_uea                          -- 사업자카드일시불이용금액
         , etk_crd_ns_uea                         -- 사업자카드할부이용금액
         , etk_crd_vv_cl_uea                      -- 사업자카드리볼빙신판이용금액
         , etk_crd_vv_cv_uea                      -- 사업자카드리볼빙현금서비스이용금액
         , etk_crd_cv_uea                         -- 사업자카드현금서비스이용금액
         , etk_crd_cl_ue_ct                       -- 사업자카드신판이용건수
         , etk_crd_cre_cl_ue_ct                   -- 사업자카드신용신판이용건수
         , etk_crd_chc_ue_ct                      -- 사업자카드체크카드이용건수
         , etk_crd_p_ue_ct                        -- 사업자카드일시불이용건수
         , etk_crd_ns_ue_ct                       -- 사업자카드할부이용건수
         , etk_crd_vv_cl_ue_ct                    -- 사업자카드리볼빙신판이용건수
         , etk_crd_vv_cv_ue_ct                    -- 사업자카드리볼빙현금서비스이용건수
         , etk_crd_cv_ue_ct                       -- 사업자카드현금서비스이용건수
         , saa                                    -- 매출금액
         , shc_saa                                -- 신한카드매출금액
         , acco_saa                               -- 타카드사매출금액
         , liq_rca                                -- 유동성입금금액
         , liq_aow_at                             -- 유동성출금금액
         , to_ase_at                              -- 총자산금액
         , to_lbt_at                              -- 총부채금액
         , to_epn_at                              -- 총지출금액
         , to_ina                                 -- 총소득금액
         , pss_crd_cn                             -- 보유카드수
         , cre_crd_uea                            -- 신용카드이용금액
         , chc_uea                                -- 체크카드이용금액
         , ivs_ase_at                             -- 투자자산금액
         , pss_iu_cn                              -- 보유보험수
         , gpm_irg_at                             -- 납입보험료금액
      from tmp_sh2.shdmigd005_tmp99

"""

"""
(@) INSERT 쿼리명 리스트
    : 위에 작성한 쿼리명 나열
"""
insert_sql_for_sh1 = [insert_sql_1]
### End of Batch Configuration
################################################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'target_schema': target_schema,
    'tmp_schema': tmp_schema,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    tmp_truncate_task = TmpTruncateOperator(
        task_id='001_tmp_truncate_task',
        target_table=tmp_sh2_table,
    )

    tmp_load_task = [RedshiftQueryOperator(
        task_id='002_tmp_load_task_' + str(insert_sql_for_tmp.index(select_sql_for_insert)+1),
        execute_query=select_sql_for_insert,
    ) for select_sql_for_insert in insert_sql_for_tmp]

    tmp_load_task_2 = RedshiftQueryOperator(
        task_id='003_tmp_load_task_2',
        execute_query=insert_sql_for_tmp_2,
    )
    
    tmp_load_task_end = DummyOperator(task_id='tmp_load_task_end')

    tmp_pk_valid_task = RedshiftPkValidOperator(
        task_id='004_tmp_pk_valid_task',
        table_pk_info=table_pk_info,
    )

    sh1_delete_task = RedshiftQueryOperator(
        task_id='005_sh2_delete_task',
        execute_query=delete_sql_for_append,
    )

    sh1_load_task = [RedshiftQueryOperator(
        task_id='006_sh2_load_task_' + str(insert_sql_for_sh1.index(inert_query)+1),
        execute_query=inert_query,
    ) for inert_query in insert_sql_for_sh1]

    task_end = DummyOperator(task_id='task_end')

    tmp_truncate_task >> tmp_load_task >> tmp_load_task_2 >> tmp_load_task_end >> tmp_pk_valid_task >> sh1_delete_task >> sh1_load_task >> task_end
