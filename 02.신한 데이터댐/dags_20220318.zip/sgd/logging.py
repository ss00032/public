# -*- coding: utf-8 -*-
import logging
import pendulum
import json

from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.python import get_current_context
from sgd.utils import *

log = logging.getLogger(__name__)


def _get_sgd_etl_history_conn():
    hook = PostgresHook(
        postgres_conn_id='sgd_dl_etl_history'
    )
    return hook.get_conn()


def _get_task_step(task_id):
    step = None
    fields = task_id.split('_')
    try:
        step = int(fields[0])
    except ValueError as e:
        log.warning(f'Get task step from task_id fail: {task_id}')
    return step


def handle_dag_success(context):
    """
    DAG on_success_callback 함수
    전체 DAG 작업 성공 시점에 호출됨
    DLADM001 테이블의 수행결과코드 값을 성공('S')로 업데이트
    """
    dag_id = ''
    try:
        dag_run = context.get('dag_run')
        ti = context.get("task_instance")
        execution_dt = context.get('execution_date')

        dag_id = dag_run.dag_id
        dr_start_dt = dag_run.start_date
        dr_end_dt = dag_run.end_date
        odate = get_odate(dag_id, execution_dt)
        dr_duration = (dr_end_dt - dr_start_dt).total_seconds()
        step = _get_task_step(ti.task_id)

        log.info(f'ETL LOG [DAG-S]: {dag_id}, {odate}')
        conn = _get_sgd_etl_history_conn()
        with conn.cursor() as cursor:
            master_sql = """
                    insert into sgdhistory.DLADM001 (
                        odate, prog_id, start_dt, step, duration, end_dt, rst_cd, err_msg
                    ) values (
                        %s, %s, %s, %s, %s, %s, 'S', NULL
                    ) on conflict (odate, prog_id)
                    do update set  
                        start_dt = %s
                        , end_dt = %s  
                        , duration = %s
                        , rst_cd = 'S'    
                        , err_msg = NULL 
                    returning id
                    """
            master_params = (odate, dag_id, dr_start_dt, step, dr_duration, dr_end_dt,
                             dr_start_dt, dr_end_dt, dr_duration)
            cursor.execute(master_sql, master_params)
            master_id = cursor.fetchone()[0]

            conn.commit()
            log.info(f'ETL LOG [DAG-S] DONE: [id:{master_id}] => master={master_params}')
        conn.close()
    except Exception as e:
        log.error(f'ETL LOG [DAG-S] FAIL: [{dag_id}]: {e.message}')
        raise


def handle_task_fail(context):
    """
    DAG on_failure_callback 함수
    전체 DAG 작업 실패 시점에 호출됨
    DLADM001 테이블의 수행결과코드 값을 실패('F'), 에러메시지내용을 업데이트
    DLADM002 테이블의 수행결과코드 값을 실패('F'), 에러메시지내용을 업데이트
    """
    dag_id = ''
    try:
        dag_run = context.get('dag_run')
        ti = context.get("task_instance")
        execution_dt = context.get('execution_date')

        dag_id = ti.dag_id
        task_id = ti.task_id
        run_id = dag_run.run_id
        try_num = ti.try_number - 1

        dr_start_dt = dag_run.start_date
        dr_end_dt = dag_run.end_date
        if not dr_end_dt:
            dr_end_dt = pendulum.now()
        ti_start_dt = ti.start_date
        ti_end_dt = ti.end_date
        if not ti_end_dt:
            ti_end_dt = pendulum.now()
        odate = get_odate(dag_id, execution_dt)
        dr_duration = (dr_end_dt - dr_start_dt).total_seconds()
        ti_duration = (ti_end_dt - ti_start_dt).total_seconds()
        step = _get_task_step(ti.task_id)
        err_msg = str(context.get("exception")).replace("'", "\"")

        log.info(f'ETL LOG [TASK-F]: {dag_id}, {odate}')
        conn = _get_sgd_etl_history_conn()
        with conn.cursor() as cursor:
            master_sql = """
                insert into sgdhistory.DLADM001 (
                    odate, prog_id, start_dt, step, duration, end_dt, rst_cd, err_msg
                ) values (
                    %s, %s, %s, %s, %s, %s, 'F', %s
                ) on conflict (odate, prog_id)
                do update set  
                    start_dt = %s
                    , end_dt = %s
                    , duration = %s
                    , step = %s
                    , rst_cd = 'F'               
                    , err_msg = %s     
                returning id
                """
            master_params = (odate, dag_id, dr_start_dt, step, dr_duration, dr_end_dt, err_msg,
                             dr_start_dt, dr_end_dt, dr_duration, step, err_msg)
            cursor.execute(master_sql, master_params)
            master_id = cursor.fetchone()[0]

            detail_sql = """
                insert into sgdhistory.DLADM002 (
                    mst_id, odate, prog_id, etl_start_dt, task_id, step, try_num, 
                    run_id, start_dt, end_dt, duration, rst_cd, err_msg
                ) values (
                    %s, %s, %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, 'F', %s
                ) on conflict (mst_id, task_id, try_num, run_id)
                do update set
                    end_dt =  %s  
                    , duration = %s
                    , rst_cd = 'F'
                    , err_msg = %s
                """
            detail_params = (master_id, odate, dag_id, dr_start_dt, task_id, step, try_num,
                             run_id, ti_start_dt, ti_end_dt, ti_duration, err_msg,
                             ti_end_dt, ti_duration, err_msg)
            cursor.execute(detail_sql, detail_params)
            conn.commit()
            log.info(f'ETL LOG [TASK-F] DONE: [id:{master_id}] => master={master_params}, detail={detail_params}')
        conn.close()
    except Exception as e:
        log.error(f'ETL LOG [TASK-F] FAIL: [{dag_id}]: {e.message}')
        raise


def handle_task_success(data_count=None, data_size=None, load_info=None):
    """
    custom operator task 성공시 호출하는 로깅 메소드
    DLADM001 테이블의 수행결과코드 값을 진행중('R'), 데이터 건수(존재시) 로깅
    DLADM002 테이블의 수행결과코드 값을 성공('S'), 데이터 건수 또는 데이터 용량 로깅
    """
    dag_id = ''
    try:
        context = get_current_context()
        dag_run = context.get('dag_run')
        ti = context.get('task_instance')
        execution_dt = context.get('execution_date')

        dag_id = ti.dag_id
        task_id = ti.task_id
        run_id = dag_run.run_id
        try_num = ti.try_number

        dr_start_dt = dag_run.start_date
        dr_end_dt = dag_run.end_date
        if not dr_end_dt:
            dr_end_dt = pendulum.now()
        ti_start_dt = ti.start_date
        ti_end_dt = ti.end_date
        if not ti_end_dt:
            ti_end_dt = pendulum.now()
        odate = get_odate(dag_id, execution_dt)
        dr_duration = (dr_end_dt - dr_start_dt).total_seconds()
        ti_duration = (ti_end_dt - ti_start_dt).total_seconds()
        step = _get_task_step(ti.task_id)

        master_update_sql = ''
        if data_count is not None:
            master_update_sql = ', cnt = %s'

        log.info(f'ETL LOG [TASK-S]: {dag_id}, {odate}')
        conn = _get_sgd_etl_history_conn()
        with conn.cursor() as cursor:
            master_sql = f"""
                insert into sgdhistory.DLADM001 (
                    odate, prog_id, start_dt, step, cnt, rst_cd, err_msg
                ) values (
                    %s, %s, %s, %s, %s, 'R', NULL
                ) on conflict (odate, prog_id)
                do update set
                    start_dt = %s  
                    , step = %s
                    , rst_cd = 'R'
                    , err_msg = NULL
                    {master_update_sql}                    
                returning id 
                """
            if data_count is not None:
                master_params = (odate, dag_id, dr_start_dt, step, data_count, dr_start_dt, step, data_count)
            else:
                master_params = (odate, dag_id, dr_start_dt, step, data_count, dr_start_dt, step)
            cursor.execute(master_sql, master_params)
            master_id = cursor.fetchone()[0]
            load_info_json = None
            if load_info:
                load_info_json = json.dumps(load_info)
            detail_sql = """
                insert into sgdhistory.DLADM002 (
                    mst_id, odate, prog_id, etl_start_dt, task_id, step, try_num, 
                    run_id, start_dt, end_dt, duration, cnt, size, rst_cd, err_msg, reserve_01
                ) values (
                    %s, %s, %s, %s, %s, %s, %s,
                    %s, %s, %s, %s, %s, %s, 'S', NULL, %s
                ) on conflict (mst_id, task_id, try_num, run_id)
                do update set
                    end_dt =  %s
                    , duration = %s                    
                    , cnt = %s
                    , size = %s
                    , rst_cd = 'S'
                    , err_msg = NULL
                    , reserve_01 = %s
            """
            detail_params = (master_id, odate, dag_id, dr_start_dt, task_id, step, try_num,
                             run_id, ti_start_dt, ti_end_dt, ti_duration, data_count, data_size, load_info_json,
                             ti_end_dt, ti_duration, data_count, data_size, load_info_json)
            cursor.execute(detail_sql, detail_params)
            conn.commit()
            log.info(f'ETL LOG [TASK-S] DONE: [id:{master_id}] => master={master_params}, detail={detail_params}')
        conn.close()
    except Exception as e:
        log.error(f'ETL LOG [TASK-S] FAIL: [{dag_id}]: {e.message}')
        raise
    return master_id


def handle_task_running():
    """
    custom sensor에서 진행중인 sensor task 로깅 메소드
    DLADM001 테이블의 수행결과코드 값을 진행중('R') 로깅
    DLADM002 테이블의 수행결과코드 값을 진행중('R') 로깅
    """
    dag_id = ''
    try:
        context = get_current_context()
        dag_run = context.get('dag_run')
        ti = context.get('task_instance')
        execution_dt = context.get('execution_date')

        dag_id = ti.dag_id
        task_id = ti.task_id
        run_id = dag_run.run_id
        try_num = ti.try_number

        dr_start_dt = dag_run.start_date
        ti_start_dt = ti.start_date
        odate = get_odate(dag_id, execution_dt)
        step = _get_task_step(ti.task_id)

        log.info(f'ETL LOG [TASK-R]: {dag_id}, {odate}')
        conn = _get_sgd_etl_history_conn()
        with conn.cursor() as cursor:
            master_sql = f"""
                insert into sgdhistory.DLADM001 (
                    odate, prog_id, start_dt, step, duration, end_dt, cnt, rst_cd, err_msg
                ) values (
                    %s, %s, %s, %s, NULL, NULL, NULL, 'R', NULL
                ) on conflict (odate, prog_id)
                do update set  
                    start_dt = %s
                    , end_dt = NULL
                    , duration = NULL
                    , cnt = NULL
                    , step = %s
                    , rst_cd = 'R'
                    , err_msg = NULL
                returning id 
                """
            master_params = (odate, dag_id, dr_start_dt, step, dr_start_dt, step)
            cursor.execute(master_sql, master_params)
            master_id = cursor.fetchone()[0]

            detail_sql = """
                insert into sgdhistory.DLADM002 (
                    mst_id, odate, prog_id, etl_start_dt, task_id, step, try_num, 
                    run_id, start_dt, rst_cd
                ) values (
                    %s, %s, %s, %s, %s, %s, %s,
                    %s, %s, 'R'
                ) on conflict (mst_id, task_id, try_num, run_id)
                do update set  
                    rst_cd = 'R' 
            """
            detail_params = (master_id, odate, dag_id, dr_start_dt, task_id, step, try_num,
                             run_id, ti_start_dt)
            cursor.execute(detail_sql, detail_params)
            conn.commit()
            log.info(f'ETL LOG [TASK-R] DONE: [id:{master_id}] => master={master_params}, detail={detail_params}')
        conn.close()
    except Exception as e:
        log.error(f'ETL LOG [TASK-R] FAIL: [{dag_id}]: {e.message}')
        raise
    return master_id
