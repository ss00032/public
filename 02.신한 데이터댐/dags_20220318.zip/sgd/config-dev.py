# -*- coding: utf-8 -*-

from datetime import datetime
from datetime import timedelta
import pendulum

SGD_TZ = pendulum.timezone('Asia/Seoul')
DEV_FLAG = 'dev'                             # prd/dev 구분
DEV_FLAG_UP = DEV_FLAG.upper()               # 대문자 치환

sgd_env = {
    'dag_owner': 'airflow',
    'wk_layer': 'w0',                                            # Working Layer
    'suffix_view': '_vw',                                        # View Suffix
    'retries': 0,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2022, 1, 1, tzinfo=SGD_TZ),           # DAG 시작일
}

conn_id = {
    'dl_s3': 'sgd_dl_s3_conn_id',                                # S3
    'dl_redshift': {
        'igd': 'sgd_dl_igd_redshift_conn_id',                    # Redshift IGD cluster
        'acd': 'sgd_dl_acd_redshift_conn_id',                    # Redshift ACD cluster
    },
    'dl_ezgator': 'sgd_dl_ezgator_conn_id',                      # ez-gator master
    'dl_konan': 'sgd_dl_konan_conn_id',                          # 외부수집용서버
}

s3_env = {
    'stg_bucket_prefix': f'shcw-an2-datadam-{DEV_FLAG}-s3-dl-stg',
    'bck_bucket_prefix': f'shcw-an2-datadam-{DEV_FLAG}-s3-dl-bck',
}

redshift_env = {
    'copy_options': {
        'shb': ["csv EMPTYASNULL quote as '\036' delimiter '\037'"],
        'shc': ["csv EMPTYASNULL quote as '\036' delimiter '|'"],
        'shi': ["csv EMPTYASNULL IGNOREHEADER 1 delimiter '~'"],
        'shl': ["csv EMPTYASNULL quote as '\036' delimiter '|'"],
        'pbc': ["csv EMPTYASNULL delimiter ','"],
    },
    'unload_options': {
        'shb': ("csv","DELIMITER AS '\037'"),
        'shc': ("csv","DELIMITER AS '|'"),
        'shi': ("csv","DELIMITER AS '~'"),
        'shl': ("csv","DELIMITER AS '|'"),
        'pbc': ("csv", "DELIMITER AS ','"),
    },
    'include_header': {
        'shb': '',
        'shc': '',
        'shi': 'HEADER',
        'shl': '',
        'pbc': '',
    },
    'unload_parallel': {
        'on': 'PARALLEL ON',
        'off': 'PARALLEL OFF',
    },
    'iam_role': {
        'igd': f'arn:aws:iam::796123547122:role/SHCW-DataDam-{DEV_FLAG_UP}-ROL-REDSHIFT-IGD-1',
        'acd': f'arn:aws:iam::796123547122:role/SHCW-DataDam-{DEV_FLAG_UP}-ROL-REDSHIFT-ACD-1',
    }
}

ezgator_env = {
    # 데이터댐 수신
    'recv': {
        'shell_path': '/shcsw/ezgator/client/ezgatorsend.sh',
        'if_nm_fmt': 'BIR{cp_cd}_{ez_seq}',
        # 데이터댐 데이터 경로 (+company_code)
        'sgd_path': '/shcsw/ezgator/ftphome/rcv',
        # 수신 후행 스크립트
        'post_shell': {
            'shb': '/shcsrc/python/sgd-dl-ezgator/script/sgd_upload_to_s3_stg.py',
            'shc': '/shcsrc/python/sgd-dl-ezgator/script/sgd_upload_to_s3_stg.py',
            'shl': '/shcsrc/python/sgd-dl-ezgator/script/sgd_upload_to_s3_stg.py',
        },
        'post_shell_timeout': 1200,
    },
    # 데이터댐 송신
    'send': {
        'shell_path': '/shcsw/ezgator/client/ezgatorsend.sh',
        'if_nm_fmt': 'BIS{cp_cd}_{ez_seq}',
        # 데이터댐 데이터 경로 (+company_code)
        'sgd_path': '/shcsw/ezgator/ftphome/snd',
        # 송신 후행 스크립트
        'post_shell': {
            'shb': '',
            'shc': '',
            'shl': '',
        },
        'post_shell_timeout': 1200,
    },
    'list': {
        'shell_path': '/shcsw/ezgator/client/ezgatorlist.sh',
        # 그룹사 서버경로.
        'com_path': {
            'shb_igd': '',
            'shb_acd': '',
            'shc_igd': '/etl_dat/data/eai/snd/data/sgd',
            'shc_acd': '/etl_dat/data/eai/snd/data/sgd',
            'shl_igd': '/shcsw/ezgator/ftphome/snd',
            'shl_acd': '/shcsw/ezgator/ftphome/snd',
        },
        'system_nm': {
            'shb': 'SHINHAN_BANK',
            'shc': 'SHINHAN_CARD',
            'shl': 'TEMP_SHINHAN_DATADAM',
        },
    },
}
