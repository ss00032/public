# -*- coding: utf-8 -*-

from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.decorators import apply_defaults
from airflow.models import BaseOperator
from airflow.exceptions import AirflowException
from sgd import config
from sgd import utils
from sgd import logging


class RedshiftPkValidOperator(BaseOperator):
    """
    Redshift 테이블 데이터 duplicate 검사 (컬럼명 리스트로 받음)
    """
    template_fields = ()
    template_ext = ()
    ui_color = '#99e699'

    @apply_defaults
    def __init__(self,
                 tmp_schema,
                 company_code,
                 use_purpose,
                 table_pk_info,
                 autocommit=False,
                 *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.tmp_schema = tmp_schema
        self.company_code = company_code
        self.use_purpose = use_purpose
        self.table_pk_info = table_pk_info  # dict
        self.autocommit = autocommit
        self.affected_rows = 0

    def execute(self, context):

        self._check_validation()
        if not self.table_pk_info:
            raise AirflowException('table_pk_info is invalid.')
        self.log.info(f"""

            ### pk duplicate validation ###
            table_pk_info: {self.table_pk_info}
    
            """)

        redshift_conn_id = config.conn_id['dl_redshift'][self.use_purpose]
        redshift_hook = PostgresHook(postgres_conn_id=redshift_conn_id)

        with redshift_hook.get_conn() as conn:

            dup_rows_count = 0
            for n, dict in self.table_pk_info.items():
                table_name = dict['table']
                column_list = dict['pk']
                self.log.info(f"""
                    schema: {self.tmp_schema}
                    table: {table_name}
                    column_list: {column_list}""")
                pk_columns = ','.join([str(item) for item in column_list])

                dup_check_query = """
                    select {select_pk_columns}, count(*) as dup_cnt
                    from {schema_name}.{table_name}
                    group by {group_by_pk_columns}
                    having dup_cnt > 1 ;
                """.format(select_pk_columns=pk_columns,
                           schema_name=self.tmp_schema,
                           table_name=table_name,
                           group_by_pk_columns=pk_columns)

                self.log.info(f"""
                
                    ### dup_check_query ###
                    {dup_check_query}
                    """)

                with conn.cursor() as cursor:
                    cursor.execute(dup_check_query)
                    self.affected_rows = cursor.rowcount
                    self.log.info(f"dup_rows_count:{self.affected_rows}")

                    dup_rows_count = dup_rows_count + self.affected_rows

            if dup_rows_count > 0:
                self.log.info(f"dup_rows_count:{self.affected_rows}")
                raise AirflowException('PK DUPLICATED IN TMP TABLE.')

            if not self.autocommit:
                conn.commit()

        # logging etl job
        logging.handle_task_success(self.affected_rows)

    def _check_validation(self):
        if not (utils.valid_company_code(self.company_code)
                and utils.valid_use_purpose(self.use_purpose)):
            raise AirflowException('Either company_code or use_purpose is invalid.')
