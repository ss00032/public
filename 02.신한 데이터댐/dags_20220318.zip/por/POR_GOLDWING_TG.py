# -*- coding: utf-8 -*-

from airflow import DAG
from sgd import config
from airflow.providers.ssh.operators.ssh import SSHOperator

__author__ = "오석근"
__copyright__ = "Copyright 2021, Shinhan Datadam"
__credits__ = ["오석근"]
__version__ = "1.0"
__maintainer__ = "오석근"
__email__ = ""
__status__ = "Production"

"""
포털 골드윙 인사 정보 수집 DAG
Ez-GATOR를 이용하여 두 개 파일 수집 

- 원천 정보 
경로: /sgd_dat/data/eai/rcv
파일명: icd_t_user.txt, icd_t_dept.txt

- Ez-GATOR 정보 
배치인터페이스: BIRC_0002

- 타겟 정보 (Ez-GATOR 수신 후행 쉘 스크립트를 통해 업로드)
S3 버킷: shcw-an2-datadam-{dev|prd}-s3-portal-1/etl
"""

# 변수 설정
ssh_conn_id = 'sgd_dl_ezgator_conn_id'

if_nm = 'BIRC_0002'
userfile_nm = 'icd_t_user.TXT'
deptfile_nm = 'icd_t_dept.TXT'

command_fmt = '/shcsw/ezgator/client/ezgatorsend.sh -i {if_nm} -f {file_nm}'
command_userfile = command_fmt.format(if_nm=if_nm, file_nm=userfile_nm)
command_deptfile = command_fmt.format(if_nm=if_nm, file_nm=deptfile_nm)

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
}

# DAG ID 는 프로그램명과 동일
dag_id = 'POR_GOLDWING_TG'
tags = ['por', 'load']

with DAG(
        dag_id=dag_id,
        description=f'{dag_id} DAG',
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        default_args=args,
        tags=tags,
        catchup=False) as dag:
    get_userfile_task = SSHOperator(
        task_id='get_userfile_task',
        ssh_conn_id=ssh_conn_id,
        command=command_userfile,
    )

    get_deptfile_task = SSHOperator(
        task_id='get_deptfile_task',
        ssh_conn_id=ssh_conn_id,
        command=command_deptfile,
    )
    get_userfile_task >> get_deptfile_task
