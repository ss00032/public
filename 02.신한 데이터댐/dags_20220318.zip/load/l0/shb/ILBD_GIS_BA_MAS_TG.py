﻿# -*- coding: utf-8 -*-

from airflow import DAG
from sgd.sensors.s3_sensor_operator import S3SensorOperator
from sgd.operators.l0_load_operator import L0LoadOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *

__author__ = "노재홍"
__copyright__ = "Copyright 2021, Shinhan Datadam"
__credits__ = ["노재홍"]
__version__ = "1.0"
__maintainer__ = "노재홍"
__email__ = ""
__status__ = "Production"

"""
S3 파일 데이터를 Redshift에 적재하는 DAG 템플릿

기능 별로 분리 되었던 오퍼레이터를 하나로 통합해 내부적으로
아래 단계를 수행하면서 파일 데이터를 Redshift에 적재 한다.

  // APPEND 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 부분 delete (선택적)
  4. W0 Working 테이블 -> L0 테이블 insert

  // MERGE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 변경 데이터 delete
  4. W0 Working 테이블 -> L0 테이블 insert

  // OVERWRITE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 전체 delete
  3. W0 Working 테이블 -> L0 테이블 insert

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 테이블 적재유형 (append, merge, overwrite)
  - 수집 파일명 prefix
  - APPEND용 L0 부분 삭제 쿼리 (선택적)
  - MERGE용 L0 변경데이터 삭제 쿼리 (선택적)
  - INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
###########################################################
# Start of Target schema, working table, target table

# default: ON
dev_switch = "{{ dag_run.conf['dev_switch'] | d('ON') }}"

"""
(@) 프로그램 ID
"""
pgm_id = 'ILBD_GIS_BA_MAS_TG'

"""
(@) 한글 프로그램명
"""
description = '(은행_통합) GIS_점주기본(GIS_BA_MAS) ETL 프로그램'

"""
(@) 테이블 적재 구분
a: append, o: overwrite, m: merge
"""
table_load_type = 'o'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) 수집 파일명 prefix

은행/카드/라이프 예시:
s3_file_prefix = 'ibd_dwa_job_date_/ibd_dwa_job_date_'
s3_file_prefix = f'jd_append_table_/jd_append_table_{execution_kst}'
금투 예시:
s3_file_prefix = 'iid_aaa001m00_/iid_aaa001m00_'
s3_file_prefix = f'iid_aaa001m00_/iid_aaa001m00_{execution_kst}'
"""
s3_file_prefix = f'ibd_gis_ba_mas_/ibd_gis_ba_mas_{execution_kst}'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명 (shb/shc/shi/shl/pbc)
target_schema = f"{company_code}"

# 적재 Working 스키마
working_schema = f"{config.sgd_env['wk_layer']}_{company_code}"

"""
(@) APPEND용 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""

"""

"""
(@) MERGE용 변경데이터 삭제 쿼리 (선택적)
    : PK를 이용한 Join Query
"""
delete_sql_for_merge = """

"""

"""
(@) INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
select_sql_for_insert = f"""
    insert into shb.gis_ba_mas                                                  -- gis_점주기본
         (
           ba_sqno                                                              -- 점주_일련번호
         , shbr_sqno                                                            -- 신한점포_일련번호
         , ba_cha                                                               -- 점주차수
         , ba_gb_cd                                                             -- 점주구분코드
         , r_dist                                                               -- 반경거리
         , ba_area                                                              -- 점주면적
         , admin_gb                                                             -- 행정구역구분
         , admin_id                                                             -- 행정구역id
         , x                                                                    -- x좌표
         , y                                                                    -- y좌표
         , calc_yn                                                              -- 집계여부
         , dr_brno                                                              -- 등록점번호
         , dr_dttm                                                              -- 등록일시
         , aws_ls_dt                                                            -- aws적재일시
         )
    select ba_sqno                            as ba_sqno                        -- 점주_일련번호
         , shbr_sqno                          as shbr_sqno                      -- 신한점포_일련번호
         , ba_cha                             as ba_cha                         -- 점주차수
         , ba_gb_cd                           as ba_gb_cd                       -- 점주구분코드
         , r_dist                             as r_dist                         -- 반경거리
         , ba_area                            as ba_area                        -- 점주면적
         , admin_gb                           as admin_gb                       -- 행정구역구분
         , admin_id                           as admin_id                       -- 행정구역id
         , x                                  as x                              -- x좌표
         , y                                  as y                              -- y좌표
         , calc_yn                            as calc_yn                        -- 집계여부
         , dr_brno                            as dr_brno                        -- 등록점번호
         , dr_dttm                            as dr_dttm                        -- 등록일시
         , current_timestamp AT TIME ZONE 'Asia/Seoul' 
      from w0_shb.gis_ba_mas                                                    -- gis_점주기본
"""

# End of Target schema, working table, target table
###########################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst,
    's3_key': s3_file_prefix
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    s3_sensor_task = S3SensorOperator(
        task_id='001_s3_sensor_task',
    )

    l0_load_task = L0LoadOperator(
        task_id='002_l0_load_task',
        target_schema=target_schema,
        target_table=target_table,
        table_load_type=table_load_type,
        delete_sql_for_append=delete_sql_for_append,
        delete_sql_for_merge=delete_sql_for_merge,
        select_sql_for_insert=select_sql_for_insert,
    )

    s3_sensor_task >> l0_load_task
