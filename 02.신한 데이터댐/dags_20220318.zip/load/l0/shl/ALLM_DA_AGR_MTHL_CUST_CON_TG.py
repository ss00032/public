﻿# -*- coding: utf-8 -*-

from airflow import DAG
from sgd.sensors.ezgator_list_sensor import EzgatorListSensor
from sgd.operators.ezgator_send_operator import EzgatorSendOperator
from sgd.operators.l0_load_operator import L0LoadOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *

__author__ = "이일주"
__copyright__ = "Copyright 2021, Shinhan Datadam"
__credits__ = ["이일주"]
__version__ = "1.0"
__maintainer__ = "이일주"
__email__ = ""
__status__ = "Production"

"""
S3 파일 데이터를 Redshift에 적재하는 DAG 템플릿

기능 별로 분리 되었던 오퍼레이터를 하나로 통합해 내부적으로
아래 단계를 수행하면서 파일 데이터를 Redshift에 적재 한다.

  // APPEND 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 부분 delete (선택적)
  4. W0 Working 테이블 -> L0 테이블 insert

  // MERGE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 변경 데이터 delete
  4. W0 Working 테이블 -> L0 테이블 insert

  // OVERWRITE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 전체 delete
  3. W0 Working 테이블 -> L0 테이블 insert

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 테이블 적재유형 (append, merge, overwrite)
  - 수집 파일명 prefix
  - APPEND용 L0 부분 삭제 쿼리 (선택적)
  - MERGE용 L0 변경데이터 삭제 쿼리 (선택적)
  - INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
###########################################################
# Start of Target schema, working table, target table

# default: ON (ez_list_task, ez_send_task SKIP)
dev_switch = "{{ dag_run.conf['dev_switch'] | d('ON') }}"

"""
(@) 프로그램 ID
"""
pgm_id = 'ALLM_DA_AGR_MTHL_CUST_CON_TG'

"""
(@) 한글 프로그램명
"""
description = '(라이프_동의) DA_동의월별고객계약(DA_AGR_MTHL_CUST_CON) ETL 프로그램'

"""
(@) 테이블 적재 구분
a: append, o: overwrite, m: merge
"""
table_load_type = 'a'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'

"""
(@) 수집 파일명 prefix

은행/카드/라이프 예시:
s3_file_prefix = 'ibd_dwa_job_date_/ibd_dwa_job_date_'
s3_file_prefix = f'jd_append_table_/jd_append_table_{execution_kst}'
금투 예시:
s3_file_prefix = 'iid_aaa001m00_/iid_aaa001m00_'
s3_file_prefix = f'iid_aaa001m00_/iid_aaa001m00_{execution_kst}'
"""
s3_file_prefix = f'alm_da_agr_mthl_cust_con_/alm_da_agr_mthl_cust_con_{execution_kst}'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명 (shb/shc/shi/shl/pbc)
target_schema = f"{company_code}"

# 적재 Working 스키마
working_schema = f"{config.sgd_env['wk_layer']}_{company_code}"

"""
(@) APPEND용 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from shl.da_agr_mthl_cust_con                                        -- 성공
     where str_ym  = '{date_cd('P_TA_YM')}'                                     -- 기준년월
"""

"""
(@) MERGE용 변경데이터 삭제 쿼리 (선택적)
    : PK를 이용한 Join Query
"""
delete_sql_for_merge = """

"""

"""
(@) INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
select_sql_for_insert = f"""
    insert into shl.da_agr_mthl_cust_con                                        -- da_동의월별고객계약
         (
           str_ym                                                               -- 기준년월
         , inon_no                                                              -- 보험계약번호
         , link_info_no                                                         -- 연계정보번호
         , gpco_unfc_cst_mda_no                                                 -- 그룹사통합고객md번호
         , mnpr_pmpe_tc_sc_cd                                                   -- 주계약납입기간구분코드
         , mnpr_pmpe_tc                                                         -- 주계약납입기간
         , mnpr_pmpe_tc_dvva                                                    -- 주계약납입기간구분값
         , mnpr_pam_cycl_cd                                                     -- 주계약납입주기코드
         , curr_cd                                                              -- 화폐통화코드
         , sum_inp_fe                                                           -- 합계보험료
         , wc_sum_inp_fe                                                        -- 원화환산합계보험료
         , mtpa_str_sum_inp_fe                                                  -- 월납기준합계보험료
         , aws_ls_dt                                                            -- aws적재일시
         )
    select str_ym                             as str_ym                         -- 기준년월
         , inon_no                            as inon_no                        -- 보험계약번호
         , link_info_no                       as link_info_no                   -- 연계정보번호
         , gpco_unfc_cst_mda_no               as gpco_unfc_cst_mda_no           -- 그룹사통합고객md번호
         , mnpr_pmpe_tc_sc_cd                 as mnpr_pmpe_tc_sc_cd             -- 주계약납입기간구분코드
         , mnpr_pmpe_tc                       as mnpr_pmpe_tc                   -- 주계약납입기간
         , mnpr_pmpe_tc_dvva                  as mnpr_pmpe_tc_dvva              -- 주계약납입기간구분값
         , mnpr_pam_cycl_cd                   as mnpr_pam_cycl_cd               -- 주계약납입주기코드
         , curr_cd                            as curr_cd                        -- 화폐통화코드
         , sum_inp_fe                         as sum_inp_fe                     -- 합계보험료
         , wc_sum_inp_fe                      as wc_sum_inp_fe                  -- 원화환산합계보험료
         , mtpa_str_sum_inp_fe                as mtpa_str_sum_inp_fe            -- 월납기준합계보험료
         , current_timestamp AT TIME ZONE 'Asia/Seoul' 
      from w0_shl.da_agr_mthl_cust_con                                          -- da_동의월별고객계약
"""

# End of Target schema, working table, target table
###########################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst,
    's3_key': s3_file_prefix
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    ez_list_task = EzgatorListSensor(
        task_id='001_ez_list_task',
        dev_switch=dev_switch,
    )

    ez_send_task = EzgatorSendOperator(
        task_id='002_ez_send_task',
        dev_switch=dev_switch,
    )

    l0_load_task = L0LoadOperator(
        task_id='003_l0_load_task',
        target_schema=target_schema,
        target_table=target_table,
        table_load_type=table_load_type,
        delete_sql_for_append=delete_sql_for_append,
        delete_sql_for_merge=delete_sql_for_merge,
        select_sql_for_insert=select_sql_for_insert,
    )

    ez_list_task >> ez_send_task >> l0_load_task
