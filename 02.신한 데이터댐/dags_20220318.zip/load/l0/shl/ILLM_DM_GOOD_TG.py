﻿# -*- coding: utf-8 -*-

from airflow import DAG
from sgd.sensors.ezgator_list_sensor import EzgatorListSensor
from sgd.operators.ezgator_send_operator import EzgatorSendOperator
from sgd.operators.l0_load_operator import L0LoadOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *

__author__ = "이일주"
__copyright__ = "Copyright 2021, Shinhan Datadam"
__credits__ = ["이일주"]
__version__ = "1.0"
__maintainer__ = "이일주"
__email__ = ""
__status__ = "Production"

"""
S3 파일 데이터를 Redshift에 적재하는 DAG 템플릿

기능 별로 분리 되었던 오퍼레이터를 하나로 통합해 내부적으로
아래 단계를 수행하면서 파일 데이터를 Redshift에 적재 한다.

  // APPEND 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 부분 delete (선택적)
  4. W0 Working 테이블 -> L0 테이블 insert

  // MERGE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 변경 데이터 delete
  4. W0 Working 테이블 -> L0 테이블 insert

  // OVERWRITE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 전체 delete
  3. W0 Working 테이블 -> L0 테이블 insert

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 테이블 적재유형 (append, merge, overwrite)
  - 수집 파일명 prefix
  - APPEND용 L0 부분 삭제 쿼리 (선택적)
  - MERGE용 L0 변경데이터 삭제 쿼리 (선택적)
  - INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
###########################################################
# Start of Target schema, working table, target table

# default: ON (ez_list_task, ez_send_task SKIP)
dev_switch = "{{ dag_run.conf['dev_switch'] | d('ON') }}"

"""
(@) 프로그램 ID
"""
pgm_id = 'ILLM_DM_GOOD_TG'

"""
(@) 한글 프로그램명
"""
description = '(라이프_통합) DM_상품(DM_GOOD) ETL 프로그램'

"""
(@) 테이블 적재 구분
a: append, o: overwrite, m: merge
"""
table_load_type = 'o'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'

"""
(@) 수집 파일명 prefix

은행/카드/라이프 예시:
s3_file_prefix = 'ibd_dwa_job_date_/ibd_dwa_job_date_'
s3_file_prefix = f'jd_append_table_/jd_append_table_{execution_kst}'
금투 예시:
s3_file_prefix = 'iid_aaa001m00_/iid_aaa001m00_'
s3_file_prefix = f'iid_aaa001m00_/iid_aaa001m00_{execution_kst}'
"""
s3_file_prefix = f'ilm_dm_good_/ilm_dm_good_{execution_kst}'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명 (shb/shc/shi/shl/pbc)
target_schema = f"{company_code}"

# 적재 Working 스키마
working_schema = f"{config.sgd_env['wk_layer']}_{company_code}"

"""
(@) APPEND용 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""

"""

"""
(@) MERGE용 변경데이터 삭제 쿼리 (선택적)
    : PK를 이용한 Join Query
"""
delete_sql_for_merge = """

"""

"""
(@) INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
select_sql_for_insert = f"""
    insert into shl.dm_good                                                     -- dm_상품
         (
           good_cd                                                              -- 상품코드
         , good_nm                                                              -- 상품명
         , good_han_nm                                                          -- 상품한글명
         , good_eng_nm                                                          -- 상품영문명
         , good_abr_nm                                                          -- 상품약어명
         , good_sc_cd                                                           -- 상품구분코드
         , ann_good_yn                                                          -- 연금상품여부
         , good_dvlp_drtm_str_asrt_cd                                           -- 상품개발부서기준분류코드
         , pspe_sc_cd                                                           -- 개인연금구분코드
         , whli_good_yn                                                         -- 종신상품여부
         , rttr_good_yn                                                         -- 금리연동형상품여부
         , vari_good_sc_cd                                                      -- 변액상품구분코드
         , unvr_good_sc_cd                                                      -- 유니버설상품구분코드
         , dis_btyp_asrt_cd                                                     -- 할인유형별분류코드
         , immd_ann_yn                                                          -- 즉시연금여부
         , immd_ann_asrt_cd                                                     -- 즉시연금분류코드
         , fund_chg_lmt_asrt_cd                                                 -- 펀드변경한도분류코드
         , fund_gtst_ent_pos_cn                                                 -- 펀드최대가입가능수
         , fund_type_chg_pet_pos_cnt                                            -- 펀드유형변경신청가능횟수
         , adpa_inp_fe_sprt_apl_yn                                              -- 추가납입보험료분리적용여부
         , olgt_pmpe_tc_mon_cn                                                  -- 의무납입기간개월수
         , frre_pos_yn                                                          -- 자유납입가능여부
         , pam_tm_st_pet_pos_pam_cnt_cd                                         -- 납입일시중지신청가능납입횟수코드
         , vari_dca_gtst_pet_cnt                                                -- 변액dca최대신청횟수
         , vari_dca_mil_lmt_am                                                  -- 변액dca최저한도금액
         , sln_end_ymd                                                          -- 판매종료일자
         , sllo_optn_chg_pos_cnt                                                -- 손절매옵션변경가능횟수
         , spcf_asst_cnnc_peri_unit_cd                                          -- 특정자산연동기간단위코드
         , excs_achr_am_atmttr_pos_yn                                           -- 초과성과금액자동이전가능여부
         , adpa_pos_ptpe_mm_cn_cd                                               -- 추가납입가능경과기간월수코드
         , evnt_fur_type_cd                                                     -- 이벤트지급유형코드
         , kndn_lfin_kd_cd                                                      -- 보험개발원생명보험종류코드
         , ins_ohrs_asrt_cd                                                     -- 보험기타분류코드
         , adpa_rsv_am_mag_yn                                                   -- 추가납입적립금관리여부
         , mil_gut_ex_ded_md_cd                                                 -- 최저보증비용공제방법코드
         , mil_gut_vlua_md_cd                                                   -- 최저보증평가방법코드
         , rsv_am_bf_slls_unit_rto                                              -- 적립금이전최소단위비율
         , atmt_rtrb_rsv_am_dst_rto                                             -- 자동재배분적립금배분비율
         , atmt_rtrb_strt_ymd_type_cd                                           -- 자동재배분시작일자유형코드
         , rlx_pls_optn_pet_pos_cnt                                             -- 안심플러스옵션신청가능횟수
         , mil_gut_am_vlua_cycl_mm_cn                                           -- 최저보증금액평가주기월수
         , wcpkg_trgt_good_yn                                                   -- 웰컴패키지대상상품여부
         , clc_folow_rrsn_good_cd                                               -- 모집준수대표상품코드
         , kcis_ins_kd_cd                                                       -- 한국신용정보원보험종류코드
         , srac_inmp_type_cd                                                    -- 특별계정투입유형코드
         , isfr_good_cd                                                         -- 보험사기상품코드
         , erst_ann_optn_pos_yn                                                 -- 조기연금옵션가능여부
         , mdwt_pos_slls_prs_mm_cn                                              -- 중도인출가능최소유지월수
         , mdwt_pos_cnt                                                         -- 중도인출가능횟수
         , adp_svc_trty_anx_yn                                                  -- 선지급서비스특약부가여부
         , futu_std_pr_apl_ymd_cd                                               -- 미래기준가격적용일자코드
         , vari_good_yn                                                         -- 변액상품여부
         , unvr_good_yn                                                         -- 유니버설상품여부
         , pspe_txsy_ftns_sc_cd                                                 -- 개인연금세제적격구분코드
         , mm_sstt_pos_good_yn                                                  -- 월대체가능상품여부
         , slry_am_rto                                                          -- 월급여금액비율
         , grin_epr_yy_cn                                                       -- 체증경과년수
         , grin_rto                                                             -- 체증비율
         , grin_ag                                                              -- 체증연령
         , grin_gtst_ens_yy_cn                                                  -- 체증최대보장년수
         , rtrm_ag                                                              -- 퇴직연령
         , good_rprt_type_cd                                                    -- 상품보고서유형코드
         , mmpd_sbtr_md_cd                                                      -- 월대체차감방법코드
         , good_grou_cd                                                         -- 상품그룹코드
         , rrsn_good_cd                                                         -- 대표상품코드
         , pllo_pos_vari_good_yn                                                -- 보험계약대출가능변액상품여부
         , slls_rsv_am_bf_str_type_cd                                           -- 최소적립금이전기준유형코드
         , hlcr_svc_type_cd                                                     -- 헬스케어서비스유형코드
         , atmt_wtr_slls_pet_cnt                                                -- 자동인출최소신청횟수
         , atmt_wtr_rsv_am_vrss_lmt_rt                                          -- 자동인출적립금대비한도율
         , atmt_wtr_mil_lmt_rt                                                  -- 자동인출최저한도율
         , atmt_wtr_afur_slls_rsv_am                                            -- 자동인출지급후최소적립금
         , atmt_wtr_pet_unit_rto                                                -- 자동인출신청단위비율
         , atmt_wtr_pet_slls_am                                                 -- 자동인출신청최소금액
         , atmt_wtr_pet_unit_am                                                 -- 자동인출신청단위금액
         , atmt_wtr_pos_slls_prs_mm_cn                                          -- 자동인출가능최소유지월수
         , atmt_wtr_rsv_am_chck_yn                                              -- 자동인출적립금체크여부
         , bncs_good_yn                                                         -- 방카슈랑스상품여부
         , lst_chg_dt                                                           -- 최종변경일시
         , edw_load_dt                                                          -- edw적재일시
         , aws_ls_dt                                                            -- aws적재일시
         )
    select good_cd                            as good_cd                        -- 상품코드
         , good_nm                            as good_nm                        -- 상품명
         , good_han_nm                        as good_han_nm                    -- 상품한글명
         , good_eng_nm                        as good_eng_nm                    -- 상품영문명
         , good_abr_nm                        as good_abr_nm                    -- 상품약어명
         , good_sc_cd                         as good_sc_cd                     -- 상품구분코드
         , ann_good_yn                        as ann_good_yn                    -- 연금상품여부
         , good_dvlp_drtm_str_asrt_cd         as good_dvlp_drtm_str_asrt_cd     -- 상품개발부서기준분류코드
         , pspe_sc_cd                         as pspe_sc_cd                     -- 개인연금구분코드
         , whli_good_yn                       as whli_good_yn                   -- 종신상품여부
         , rttr_good_yn                       as rttr_good_yn                   -- 금리연동형상품여부
         , vari_good_sc_cd                    as vari_good_sc_cd                -- 변액상품구분코드
         , unvr_good_sc_cd                    as unvr_good_sc_cd                -- 유니버설상품구분코드
         , dis_btyp_asrt_cd                   as dis_btyp_asrt_cd               -- 할인유형별분류코드
         , immd_ann_yn                        as immd_ann_yn                    -- 즉시연금여부
         , immd_ann_asrt_cd                   as immd_ann_asrt_cd               -- 즉시연금분류코드
         , fund_chg_lmt_asrt_cd               as fund_chg_lmt_asrt_cd           -- 펀드변경한도분류코드
         , fund_gtst_ent_pos_cn               as fund_gtst_ent_pos_cn           -- 펀드최대가입가능수
         , fund_type_chg_pet_pos_cnt          as fund_type_chg_pet_pos_cnt      -- 펀드유형변경신청가능횟수
         , adpa_inp_fe_sprt_apl_yn            as adpa_inp_fe_sprt_apl_yn        -- 추가납입보험료분리적용여부
         , olgt_pmpe_tc_mon_cn                as olgt_pmpe_tc_mon_cn            -- 의무납입기간개월수
         , frre_pos_yn                        as frre_pos_yn                    -- 자유납입가능여부
         , pam_tm_st_pet_pos_pam_cnt_cd       as pam_tm_st_pet_pos_pam_cnt_cd   -- 납입일시중지신청가능납입횟수코드
         , vari_dca_gtst_pet_cnt              as vari_dca_gtst_pet_cnt          -- 변액dca최대신청횟수
         , vari_dca_mil_lmt_am                as vari_dca_mil_lmt_am            -- 변액dca최저한도금액
         , sln_end_ymd                        as sln_end_ymd                    -- 판매종료일자
         , sllo_optn_chg_pos_cnt              as sllo_optn_chg_pos_cnt          -- 손절매옵션변경가능횟수
         , spcf_asst_cnnc_peri_unit_cd        as spcf_asst_cnnc_peri_unit_cd    -- 특정자산연동기간단위코드
         , excs_achr_am_atmttr_pos_yn         as excs_achr_am_atmttr_pos_yn     -- 초과성과금액자동이전가능여부
         , adpa_pos_ptpe_mm_cn_cd             as adpa_pos_ptpe_mm_cn_cd         -- 추가납입가능경과기간월수코드
         , evnt_fur_type_cd                   as evnt_fur_type_cd               -- 이벤트지급유형코드
         , kndn_lfin_kd_cd                    as kndn_lfin_kd_cd                -- 보험개발원생명보험종류코드
         , ins_ohrs_asrt_cd                   as ins_ohrs_asrt_cd               -- 보험기타분류코드
         , adpa_rsv_am_mag_yn                 as adpa_rsv_am_mag_yn             -- 추가납입적립금관리여부
         , mil_gut_ex_ded_md_cd               as mil_gut_ex_ded_md_cd           -- 최저보증비용공제방법코드
         , mil_gut_vlua_md_cd                 as mil_gut_vlua_md_cd             -- 최저보증평가방법코드
         , rsv_am_bf_slls_unit_rto            as rsv_am_bf_slls_unit_rto        -- 적립금이전최소단위비율
         , atmt_rtrb_rsv_am_dst_rto           as atmt_rtrb_rsv_am_dst_rto       -- 자동재배분적립금배분비율
         , atmt_rtrb_strt_ymd_type_cd         as atmt_rtrb_strt_ymd_type_cd     -- 자동재배분시작일자유형코드
         , rlx_pls_optn_pet_pos_cnt           as rlx_pls_optn_pet_pos_cnt       -- 안심플러스옵션신청가능횟수
         , mil_gut_am_vlua_cycl_mm_cn         as mil_gut_am_vlua_cycl_mm_cn     -- 최저보증금액평가주기월수
         , wcpkg_trgt_good_yn                 as wcpkg_trgt_good_yn             -- 웰컴패키지대상상품여부
         , clc_folow_rrsn_good_cd             as clc_folow_rrsn_good_cd         -- 모집준수대표상품코드
         , kcis_ins_kd_cd                     as kcis_ins_kd_cd                 -- 한국신용정보원보험종류코드
         , srac_inmp_type_cd                  as srac_inmp_type_cd              -- 특별계정투입유형코드
         , isfr_good_cd                       as isfr_good_cd                   -- 보험사기상품코드
         , erst_ann_optn_pos_yn               as erst_ann_optn_pos_yn           -- 조기연금옵션가능여부
         , mdwt_pos_slls_prs_mm_cn            as mdwt_pos_slls_prs_mm_cn        -- 중도인출가능최소유지월수
         , mdwt_pos_cnt                       as mdwt_pos_cnt                   -- 중도인출가능횟수
         , adp_svc_trty_anx_yn                as adp_svc_trty_anx_yn            -- 선지급서비스특약부가여부
         , futu_std_pr_apl_ymd_cd             as futu_std_pr_apl_ymd_cd         -- 미래기준가격적용일자코드
         , vari_good_yn                       as vari_good_yn                   -- 변액상품여부
         , unvr_good_yn                       as unvr_good_yn                   -- 유니버설상품여부
         , pspe_txsy_ftns_sc_cd               as pspe_txsy_ftns_sc_cd           -- 개인연금세제적격구분코드
         , mm_sstt_pos_good_yn                as mm_sstt_pos_good_yn            -- 월대체가능상품여부
         , slry_am_rto                        as slry_am_rto                    -- 월급여금액비율
         , grin_epr_yy_cn                     as grin_epr_yy_cn                 -- 체증경과년수
         , grin_rto                           as grin_rto                       -- 체증비율
         , grin_ag                            as grin_ag                        -- 체증연령
         , grin_gtst_ens_yy_cn                as grin_gtst_ens_yy_cn            -- 체증최대보장년수
         , rtrm_ag                            as rtrm_ag                        -- 퇴직연령
         , good_rprt_type_cd                  as good_rprt_type_cd              -- 상품보고서유형코드
         , mmpd_sbtr_md_cd                    as mmpd_sbtr_md_cd                -- 월대체차감방법코드
         , good_grou_cd                       as good_grou_cd                   -- 상품그룹코드
         , rrsn_good_cd                       as rrsn_good_cd                   -- 대표상품코드
         , pllo_pos_vari_good_yn              as pllo_pos_vari_good_yn          -- 보험계약대출가능변액상품여부
         , slls_rsv_am_bf_str_type_cd         as slls_rsv_am_bf_str_type_cd     -- 최소적립금이전기준유형코드
         , hlcr_svc_type_cd                   as hlcr_svc_type_cd               -- 헬스케어서비스유형코드
         , atmt_wtr_slls_pet_cnt              as atmt_wtr_slls_pet_cnt          -- 자동인출최소신청횟수
         , atmt_wtr_rsv_am_vrss_lmt_rt        as atmt_wtr_rsv_am_vrss_lmt_rt    -- 자동인출적립금대비한도율
         , atmt_wtr_mil_lmt_rt                as atmt_wtr_mil_lmt_rt            -- 자동인출최저한도율
         , atmt_wtr_afur_slls_rsv_am          as atmt_wtr_afur_slls_rsv_am      -- 자동인출지급후최소적립금
         , atmt_wtr_pet_unit_rto              as atmt_wtr_pet_unit_rto          -- 자동인출신청단위비율
         , atmt_wtr_pet_slls_am               as atmt_wtr_pet_slls_am           -- 자동인출신청최소금액
         , atmt_wtr_pet_unit_am               as atmt_wtr_pet_unit_am           -- 자동인출신청단위금액
         , atmt_wtr_pos_slls_prs_mm_cn        as atmt_wtr_pos_slls_prs_mm_cn    -- 자동인출가능최소유지월수
         , atmt_wtr_rsv_am_chck_yn            as atmt_wtr_rsv_am_chck_yn        -- 자동인출적립금체크여부
         , bncs_good_yn                       as bncs_good_yn                   -- 방카슈랑스상품여부
         , lst_chg_dt                         as lst_chg_dt                     -- 최종변경일시
         , edw_load_dt                        as edw_load_dt                    -- edw적재일시
         , current_timestamp AT TIME ZONE 'Asia/Seoul' 
      from w0_shl.dm_good                                                       -- dm_상품
"""

# End of Target schema, working table, target table
###########################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst,
    's3_key': s3_file_prefix
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    ez_list_task = EzgatorListSensor(
        task_id='001_ez_list_task',
        dev_switch=dev_switch,
    )

    ez_send_task = EzgatorSendOperator(
        task_id='002_ez_send_task',
        dev_switch=dev_switch,
    )

    l0_load_task = L0LoadOperator(
        task_id='003_l0_load_task',
        target_schema=target_schema,
        target_table=target_table,
        table_load_type=table_load_type,
        delete_sql_for_append=delete_sql_for_append,
        delete_sql_for_merge=delete_sql_for_merge,
        select_sql_for_insert=select_sql_for_insert,
    )

    ez_list_task >> ez_send_task >> l0_load_task
