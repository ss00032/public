﻿# -*- coding: utf-8 -*-

from airflow import DAG
from sgd.sensors.s3_sensor_operator import S3SensorOperator
from sgd.operators.l0_load_operator import L0LoadOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *

__author__ = "윤혁준"
__copyright__ = "Copyright 2021, Shinhan Datadam"
__credits__ = ["윤혁준"]
__version__ = "1.0"
__maintainer__ = "윤혁준"
__email__ = ""
__status__ = "Production"

"""
S3 파일 데이터를 Redshift에 적재하는 DAG 템플릿

기능 별로 분리 되었던 오퍼레이터를 하나로 통합해 내부적으로
아래 단계를 수행하면서 파일 데이터를 Redshift에 적재 한다.

  // APPEND 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 부분 delete (선택적)
  4. W0 Working 테이블 -> L0 테이블 insert

  // MERGE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 변경 데이터 delete
  4. W0 Working 테이블 -> L0 테이블 insert

  // OVERWRITE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 전체 delete
  3. W0 Working 테이블 -> L0 테이블 insert

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 테이블 적재유형 (append, merge, overwrite)
  - 수집 파일명 prefix
  - APPEND용 L0 부분 삭제 쿼리 (선택적)
  - MERGE용 L0 변경데이터 삭제 쿼리 (선택적)
  - INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
###########################################################
# Start of Target schema, working table, target table

# default: ON
dev_switch = "{{ dag_run.conf['dev_switch'] | d('ON') }}"

"""
(@) 프로그램 ID
"""
pgm_id = 'ILPM_SEOUL_00705_TG'

"""
(@) 한글 프로그램명
"""
description = '[서울특별시]seoul_서울생활인구_집계구단위 ETL 프로그램'

"""
(@) 테이블 적재 구분
a: append, o: overwrite, m: merge
"""
table_load_type = 'a'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) 수집 파일명 prefix

은행/카드/라이프 예시:
s3_file_prefix = 'ibd_dwa_job_date_/ibd_dwa_job_date_'
s3_file_prefix = f'jd_append_table_/jd_append_table_{execution_kst}'
금투 예시:
s3_file_prefix = 'iid_aaa001m00_/iid_aaa001m00_'
s3_file_prefix = f'iid_aaa001m00_/iid_aaa001m00_{execution_kst}'
"""
s3_file_prefix = f'seoul_/seoul_{execution_kst}_/seoul_00705_{execution_kst}'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명 (shb/shc/shi/shl/pbc)
target_schema = f"{company_code}"

# 적재 Working 스키마
working_schema = f"{config.sgd_env['wk_layer']}_{company_code}"

"""
(@) APPEND용 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from pbc.sod_seoul_034                                               -- seoul_서울생활인구_집계구단위
          using w0_pbc.seoul_00705                                              -- seoul_서울생활인구_집계구단위
          where pbc.sod_seoul_034.revision_date = w0_pbc.seoul_00705.revision_date -- 기준일자
            and pbc.sod_seoul_034.idx = w0_pbc.seoul_00705.idx                  -- 일련번호
"""

"""
(@) MERGE용 변경데이터 삭제 쿼리 (선택적)
    : PK를 이용한 Join Query
"""
delete_sql_for_merge = """

"""

"""
(@) INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
select_sql_for_insert = f"""
    insert into pbc.sod_seoul_034                                               -- seoul_서울생활인구_집계구단위
         (
           revision_date                                                        -- 기준일자
         , idx                                                                  -- 일련번호
         , col1                                                                 -- 대상연월
         , col2                                                                 -- 요일
         , col3                                                                 -- 도착시간
         , col4                                                                 -- 출발 시군구 코드
         , col5                                                                 -- 도착 시군구 코드
         , col6                                                                 -- 성별
         , col7                                                                 -- 나이
         , col8                                                                 -- 이동유형
         , col9                                                                 -- 평균 이동 시간(분)
         , col10                                                                -- 이동인구(합)
         , crawled_ts                                                           -- crawled_ts
         , update_ts                                                            -- update_ts
         , aws_ls_dt                                                            -- aws적재일시
         )
    select revision_date                      as revision_date                  -- 기준일자
         , idx                                as idx                            -- 일련번호
         , col1                               as col1                           -- 대상연월
         , col2                               as col2                           -- 요일
         , col3                               as col3                           -- 도착시간
         , col4                               as col4                           -- 출발 시군구 코드
         , col5                               as col5                           -- 도착 시군구 코드
         , col6                               as col6                           -- 성별
         , col7                               as col7                           -- 나이
         , col8                               as col8                           -- 이동유형
         , col9                               as col9                           -- 평균 이동 시간(분)
         , col10                              as col10                          -- 이동인구(합)
         , crawled_ts                         as crawled_ts                     -- crawled_ts
         , update_ts                          as update_ts                      -- update_ts
         , current_timestamp AT TIME ZONE 'Asia/Seoul' 
      from w0_pbc.seoul_00705                                                   -- seoul_서울생활인구_집계구단위
"""

# End of Target schema, working table, target table
###########################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst,
    's3_key': s3_file_prefix
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    s3_sensor_task = S3SensorOperator(
        task_id='001_s3_sensor_task',
    )

    l0_load_task = L0LoadOperator(
        task_id='002_l0_load_task',
        target_schema=target_schema,
        target_table=target_table,
        table_load_type=table_load_type,
        delete_sql_for_append=delete_sql_for_append,
        delete_sql_for_merge=delete_sql_for_merge,
        select_sql_for_insert=select_sql_for_insert,
    )

    s3_sensor_task >> l0_load_task
