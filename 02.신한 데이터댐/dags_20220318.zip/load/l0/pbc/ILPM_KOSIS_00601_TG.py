﻿# -*- coding: utf-8 -*-

from airflow import DAG
from sgd.sensors.s3_sensor_operator import S3SensorOperator
from sgd.operators.l0_load_operator import L0LoadOperator
from sgd import logging
from sgd import config
from sgd.utils import *
from sgd.date_util import *

__author__ = "윤혁준"
__copyright__ = "Copyright 2021, Shinhan Datadam"
__credits__ = ["윤혁준"]
__version__ = "1.0"
__maintainer__ = "윤혁준"
__email__ = ""
__status__ = "Production"

"""
S3 파일 데이터를 Redshift에 적재하는 DAG 템플릿

기능 별로 분리 되었던 오퍼레이터를 하나로 통합해 내부적으로
아래 단계를 수행하면서 파일 데이터를 Redshift에 적재 한다.

  // APPEND 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 부분 delete (선택적)
  4. W0 Working 테이블 -> L0 테이블 insert

  // MERGE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 변경 데이터 delete
  4. W0 Working 테이블 -> L0 테이블 insert

  // OVERWRITE 적재 프로세스
  1. W0 Working 테이블 delete
  2. W0 Working 테이블 insert (S3 -> Redshift COPY)
  3. L0 테이블 전체 delete
  3. W0 Working 테이블 -> L0 테이블 insert

[ 적용 방법 ]
제공된 ETL 개발 템플릿에서
아래 수정 대상 '(@)' 부분만 변경해서 바로 실행 가능

(@) 변경 대상 :
  - 프로그램 ID
  - 테이블 적재유형 (append, merge, overwrite)
  - 수집 파일명 prefix
  - APPEND용 L0 부분 삭제 쿼리 (선택적)
  - MERGE용 L0 변경데이터 삭제 쿼리 (선택적)
  - INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
###########################################################
# Start of Target schema, working table, target table

# default: ON
dev_switch = "{{ dag_run.conf['dev_switch'] | d('ON') }}"

"""
(@) 프로그램 ID
"""
pgm_id = 'ILPM_KOSIS_00601_TG'

"""
(@) 한글 프로그램명
"""
description = '[통계청]kosis_종목별보험금,환급금지급사유별건수,금액 ETL 프로그램'

"""
(@) 테이블 적재 구분
a: append, o: overwrite, m: merge
"""
table_load_type = 'a'

"""
(@) EXECUTION DATE
Airflow Console 에서 DAG CREATE 시 입력하는 execution date

일배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'
월배치: execution_kst='{{ dag.timezone.convert(execution_date).strftime("%Y%m") }}'
"""
execution_kst = '{{ dag.timezone.convert(execution_date).strftime("%Y%m%d") }}'

"""
(@) 수집 파일명 prefix

은행/카드/라이프 예시:
s3_file_prefix = 'ibd_dwa_job_date_/ibd_dwa_job_date_'
s3_file_prefix = f'jd_append_table_/jd_append_table_{execution_kst}'
금투 예시:
s3_file_prefix = 'iid_aaa001m00_/iid_aaa001m00_'
s3_file_prefix = f'iid_aaa001m00_/iid_aaa001m00_{execution_kst}'
"""
s3_file_prefix = f'kosis_/kosis_{execution_kst}_/kosis_00601_{execution_kst}'

# pgm_id 파싱하여 변수 세팅
# 사용목적코드, 프로그램적재구분, 그룹사코드, 적재시점코드, 테이블명, TG, DAG TAGS
(up_cd, pt_cd, cp_cd, tm_cd, target_table, tg_cd, tags) = parse_pgm_id(pgm_id)

use_purpose = tags[0]
company_code = tags[2]

# 적재 스키마명 (shb/shc/shi/shl/pbc)
target_schema = f"{company_code}"

# 적재 Working 스키마
working_schema = f"{config.sgd_env['wk_layer']}_{company_code}"

"""
(@) APPEND용 부분삭제 쿼리 (선택적)
"""
delete_sql_for_append = f"""
    delete from pbc.kosis_022                                                   -- kosis_종목별보험금환급금지급사유별건수금액(보험통계월보)
          using w0_pbc.kosis_00601                                              -- kosis_종목별보험금,환급금지급사유별건수,금액
          where pbc.kosis_022.revision_date = w0_pbc.kosis_00601.revision_date  -- 기준일자
            and pbc.kosis_022.idx = w0_pbc.kosis_00601.idx                      -- 일련번호
"""

"""
(@) MERGE용 변경데이터 삭제 쿼리 (선택적)
    : PK를 이용한 Join Query
"""
delete_sql_for_merge = """

"""

"""
(@) INSERT용 Working 테이블 조회 쿼리 (선택적)
"""
select_sql_for_insert = f"""
    insert into pbc.kosis_022                                                   -- kosis_종목별보험금환급금지급사유별건수금액(보험통계월보)
         (
           revision_date                                                        -- 기준일자
         , idx                                                                  -- 일련번호
         , tbl_nm                                                               -- 통계표명
         , prd_de                                                               -- 일자
         , tbl_id                                                               -- 통계표id
         , itm_nm                                                               -- 아이템명
         , itm_nm_eng                                                           -- 아이템명(영문)
         , itm_id                                                               -- 아이템id
         , unit_nm                                                              -- 단위명
         , org_id                                                               -- 기관id
         , unit_nm_eng                                                          -- 단위명(영문)
         , c1_obj_nm                                                            -- 분류1항목명
         , c1_obj_nm_eng                                                        -- 분류1항목명(영문)
         , c2_obj_nm                                                            -- 분류2항목명
         , c2_obj_nm_eng                                                        -- 분류2항목명(영문)
         , dt                                                                   -- 데이터
         , prd_se                                                               -- 주기
         , c2                                                                   -- 분류1코드
         , c1                                                                   -- 분류2코드
         , c1_nm                                                                -- 분류1명
         , c2_nm                                                                -- 분류2명
         , c1_nm_eng                                                            -- 분류1명(영문)
         , c2_nm_eng                                                            -- 분류2명(영문)
         , crawled_ts                                                           -- crawled_ts
         , update_ts                                                            -- update_ts
         , aws_ls_dt                                                            -- aws적재일시
         )
    select revision_date                      as revision_date                  -- 기준일자
         , idx                                as idx                            -- 일련번호
         , tbl_nm                             as tbl_nm                         -- 통계표명
         , prd_de                             as prd_de                         -- 일자
         , tbl_id                             as tbl_id                         -- 통계표id
         , itm_nm                             as itm_nm                         -- 아이템명
         , itm_nm_eng                         as itm_nm_eng                     -- 아이템명(영문)
         , itm_id                             as itm_id                         -- 아이템id
         , unit_nm                            as unit_nm                        -- 단위명
         , org_id                             as org_id                         -- 기관id
         , unit_nm_eng                        as unit_nm_eng                    -- 단위명(영문)
         , c1_obj_nm                          as c1_obj_nm                      -- 분류1항목명
         , c1_obj_nm_eng                      as c1_obj_nm_eng                  -- 분류1항목명(영문)
         , c2_obj_nm                          as c2_obj_nm                      -- 분류2항목명
         , c2_obj_nm_eng                      as c2_obj_nm_eng                  -- 분류2항목명(영문)
         , dt                                 as dt                             -- 데이터
         , prd_se                             as prd_se                         -- 주기
         , c2                                 as c2                             -- 분류1코드
         , c1                                 as c1                             -- 분류2코드
         , c1_nm                              as c1_nm                          -- 분류1명
         , c2_nm                              as c2_nm                          -- 분류2명
         , c1_nm_eng                          as c1_nm_eng                      -- 분류1명(영문)
         , c2_nm_eng                          as c2_nm_eng                      -- 분류2명(영문)
         , crawled_ts                         as crawled_ts                     -- crawled_ts
         , update_ts                          as update_ts                      -- update_ts
         , current_timestamp AT TIME ZONE 'Asia/Seoul' 
      from w0_pbc.kosis_00601                                                   -- kosis_종목별보험금환급금지급사유별건수금액(보험통계월보)
"""

# End of Target schema, working table, target table
###########################################################

""" DAG 공통 파라미터 """
args = {
    'owner': config.sgd_env['dag_owner'],
    'retries': config.sgd_env['retries'],
    'retry_delay': config.sgd_env['retry_delay'],
    'provide_context': True,
    'on_failure_callback': logging.handle_task_fail,
    'company_code': company_code,
    'use_purpose': use_purpose,
    'execution_kst': execution_kst,
    's3_key': s3_file_prefix
}

# DAG ID 는 프로그램명과 동일
dag_id = pgm_id

with DAG(
        dag_id=dag_id,
        description=description,
        start_date=config.sgd_env['start_date'],
        schedule_interval=None,
        on_success_callback=logging.handle_dag_success,
        default_args=args,
        tags=tags,
        catchup=False) as dag:

    s3_sensor_task = S3SensorOperator(
        task_id='001_s3_sensor_task',
    )

    l0_load_task = L0LoadOperator(
        task_id='002_l0_load_task',
        target_schema=target_schema,
        target_table=target_table,
        table_load_type=table_load_type,
        delete_sql_for_append=delete_sql_for_append,
        delete_sql_for_merge=delete_sql_for_merge,
        select_sql_for_insert=select_sql_for_insert,
    )

    s3_sensor_task >> l0_load_task
